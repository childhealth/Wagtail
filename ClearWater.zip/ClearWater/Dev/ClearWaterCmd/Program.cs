﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using System.Configuration;
using UK.GOV.DH.ClearWaterLib;

namespace ClearWaterCmd
{
    class Program
    {
        #region Methods

        static int Main(string[] args)
        {
            Engine e = new Engine();

            // Parse command line arguments
            if (e.ParseCmdLineArgs(args) < 1)
            {
                return (1);
            }

            // Process
            if (e.Process())
            {
                return (0);
            }
            else
            {
                return (1);
            }
        }

        #endregion
    }
}
