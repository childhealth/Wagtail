﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using System.Configuration;
using UK.GOV.DH.ClearWaterLib;

namespace ClearWaterCmd
{
    public class Engine
    {
        #region Constants

        private const string HELP = "/?";
        private const char AUDIT = 'A';
        private const char AUDIT_ENABLE = 'L';
        private const char ERROR = 'E';
        private const char ERROR_ENABLE = 'K';
        private const char DATABASE = 'D';
        private const char XSD = 'X';
        private const string ON = "ON";
        private const string OFF = "OFF";
        private const char SLASH = '/';
        private const char QUOTE = '"';
        private const char COLON = ':';

        #endregion

        #region Fields

        private string mXMLFile;
        private string mXMLFolder;
        private ErrorLog mErrorLog;
        private AuditLog mAuditLog;
        private DatabaseHelper mDB;
        private XMLSchema mXSD;
        private bool mValidateEnvelope;

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public Engine()
		{
            mXMLFile = "";
            mXMLFolder = "";
            mErrorLog = new ErrorLog();
            mAuditLog = new AuditLog();
            mDB = new DatabaseHelper();
            mXSD = new XMLSchema();
            mValidateEnvelope = true;
		}

		#endregion

		#region Properties



        #endregion

		#region Methods

        /// <summary>
        /// Parse command line arguments
        /// If there is an error return 0
        /// If no error return 1
        /// If /? or no parameters return -1
        /// </summary>
        public int ParseCmdLineArgs(string[] args)
        {
            bool ArgA = false;
            bool ArgL = false;
            bool ArgE = false;
            bool ArgK = false;
            bool ArgD = false;
            bool ArgX = false;

            // At a minimum there must be 1 argument
            if (args.Length < 1)
            {
                Usage();
                return (-1);
            }

            // Get settings from App.config file
            mAuditLog.AuditLogFile = ConfigurationManager.AppSettings.Get("AuditLogFile");
            mAuditLog.Enabled = bool.Parse(ConfigurationManager.AppSettings.Get("AuditLogEnable"));
            mErrorLog.ErrorLogFile = ConfigurationManager.AppSettings.Get("ErrorLogFile");
            mErrorLog.Enabled = bool.Parse(ConfigurationManager.AppSettings.Get("ErrorLogEnable"));
            mDB.DatabaseConnection = ConfigurationManager.AppSettings.Get("DatabaseConnectionString");
            mXSD.XSDFolder = ConfigurationManager.AppSettings.Get("XSDFolder");
            mValidateEnvelope = bool.Parse(ConfigurationManager.AppSettings.Get("ValidateEnvelope"));

            // Parse command line arguments - these will override config file settings

            // Check if first argument is /?
            if (args[0] == HELP)
            {
                Usage();
                return (-1);
            }

            // Otherwise the first argument is a filename or a folder name
            string s = args[0];
            // Check if value is quoted
            if (s[0] == QUOTE)
            {
                // Check end quote found
                if (s[s.Length - 1] != QUOTE)
                {
                    Console.WriteLine("Argument: " + s + " is invalid.");
                    return (0);
                }
                s = s.Substring(1, s.Length - 2);
            }
            
            // Check if we have a valid XML file
            if (File.Exists(s))
            {
                mXMLFile = s;
                mXMLFolder = "";
            }
            else
            {
                // If not a valid XML file check if we have a valid folder
                if (Directory.Exists(s))
                {
                    mXMLFile = "";
                    mXMLFolder = s;
                }
                else
                {
                    Console.WriteLine("Argument: " + s + " is neither a valid file name or folder name.");
                    return (0);
                }
            }

            // Parse any remaining command arguments
            for (int i = 1; i < args.Length; ++i)
            {
                string a = args[i];
                string v = "";

                // Check we have a valid argument name
                if (a.Length < 4 || a[0] != SLASH || !(a[1] == AUDIT || a[1] == AUDIT_ENABLE || a[1] == ERROR || a[1] == ERROR_ENABLE || a[1] == DATABASE || a[1] == XSD) || a[2] != COLON)
                {
                    Console.WriteLine("Argument: " + a + " is invalid.");
                    return (0);
                }
                
                // Get the argument value
                switch (a[1])
                {
                    case AUDIT:
                        // Get the audit log name
                        // Check not a repeat
                        if (ArgA)
                        {
                            Console.WriteLine("Argument: " + a + " is repeated.");
                            return (0);
                        }
                        // Check if value is quoted
                        if (a[3] == QUOTE)
                        {
                            // Check end quote found
                            if (a[a.Length - 1] != QUOTE)
                            {
                                Console.WriteLine("Argument: " + a + " is invalid.");
                                return (0);
                            }
                            mAuditLog.AuditLogFile = a.Substring(4, a.Length - 5);
                        }
                        else
                        {
                            mAuditLog.AuditLogFile = a.Substring(3, a.Length - 3);
                        }
                        ArgA = true;
                        break;

                    case AUDIT_ENABLE:
                        // Get the audit enable value
                        // Check not a repeat
                        if (ArgL)
                        {
                            Console.WriteLine("Argument: " + a + " is repeated.");
                            return (0);
                        }
                        v = a.Substring(3, a.Length - 3);
                        switch (v)
                        {
                            case ON:
                                mAuditLog.Enabled = true;
                                break;

                            case OFF:
                                mAuditLog.Enabled = false;
                                break;

                            default:
                                Console.WriteLine("Argument: " + a + " is invalid.");
                                return (0);
                        }
                        ArgL = true;
                        break;

                    case ERROR:
                        // Get the error log name
                        // Check not a repeat
                        if (ArgE)
                        {
                            Console.WriteLine("Argument: " + a + " is repeated.");
                            return (0);
                        }
                        // Check if value is quoted
                        if (a[3] == QUOTE)
                        {
                            // Check end quote found
                            if (a[a.Length - 1] != QUOTE)
                            {
                                Console.WriteLine("Argument: " + a + " is invalid.");
                                return (0);
                            }
                            mErrorLog.ErrorLogFile = a.Substring(4, a.Length - 5);
                        }
                        else
                        {
                            mErrorLog.ErrorLogFile = a.Substring(3, a.Length - 3);
                        }
                        ArgE = true;
                        break;

                    case ERROR_ENABLE:
                        // Get the error enable value
                        // Check not a repeat
                        if (ArgK)
                        {
                            Console.WriteLine("Argument: " + a + " is repeated.");
                            return (0);
                        }
                        v = a.Substring(3, a.Length - 3);
                        switch (v)
                        {
                            case ON:
                                mErrorLog.Enabled = true;
                                break;

                            case OFF:
                                mErrorLog.Enabled = false;
                                break;

                            default:
                                Console.WriteLine("Argument: " + a + " is invalid.");
                                return (0);
                        }
                        ArgK = true;
                        break;

                    case DATABASE:
                        // Get the database connection string
                        // Check not a repeat
                        if (ArgD)
                        {
                            Console.WriteLine("Argument: " + a + " is repeated.");
                            return (0);
                        }
                        // Check if value is quoted
                        if (a[3] == QUOTE)
                        {
                            // Check end quote found
                            if (a[a.Length - 1] != QUOTE)
                            {
                                Console.WriteLine("Argument: " + a + " is invalid.");
                                return (0);
                            }
                            mDB.DatabaseConnection = a.Substring(4, a.Length - 5);
                        }
                        else
                        {
                            mDB.DatabaseConnection = a.Substring(3, a.Length - 3);
                        }
                        ArgD = true;
                        break;

                    case XSD:
                        // Get the XSD folder name
                        // Check not a repeat
                        if (ArgX)
                        {
                            Console.WriteLine("Argument: " + a + " is repeated.");
                            return (0);
                        }
                        // Check if value is quoted
                        if (a[3] == QUOTE)
                        {
                            // Check end quote found
                            if (a[a.Length - 1] != QUOTE)
                            {
                                Console.WriteLine("Argument: " + a + " is invalid.");
                                return (0);
                            }
                            mXSD.XSDFolder = a.Substring(4, a.Length - 5);
                        }
                        else
                        {
                            mXSD.XSDFolder = a.Substring(3, a.Length - 3);
                        }
                        ArgX = true;
                        break;

                    default:
                        // Do nothing as we have already checked we have a valid argument name
                        break;
                }
            }

            return (1);
        }

        /// <summary>
        /// Write out usage of command to stdout
        /// </summary>
        private void Usage()
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("CLEARWATERCMD filename | foldername [/A:file] [/L:status] [/E:file] [/K:status] [/D:string] [/X:folder]");
            Console.WriteLine("");
            Console.WriteLine("  filename | foldername");
            Console.WriteLine("              The full path name to an XML file to be loaded or");
            Console.WriteLine("              the full path name to a folder from which to load XML files from.");
            Console.WriteLine("  /A          The text file to store audit records.");
            Console.WriteLine("  file        The full path name to the text file");
            Console.WriteLine("  /L          Enable or disable writing of audit records.");
            Console.WriteLine("  status      ON   Enable writing of audit records");
            Console.WriteLine("              OFF  Disable writing of audit records");
            Console.WriteLine("  /E          The text file to store error records.");
            Console.WriteLine("  file        The full path name to the text file");
            Console.WriteLine("  /K          Enable or disable writing of error records.");
            Console.WriteLine("  status      ON   Enable writing of error records");
            Console.WriteLine("              OFF  Disable writing of error records");
            Console.WriteLine("  /D          Database connection string.");
            Console.WriteLine("  string      ADO.NET format database connection string");
            Console.WriteLine("  /X          The folder containing XSD files.");
            Console.WriteLine("  folder      The full path name to folder");
        }

        /// <summary>
        /// Process
        /// If error return false otherwise return true
        /// </summary>
        public bool Process()
        {
            if (mXMLFile != "")
            {
                return (LoadXMLFile());
            }
            else
            {
                return (LoadFromFolder());
            }
        }

        /// <summary>
        /// Load XML File
        /// Returns true if no errors, otherwise false
        /// </summary>
        private bool LoadXMLFile()
        {
            bool result = true;

            // Check settings
            if (!CheckSettings())
                return (false);

            // Check we have a valid XML file
            if (!File.Exists(mXMLFile))
            {
                Console.WriteLine("Error: XML File " + mXMLFile + " does not exist.");
                return (false);
            }

            // Create XmlReaderSettings
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.ConformanceLevel = ConformanceLevel.Document;
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;
            settings.Schemas = mXSD.XmlSchemas;
            settings.ValidationType = ValidationType.None;

            // Create XmlReader
            XmlReader reader = XmlReader.Create(mXMLFile, settings);
            string s = "XML File " + mXMLFile + " opened.";
            Console.WriteLine(s);
            mAuditLog.WriteLog(s);

            // Read the DistributionEnvelope
            DistributionEnvelope mEnvelope = new DistributionEnvelope();
            mEnvelope.Error = mErrorLog;
            mEnvelope.Audit = mAuditLog;
            mEnvelope.Database = mDB;

            // Open database connection
            mEnvelope.Database.OpenDB();

            switch (mEnvelope.ReadAndLoadXML(reader, mXMLFile, mValidateEnvelope))
            {
                case -1:
                    s = "Error: Reading XML file - see error log.";
                    Console.WriteLine(s);
                    mAuditLog.WriteLog(s);
                    result = false;

                    // If inserted any database records, roll them back
                    if (mEnvelope.DatabaseInsert) mEnvelope.RollBack(mEnvelope.Header_trackingid);
                    break;

                case -2:
                    s = "Error: Database - see error log.";
                    Console.WriteLine(s);
                    mAuditLog.WriteLog(s);
                    result = false;
                    break;

                case -3:
                    s = "Error: XML file with same TrackingID already loaded into database - see error log.";
                    Console.WriteLine(s);
                    mAuditLog.WriteLog(s);
                    result = false;
                    break;

                default:
                    s = "XML file loaded into database successfully.";
                    Console.WriteLine(s);
                    mAuditLog.WriteLog(s);
                    break;
            }

            // Close database connection
            mEnvelope.Database.CloseDB();

            // Close XmlReader
            reader.Close();
            s = "XML File " + mXMLFile + " closed.";
            Console.WriteLine(s);
            mAuditLog.WriteLog(s);

            return (result);
        }

        /// <summary>
        /// Load XML Files from folder
        /// Returns true if no errors, otherwise false
        /// </summary>
        private bool LoadFromFolder()
        {
            bool result = true;

            // Check settings
            if (!CheckSettings())
                return (false);

            // Check we have a valid XML folder
            if (!Directory.Exists(mXMLFolder))
            {
                Console.WriteLine("Error: Folder " + mXMLFolder + " does not exist.");
                return (false);
            }

            // Create XmlReaderSettings
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.ConformanceLevel = ConformanceLevel.Document;
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;
            settings.Schemas = mXSD.XmlSchemas;
            settings.ValidationType = ValidationType.None;

            string s = "Folder " + mXMLFolder + " opened.";
            Console.WriteLine(s);
            mAuditLog.WriteLog(s);

            // Process the list of files found in the directory.
            string[] fileEntries = Directory.GetFiles(mXMLFolder);
            foreach (string mXMLFile in fileEntries)
            {
                // Create XmlReader
                XmlReader reader = XmlReader.Create(mXMLFile, settings);
                s = "XML File " + mXMLFile + " opened.";
                Console.WriteLine(s);
                mAuditLog.WriteLog(s);

                // Read the DistributionEnvelope
                DistributionEnvelope mEnvelope = new DistributionEnvelope();
                mEnvelope.Error = mErrorLog;
                mEnvelope.Audit = mAuditLog;
                mEnvelope.Database = mDB;

                // Open database connection
                mEnvelope.Database.OpenDB();

                switch (mEnvelope.ReadAndLoadXML(reader, mXMLFile, mValidateEnvelope))
                {
                    case -1:
                        s = "Error: Reading XML file - see error log.";
                        Console.WriteLine(s);
                        mAuditLog.WriteLog(s);
                        result = false;

                        // If inserted any database records, roll them back
                        if (mEnvelope.DatabaseInsert) mEnvelope.RollBack(mEnvelope.Header_trackingid);
                        break;

                    case -2:
                        s = "Error: Database - see error log.";
                        Console.WriteLine(s);
                        mAuditLog.WriteLog(s);
                        result = false;
                        break;

                    case -3:
                        s = "Error: XML file with same TrackingID already loaded into database - see error log.";
                        Console.WriteLine(s);
                        mAuditLog.WriteLog(s);
                        result = false;
                        break;

                    default:
                        s = "XML file loaded into database successfully.";
                        Console.WriteLine(s);
                        mAuditLog.WriteLog(s);
                        break;
                }

                // Close database connection
                mEnvelope.Database.CloseDB();

                // Close XmlReader
                reader.Close();
                s = "XML File " + mXMLFile + " closed.";
                Console.WriteLine(s);
                mAuditLog.WriteLog(s);
            }

            s = "Folder " + mXMLFolder + " closed.";
            Console.WriteLine(s);
            mAuditLog.WriteLog(s);

            return (result);
        }

        /// <summary>
        /// Validates settings.
        /// If there is a validation error will place a message to stdout and return false.
        /// </summary>
        private bool CheckSettings()
        {
            // Audit
            if (mAuditLog.Enabled)
            {
                try
                {
                    File.AppendAllText(mAuditLog.AuditLogFile, "");
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error: Audit Log File " + mAuditLog.AuditLogFile + ": " + e.Message);
                    return false;
                }
            }

            // Error
            if (mErrorLog.Enabled)
            {
                try
                {
                    File.AppendAllText(mErrorLog.ErrorLogFile, "");
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error: Error Log File " + mErrorLog.ErrorLogFile + ": " + e.Message);
                    return false;
                }
            }

            // Database
            try
            {
                mDB.OpenDB();
                mDB.CloseDB();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: Database connection string " + mDB.DatabaseConnection + ": " + e.Message);
                return false;
            }

            // XSD Folder
            try
            {
                mXSD.LoadXSD();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: XSD file: " + e.Message);
                return false;
            }

            return true;
        }

		#endregion
    }
}
