﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		GPPractice
    // Description:	GP Practice
    //
    // History:
    // 29 Oct 2011	1.00	MAK Initial version
    // 12 Mar 2012  2.00    MAK Updated

    /// <summary>
    /// GPPractice represents a GP Practice. 
    /// </summary>
    public class GPPractice
    {
        #region Constants

        private const string XML_gPPractice = "gPPractice";
        private const string XML_templateId = "templateId";
        private const string XML_code = "code";
        private const string XML_locationOrganization = "locationOrganization";
        private const string XML_id = "id";
        private const string XML_name = "name";
        private const string XML_extension = "extension";

		#endregion

		#region Fields

        private ErrorLog mErrorLog;                     // Error log
        private AuditLog mAuditLog;                     // Audit Log

        private string mOrgCode;                        // Organisation code 
        private string mOrgName;                        // Organisation name

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public GPPractice()
		{
			Clear();
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// Audit Log
        /// </summary>
        public AuditLog Audit
        {
            get
            {
                return mAuditLog;
            }

            set
            {
                mAuditLog = value;
            }
        }

        /// <summary>
        /// Organisation code
        /// </summary>
        public string OrgCode
        {
            get
            {
                return mOrgCode;
            }
        }

        /// <summary>
        /// Organisation name
        /// </summary>
        public string OrgName
        {
            get
            {
                return mOrgName;
            }
        }

        #endregion

		#region Methods

        /// <summary>
        /// Clears field values to default values.
        /// </summary>
        public void Clear()
        {
            mOrgCode = "";
            mOrgName = "";
        }
        
		/// <summary>
        /// Read in GP Practice from an XML stream.
        /// If an error is encountered return false.
		/// </summary>
		/// <param name="reader">XML input stream.</param>
        /// <param name="XMLFile">Name of XML file.</param>
		public bool ReadXML(XmlReader reader, string XMLFile)
		{
            // Setup element name checker
            ElementNameChecker x = new ElementNameChecker();
            x.Error = mErrorLog;
            x.XMLFile = XMLFile;

            try
            {
                // On <gPPractice> start element
                if (!x.Check(reader, XML_gPPractice)) return (false);

                // <templateId> element
                reader.Read();
                if (!x.Check(reader, XML_templateId)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // <locationOrganization> start element
                reader.Read();
                if (!x.Check(reader, XML_locationOrganization)) return (false);

                // <templateId> element
                reader.Read();
                if (!x.Check(reader, XML_templateId)) return (false);

                // Move to next element
                reader.Read();

                // Check if <id> element
                if (reader.LocalName == XML_id)
                {
                    // extension attribute
                    mOrgCode = reader.GetAttribute(XML_extension);

                    // Move to next element
                    reader.Read();

                }

                // Check if <name> start element
                if (reader.LocalName == XML_name)
                {
                    // Element contents if not empty
                    if (!reader.IsEmptyElement)
                    {
                        mOrgName = reader.ReadElementContentAsString();
                    }
                    else
                    {
                        // Skip to next element
                        reader.Skip();
                    }
                }

                // On <locationOrganization> end element
                if (!x.Check(reader, XML_locationOrganization)) return (false);

                // <gPPractice> end element
                reader.Read();
                if (!x.Check(reader, XML_gPPractice)) return (false);

                // Move to next element
                reader.Read();
 
                return true;
            }
            catch (XmlException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
            catch (XmlSchemaValidationException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
		}

		#endregion
    }
}
