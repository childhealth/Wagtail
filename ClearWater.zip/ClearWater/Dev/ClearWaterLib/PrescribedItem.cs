﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Data;
using System.Data.SqlClient;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		PrescribedItem
    // Description:	A prescribed item.
    //
    // History:
    // 28 Oct 2011	1.00	MAK Initial version
    // 12 Mar 2012  1.00    MAK Updated

    /// <summary>
    /// PresscribedItem represents a prescribed item. 
    /// </summary>
    public class PrescribedItem
    {
        #region Constants

        private const string XML_component21 = "component21";
        private const string XML_component26 = "component26";
        private const string XML_prescribedItems = "prescribedItems";
        private const string XML_medicationSupply = "medicationSupply";
        private const string XML_code = "code";
        private const string XML_value = "value";
        private const string XML_consumable = "consumable";
        private const string XML_product = "product";
        private const string XML_manufacturedProduct = "manufacturedProduct";
        private const string XML_manufacturedManufacturedMaterial = "manufacturedManufacturedMaterial";
        private const string XML_codeSystem = "codeSystem";
        private const string XML_displayName = "displayName";
        private const string CONTAINER = "from Encounter ID = ";
        private const string XML_text = "text";

		#endregion

		#region Fields

        private ErrorLog mErrorLog;                     // Error log
        private AuditLog mAuditLog;                     // Audit Log
        private DatabaseHelper mDB;                     // Database helper

        private string mPrescribedItem_value;           // A string representation of the prescribed item.
        private string mMedicationCode;                 // Medication code
        private string mMedicationCodeSystem;           // Medication code system
        private string mMedicationDisplayName;          // Medication display name

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public PrescribedItem()
		{
			Clear();
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// Audit Log
        /// </summary>
        public AuditLog Audit
        {
            get
            {
                return mAuditLog;
            }

            set
            {
                mAuditLog = value;
            }
        }

        /// <summary>
        /// Database Helper
        /// </summary>
        public DatabaseHelper Database
        {
            get
            {
                return mDB;
            }

            set
            {
                mDB = value;
            }
        }

        /// <summary>
        /// Prescribed Item Value
        /// </summary>
        public string PrescribedItemValue
        {
            get
            {
                return mPrescribedItem_value;
            }
        }

        /// <summary>
        /// Medication code
        /// </summary>
        public string MedicationCode
        {
            get
            {
                return mMedicationCode;
            }
        }

        /// <summary>
        /// Medication code system
        /// </summary>
        public string MedicationCodeSystem
        {
            get
            {
                return mMedicationCodeSystem;
            }
        }

        /// <summary>
        /// Medication display name
        /// </summary>
        public string MedicationDisplayName
        {
            get
            {
                return mMedicationDisplayName;
            }
        }

        #endregion

		#region Methods

        /// <summary>
        /// Clears field values to default values.
        /// </summary>
        public void Clear()
        {
            mPrescribedItem_value = "";
            mMedicationCode = "";
            mMedicationCodeSystem = "";
            mMedicationDisplayName = "";
        }
        
		/// <summary>
        /// Read in Prescribed item from an XML stream.
        /// If an error is encountered return false.
		/// </summary>
		/// <param name="reader">XML input stream.</param>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="FeedType">Feed type.</param>
        /// <param name="EncounterID">Encounter identity.</param>
        public bool ReadXML(XmlReader reader, string XMLFile, DistributionEnvelope.FEEDTYPE FeedType, string EncounterID)
		{
            // Setup element name checker
            ElementNameChecker x = new ElementNameChecker();
            x.Error = mErrorLog;
            x.XMLFile = XMLFile;

            string ComponentTAG = "";
            string PrescriptionTAG = "";
            string ValueTAG = "";
            string ItemTAG = "";

            // Set tags dependent on feed type
            switch (FeedType)
            {
                case DistributionEnvelope.FEEDTYPE.OOHWIC:
                    ComponentTAG = XML_component21;
                    PrescriptionTAG = XML_prescribedItems;
                    ValueTAG = XML_value;
                    ItemTAG = XML_consumable;
                    break;

                case DistributionEnvelope.FEEDTYPE.AE:
                    ComponentTAG = XML_component26;
                    PrescriptionTAG = XML_medicationSupply;
                    ValueTAG = XML_text;
                    ItemTAG = XML_product;
                    break;
            }

            try
            {
                // On component start elelemt
                if (!x.Check(reader, ComponentTAG)) return (false);

                // prescription start element
                reader.Read();
                if (!x.Check(reader, PrescriptionTAG)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // Move to next element
                reader.Read();

                // Check if <value> start element
                if (reader.LocalName == ValueTAG)
                {
                    // Element contents if not empty
                    if (!reader.IsEmptyElement)
                    {
                        mPrescribedItem_value = reader.ReadElementContentAsString();
                    }
                    else
                    {
                        // Skip to next element
                        reader.Skip();
                    }
                }

                // There can be 0 .. 1 items elements
                if (reader.LocalName == ItemTAG)
                {
                    // <manufacturedProduct> start element
                    reader.Read();
                    if (!x.Check(reader, XML_manufacturedProduct)) return (false);

                    // <manufacturedManufacturedMaterial> start element
                    reader.Read();
                    if (!x.Check(reader, XML_manufacturedManufacturedMaterial)) return (false);

                    // <code> element
                    reader.Read();
                    if (!x.Check(reader, XML_code)) return (false);

                    // code attribute
                    mMedicationCode = reader.GetAttribute(XML_code);

                    // codeSystem attribute
                    mMedicationCodeSystem = reader.GetAttribute(XML_codeSystem);

                    // displayName attribute
                    mMedicationDisplayName = reader.GetAttribute(XML_displayName);
                }

                // Skip to ComponentTAG end element
                while (reader.LocalName != ComponentTAG && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, ComponentTAG, "End", CONTAINER + EncounterID);
                    return false;
                }

                // Move to next element
                reader.Read();
 
                return true;
            }
            catch (XmlException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
            catch (XmlSchemaValidationException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
		}

        /// <summary>
        /// Insert the prescribed item into database
        /// If an error is encountered return false.
        /// </summary>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="TrackingID">Tracking identifier.</param>
        /// <param name="FeedID">Feed identifier.</param>
        /// <param name="PrescribedID">Prescribed identifier.</param>
        public bool Insert(string XMLFile, string TrackingID, int FeedID, int PrescribedID)
        {

            string myCmd = "INSERT INTO prescribeditems (trackingid, feedid, prescribedid, prescribedvalue, medicationcode, medicationcodesystem, medicationdisplayname) VALUES (" +
                "'" + mDB.Munge(TrackingID) + "'," +
                FeedID + "," +
                PrescribedID + ",'" +
                mDB.Munge(mPrescribedItem_value) + "','" +
                mDB.Munge(mMedicationCode) + "','" +
                mDB.Munge(mMedicationCodeSystem) + "','" +
                mDB.Munge(mMedicationDisplayName) + 
                "')";

            SqlCommand myCommand = new SqlCommand(myCmd, mDB.SQLConnection);
            myCommand.CommandType = CommandType.Text;

            try
            {
                // INSERT could throw an exception
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog("XML File: " + XMLFile + " INSERT INTO prescribeditems error: " + e.Message);
                return (false);
            }

            return (true);
        }

		#endregion
    }
}
