﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		ErrorLog
    // Description:	Class to manage error logging
    //
    // History:
    // 25 Oct 2011	1.00	MAK Initial version

    /// <summary>
    /// Class to manage error logging
    /// </summary>
    public class ErrorLog
    {
        #region Constants

        private const string NEWLINE = "\r\n";

        #endregion

        #region Fields

        private bool mEnabled;          // Error logging enabled.
        private string mErrorLogFile;   // Error Log file.

        #endregion

        #region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
		public ErrorLog()
		{
			mEnabled = false;
            mErrorLogFile = "";
		}

		#endregion

        #region Properties

        /// <summary>
        /// Error log enabled
        /// </summary>
        public bool Enabled
        {
            get
            {
                return mEnabled;
            }

            set
            {
                mEnabled = value;
            }
        }

        /// <summary>
        /// Error log File
        /// </summary>
        public string ErrorLogFile
        {
            get
            {
                return mErrorLogFile;
            }

            set
            {
                mErrorLogFile = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Write message to log. 
        /// </summary>
        /// <param name="message">Message.</param>
        public void WriteLog(string message)
        {
            if (mEnabled)
            {
                File.AppendAllText(mErrorLogFile, DateTime.Now.ToString() + ": " + message + NEWLINE);
            }
        }

        #endregion
    }
}
