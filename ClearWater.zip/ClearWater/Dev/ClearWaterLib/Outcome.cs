﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Data;
using System.Data.SqlClient;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		Outcome
    // Description:	An outcome description.
    //
    // History:
    // 28 Oct 2011	1.00	MAK Initial version

    /// <summary>
    /// Outcome represents an outcome description. 
    /// </summary>
    public class Outcome
    {
        #region Constants

        private const string XML_component5 = "component5";
        private const string XML_outcomeDescription = "outcomeDescription";
        private const string XML_code = "code";
        private const string XML_value = "value";

		#endregion

		#region Fields

        private ErrorLog mErrorLog;                     // Error log
        private AuditLog mAuditLog;                     // Audit Log
        private DatabaseHelper mDB;                     // Database helper
 
        private string mOutcome_value;                  // Outcome description

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public Outcome()
		{
			Clear();
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// Audit Log
        /// </summary>
        public AuditLog Audit
        {
            get
            {
                return mAuditLog;
            }

            set
            {
                mAuditLog = value;
            }
        }

        /// <summary>
        /// Database Helper
        /// </summary>
        public DatabaseHelper Database
        {
            get
            {
                return mDB;
            }

            set
            {
                mDB = value;
            }
        }

        /// <summary>
        /// Outcome Value
        /// </summary>
        public string OutcomeValue
        {
            get
            {
                return mOutcome_value;
            }
        }

        #endregion

		#region Methods

        /// <summary>
        /// Clears field values to default values.
        /// </summary>
        public void Clear()
        {
            mOutcome_value = "";
        }
        
		/// <summary>
        /// Read in Outcome from an XML stream.
        /// If an error is encountered return false.
		/// </summary>
		/// <param name="reader">XML input stream.</param>
        /// <param name="XMLFile">Name of XML file.</param>
		public bool ReadXML(XmlReader reader, string XMLFile)
		{
            // Setup element name checker
            ElementNameChecker x = new ElementNameChecker();
            x.Error = mErrorLog;
            x.XMLFile = XMLFile;

            try
            {
                // On <component5> start element
                if (!x.Check(reader, XML_component5)) return (false);

                // <outcomeDescription> start element
                reader.Read();
                if (!x.Check(reader, XML_outcomeDescription)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // <value> element
                reader.Read();
                if (!x.Check(reader, XML_value)) return (false);

                mOutcome_value = reader.ReadElementString();

                // <outcomeDescription> end element
                if (!x.Check(reader, XML_outcomeDescription)) return (false);

                // <component5> end element
                reader.Read();
                if (!x.Check(reader, XML_component5)) return (false);

                // Move to next element
                reader.Read();
 
                return true;
            }
            catch (XmlException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
            catch (XmlSchemaValidationException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
		}

        /// <summary>
        /// Insert the outcome into database
        /// If an error is encountered return false.
        /// </summary>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="TrackingID">Tracking identifer.</param>
        /// <param name="FeedID">Feed identifier.</param>
        /// <param name="OutcomeID">Outcome identifier.</param>
        public bool Insert(string XMLFile, string TrackingID, int FeedID, int OutcomeID)
        {

            string myCmd = "INSERT INTO outcomes (trackingid, feedid, outcomeid, outcomevalue) VALUES (" +
                "'" + mDB.Munge(TrackingID) + "'," +
                FeedID + "," +
                OutcomeID + ",'" +
                mDB.Munge(mOutcome_value) +
                "')";

            SqlCommand myCommand = new SqlCommand(myCmd, mDB.SQLConnection);
            myCommand.CommandType = CommandType.Text;

            try
            {
                // INSERT could throw an exception
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog("XML File: " + XMLFile + " INSERT INTO prescribeditems error: " + e.Message);
                return (false);
            }

            return (true);
        }

		#endregion
    }
}
