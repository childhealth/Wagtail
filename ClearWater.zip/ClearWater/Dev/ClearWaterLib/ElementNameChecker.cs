﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		ElementNameChecker
    // Description:	Element Name Checker
    //
    // History:
    // 29 Oct 2011	1.00	MAK Initial version

    /// <summary>
    /// ElementNameChecker is a utility class to check an XML element name is correct 
    /// </summary>
    public class ElementNameChecker
    {
		#region Fields

        private ErrorLog mErrorLog;                     // Error log
        private string mXMLFile;                        // XML file

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public ElementNameChecker()
		{
            mErrorLog = null;
            mXMLFile = "";
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// XML File
        /// </summary>
        public string XMLFile
        {
            get
            {
                return mXMLFile;
            }

            set
            {
                mXMLFile = value;
            }
        }

        #endregion

		#region Methods

        /// <summary>
        /// Check node name is same as expected
        /// If not write a message to error log and return false, otherwise return true
        /// </summary>
        public bool Check(XmlReader reader, string expectedName)
        {
            if (reader.LocalName != expectedName)
            {
                IXmlLineInfo xmlInfo = (IXmlLineInfo)reader;
                int lineNumber = xmlInfo.LineNumber;
                int linePosition = xmlInfo.LinePosition;
                mErrorLog.WriteLog("XML File: " + XMLFile + " Element: <" + reader.LocalName + "> found where expected element is: <" + expectedName + "> Line " + lineNumber + " position " + linePosition + ".");
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Check attribute defined in current node
        /// If not write a message to error log and return false, otherwise return true
        /// </summary>
        public bool CheckA(XmlReader reader, string expectedName)
        {
            if (!reader.MoveToAttribute(expectedName))
            {
                IXmlLineInfo xmlInfo = (IXmlLineInfo)reader;
                int lineNumber = xmlInfo.LineNumber;
                int linePosition = xmlInfo.LinePosition;
                mErrorLog.WriteLog("XML File: " + XMLFile + " Attribute: " + expectedName + " is missing. Line " + lineNumber + " position " + linePosition + ".");
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Report expectedName is missing
        /// </summary>
        public void Missing(XmlReader reader, string expectedName, string parentPath, string container)
        {
            IXmlLineInfo xmlInfo = (IXmlLineInfo)reader;
            int lineNumber = xmlInfo.LineNumber;
            int linePosition = xmlInfo.LinePosition;
            mErrorLog.WriteLog("XML File: " + XMLFile + " " + parentPath + " Element: <" + expectedName + "> is missing " + container);
        }

        /// <summary>
        /// Report datetime is invalid
        /// </summary>
        public void InvalidDateTime(XmlReader reader, string expectedName, string parentPath, string dt)
        {
            IXmlLineInfo xmlInfo = (IXmlLineInfo)reader;
            int lineNumber = xmlInfo.LineNumber;
            int linePosition = xmlInfo.LinePosition;
            mErrorLog.WriteLog("XML File: " + XMLFile + " " + parentPath + " Element: <" + expectedName + "> invalid date time format: " + dt + " Line " + lineNumber + " position " + linePosition + ".");
        }

		#endregion
    }
}
