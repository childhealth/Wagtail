﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Data;
using System.Data.SqlClient;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		PMIContent
    // Description:	Paient Master Index Content
    //
    // History:
    // 28 Oct 2011	1.00	MAK Initial version
    // 06 Feb 2012  2.00    MAK Updated
    // 12 Mar 2012  3.00    MAK Updated

    /// <summary>
    /// PMI represents the Patient Master Index Content for a patient 
    /// </summary>
    public class PMIContent
    {
        #region Constants

        private const string XML_templateId = "templateId";
        private const string XML_id = "id";
        private const string XML_code = "code";
        private const string XML_component1 = "component1";
        private const string XML_deleteFlag = "deleteFlag";
        private const string XML_value = "value";
        private const string XML_component2 = "component2";
        private const string XML_createdDate = "createdDate";
        private const string XML_component3 = "component3";
        private const string XML_modifiedDate = "modifiedDate";
        private const string XML_subject = "subject";
        private const string XML_patient = "patient";
        private const string XML_addr = "addr";
        private const string XML_postalCode = "postalCode";
        private const string XML_patientPerson = "patientPerson";
        private const string XML_name = "name";
        private const string XML_administrativeGenderCode = "administrativeGenderCode";
        private const string XML_birthTime = "birthTime";
        private const string XML_deceasedTime = "deceasedTime";
        private const string XML_ethnicGroupCode = "ethnicGroupCode";
        private const string XML_gPPractice = "gPPractice";
        private const string XML_pCTOfRegistration = "pCTOfRegistration";
        private const string XML_pCTOfResidence = "pCTOfResidence";
        private const string XML_overseasVisitorStatus = "overseasVisitorStatus";
        private const string XML_extension = "extension";
        private const string XML_root = "root";
        private const string LB = "<";
        private const string RB = ">";

		#endregion

		#region Fields

        private ErrorLog mErrorLog;                     // Error log
        private AuditLog mAuditLog;                     // Audit Log
        private DatabaseHelper mDB;                     // Database helper

        private string mDeleteFlag;                     // Delete flag 
        private DateTime mCreatedDate;                  // Created date
        private DateTime mModifiedDate;                 // Modified date
        private string mID1;                            // Patient ID 1
        private string mID1root;                        // Root of ID 1 value - should always be NHS number    
        private string mID2;                            // Patient ID 2
        private string mID2root;                        // Root of ID 2 value
        private string mPostcode;                       // Postcode
        private PersonName mName;                       // Name
        private string mGender;                         // Gender
        private DateTime mDOB;                          // Date of birth
        private DateTime mDOD;                          // Date of death
        private string mEthnicGroup;                    // Ethnic group
        private GPPractice mGP;                         // GP
        private PCTOfRegistration mPCTReg;              // PCT of registration
        private PCTOfResidence mPCTRes;                 // PCT of residence
        private string mVisitorStatus;                  // Overseas visitor status
        private string XML_COCT_TP000018GB01_PMIContent;

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public PMIContent()
		{
            mCreatedDate = new DateTime();
            mModifiedDate = new DateTime();
            mName = new PersonName();
            mDOB = new DateTime();
            mDOD = new DateTime();
            mGP = new GPPractice();
            mPCTReg = new PCTOfRegistration();
            mPCTRes = new PCTOfResidence();
			Clear();
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// Audit Log
        /// </summary>
        public AuditLog Audit
        {
            get
            {
                return mAuditLog;
            }

            set
            {
                mAuditLog = value;
            }
        }

        /// <summary>
        /// Database Helper
        /// </summary>
        public DatabaseHelper Database
        {
            get
            {
                return mDB;
            }

            set
            {
                mDB = value;
            }
        }

        /// <summary>
        /// Delete Flag
        /// </summary>
        public string DeleteFlag
        {
            get
            {
                return mDeleteFlag;
            }
        }

        /// <summary>
        /// Created date
        /// </summary>
        public DateTime CreatedDate
        {
            get
            {
                return mCreatedDate;
            }
        }

        /// <summary>
        /// Modified date
        /// </summary>
        public DateTime ModifiedDate
        {
            get
            {
                return mModifiedDate;
            }
        }

        /// <summary>
        /// ID1
        /// </summary>
        public string ID1
        {
            get
            {
                return mID1;
            }
        }

        /// <summary>
        /// ID1 Root
        /// </summary>
        public string ID1Root
        {
            get
            {
                return mID1root;
            }
        }

        /// <summary>
        /// ID2
        /// </summary>
        public string ID2
        {
            get
            {
                return mID2;
            }
        }

        /// <summary>
        /// ID2 Root
        /// </summary>
        public string ID2Root
        {
            get
            {
                return mID2root;
            }
        }

        /// <summary>
        /// Postcode
        /// </summary>
        public string Postcode
        {
            get
            {
                return mPostcode;
            }
        }

        /// <summary>
        /// Patient name
        /// </summary>
        public PersonName PatientName
        {
            get
            {
                return mName;
            }
        }

        /// <summary>
        /// Gender
        /// </summary>
        public string Gender
        {
            get
            {
                return mGender;
            }
        }

        /// <summary>
        /// DOB
        /// </summary>
        public DateTime DOB
        {
            get
            {
                return mDOB;
            }
        }

        /// <summary>
        /// DOD
        /// </summary>
        public DateTime DOD
        {
            get
            {
                return mDOD;
            }
        }

        /// <summary>
        /// Ethnic group
        /// </summary>
        public string EthnicGroup
        {
            get
            {
                return mEthnicGroup;
            }
        }

        /// <summary>
        /// GP
        /// </summary>
        public GPPractice GP
        {
            get
            {
                return mGP;
            }
        }

        /// <summary>
        /// PCT of registration
        /// </summary>
        public PCTOfRegistration PCTReg
        {
            get
            {
                return mPCTReg;
            }
        }

        /// <summary>
        /// PCT of residence
        /// </summary>
        public PCTOfResidence PCTRes
        {
            get
            {
                return mPCTRes;
            }
        }

        /// <summary>
        /// Overseas visitor status
        /// </summary>
        public string VisitorStatus
        {
            get
            {
                return mVisitorStatus;
            }
        }

        #endregion

		#region Methods

        /// <summary>
        /// Clears field values to default values.
        /// </summary>
        public void Clear()
        {
            mDeleteFlag = "";
            mCreatedDate = DateTime.MinValue;
            mModifiedDate = DateTime.MinValue;
            mID1 = "";
            mID1root = "";
            mID2 = "";
            mID2root = "";
            mPostcode = "";
            mName.Clear();
            mGender = "";
            mDOB = DateTime.MinValue;
            mDOD = DateTime.MinValue;
            mEthnicGroup = "";
            mGP.Clear();
            mPCTReg.Clear();
            mPCTRes.Clear();
            mVisitorStatus = "";  
        }
        
		/// <summary>
        /// Read in PMIContent from an XML stream.
        /// If an error is encountered return false.
		/// </summary>
		/// <param name="reader">XML input stream.</param>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="EncounterID">Encounter identity.</param>
		public bool ReadXML(XmlReader reader, string XMLFile, string EncounterID)
		{
            // Setup element name checker
            ElementNameChecker x = new ElementNameChecker();
            x.Error = mErrorLog;
            x.XMLFile = XMLFile;

            try
            {
                // On <COCT_TP000018GB01.PMIContent> start element RC1 OR
                // On <COCT_TP000018GB02.PMIContent> start element RC2
                // To provide backward compatibility dont check 
                XML_COCT_TP000018GB01_PMIContent = reader.LocalName;

                // <templateId> element
                reader.Read();
                if (!x.Check(reader, XML_templateId)) return (false);

                // <id> element
                reader.Read();
                if (!x.Check(reader, XML_id)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // <component1> start element
                reader.Read();
                if (!x.Check(reader, XML_component1)) return (false);

                // <templateId> element
                reader.Read();
                if (!x.Check(reader, XML_templateId)) return (false);

                // <deleteFlag> element
                reader.Read();
                if (!x.Check(reader, XML_deleteFlag)) return (false);

                // <templateId> element
                reader.Read();
                if (!x.Check(reader, XML_templateId)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // <value> element
                reader.Read();
                if (!x.Check(reader, XML_value)) return (false);

                // value attribute
                mDeleteFlag = reader.GetAttribute(XML_value);

                // skip to next element
                reader.Skip();

                // <deleteFlag> end element
                if (!x.Check(reader, XML_deleteFlag)) return (false);
                
                // <component1> end element
                reader.Read();
                if (!x.Check(reader, XML_component1)) return (false);

                // <component2> start element
                reader.Read();
                if (!x.Check(reader, XML_component2)) return (false);

                // <templateId> element
                reader.Read();
                if (!x.Check(reader, XML_templateId)) return (false);

                // <createdDate> element
                reader.Read();
                if (!x.Check(reader, XML_createdDate)) return (false);

                // <templateId> element
                reader.Read();
                if (!x.Check(reader, XML_templateId)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // <value> element
                reader.Read();
                if (!x.Check(reader, XML_value)) return (false);

                // value attribute
                string s = reader.GetAttribute(XML_value);
                if (!mDB.HL7DataTime(s, out mCreatedDate))
                {
                    x.InvalidDateTime(reader, XML_value, " <" + XML_COCT_TP000018GB01_PMIContent + "> ... <createdDate>", s);
                    return false;
                }

                // skip to next element
                reader.Skip();

                // <createdDate> end element
                if (!x.Check(reader, XML_createdDate)) return (false);
                
                // <component2> end element
                reader.Read();
                if (!x.Check(reader, XML_component2)) return (false);

                // Move to next element
                reader.Read();

                // Check if <component3> start element
                if (reader.LocalName == XML_component3)
                {
                    // <templateId> element
                    reader.Read();
                    if (!x.Check(reader, XML_templateId)) return (false);

                    // <modifiedDate> element
                    reader.Read();
                    if (!x.Check(reader, XML_modifiedDate)) return (false);
                        
                    // <templateId> element
                    reader.Read();
                    if (!x.Check(reader, XML_templateId)) return (false);

                    // <code> element
                    reader.Read();
                    if (!x.Check(reader, XML_code)) return (false);

                    // <value> element
                    reader.Read();
                    if (!x.Check(reader, XML_value)) return (false);

                    // value attribute
                    s = reader.GetAttribute(XML_value);
                    if (!mDB.HL7DataTime(s, out mModifiedDate))
                    {
                        x.InvalidDateTime(reader, XML_value, " <" + XML_COCT_TP000018GB01_PMIContent + "> ... <modifiedDate>", s);
                        return (false);
                    }

                    // skip to next element
                    reader.Skip();

                    // <modifiedDate> end element
                    if (!x.Check(reader, XML_modifiedDate)) return (false);
                        
                    // <component3> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component3)) return (false);
                    
                    // Move to next element
                    reader.Read();
                }

                // On <subject> start element
                if (!x.Check(reader, XML_subject)) return (false);

                // <templateId> element
                reader.Read();
                if (!x.Check(reader, XML_templateId)) return (false);

                // <patient> element
                reader.Read();
                if (!x.Check(reader, XML_patient)) return (false);

                // <templateId> element
                reader.Read();
                if (!x.Check(reader, XML_templateId)) return (false);

                // <id> element
                reader.Read();
                if (!x.Check(reader, XML_id)) return (false);

                // extension attribute
                mID1 = reader.GetAttribute(XML_extension);

                // root attribute
                mID1root = reader.GetAttribute(XML_root);

                // Move to next element
                reader.Read();

                // Check if <id> element
                if (reader.LocalName == XML_id)
                {
                    // extension attribute
                    mID2 = reader.GetAttribute(XML_extension);

                    // root attribute
                    mID2root = reader.GetAttribute(XML_root);

                    // Move to next element
                    reader.Read();
                }

                // Check if <addr> element
                if (reader.LocalName == XML_addr)
                {
                    // <postalCode> start element
                    reader.Read();
                    if (!x.Check(reader, XML_postalCode)) return (false);

                    // Element contents if not empty
                    if (!reader.IsEmptyElement)
                    {
                        mPostcode = reader.ReadElementContentAsString();
                    }
                    else
                    {
                        // Skip to next element
                        reader.Skip();
                    }

                    // <addr> end element
                    if (!x.Check(reader, XML_addr)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // On <patientPerson> start element
                if (!x.Check(reader, XML_patientPerson)) return (false);

                // <templateId> element
                reader.Read();
                if (!x.Check(reader, XML_templateId)) return (false);

                // <name> start element
                reader.Read();
                if (!x.Check(reader, XML_name)) return (false);

                // Read persons name
                mName.Audit = mAuditLog;
                mName.Error = mErrorLog;
                if (!mName.ReadXML(reader, XMLFile, EncounterID)) return (false);

                // Check if <administrativeGenderCode> element
                if (reader.LocalName == XML_administrativeGenderCode)
                {
                    // code attribute
                    mGender = reader.GetAttribute(XML_code);

                    // skip to next element
                    reader.Skip();
                }

                // <birthTime> element
                if (!x.Check(reader, XML_birthTime)) return (false);

                // value attribute
                s = reader.GetAttribute(XML_value);
                if (!mDB.HL7DataTime(s, out mDOB))
                {
                    x.InvalidDateTime(reader, XML_birthTime, LB + XML_COCT_TP000018GB01_PMIContent + RB, s);
                    return (false);
                }

                // skip to next element
                reader.Skip();

                // Check if <deceasedTime> element
                if (reader.LocalName == XML_deceasedTime)
                {
                    // value attribute
                    s = reader.GetAttribute(XML_value);
                    if (!mDB.HL7DataTime(s, out mDOD))
                    {
                        x.InvalidDateTime(reader, XML_deceasedTime, LB + XML_COCT_TP000018GB01_PMIContent + RB, s);
                        return (false);
                    }

                    // skip to next element
                    reader.Skip();
                }

                // Check if <ethnicGroupCode> element
                if (reader.LocalName == XML_ethnicGroupCode)
                {
                    // code attribute
                    mEthnicGroup = reader.GetAttribute(XML_code);

                    // skip to next element
                    reader.Skip();
                }

                // Check if <gPPractice> element
                if (reader.LocalName == XML_gPPractice)
                {
                    // Read GP
                    mGP.Audit = mAuditLog;
                    mGP.Error = mErrorLog;
                    if (!mGP.ReadXML(reader, XMLFile)) return (false);
                }

                // Check if <pCTOfRegistration> element
                if (reader.LocalName == XML_pCTOfRegistration)
                {
                    // Read PCT
                    mPCTReg.Audit = mAuditLog;
                    mPCTReg.Error = mErrorLog;
                    if (!mPCTReg.ReadXML(reader, XMLFile)) return (false);
                }

                // Check if <pCTOfResidence> element
                if (reader.LocalName == XML_pCTOfResidence)
                {
                    // Read PCT
                    mPCTRes.Audit = mAuditLog;
                    mPCTRes.Error = mErrorLog;
                    if (!mPCTRes.ReadXML(reader, XMLFile)) return (false);
                }

                // On <patientPerson> end element
                if (!x.Check(reader, XML_patientPerson)) return (false);

                // Move to next element
                reader.Read();

                // Check if <subject> element
                if (reader.LocalName == XML_subject)
                {
                    // <templateId> element
                    reader.Read();
                    if (!x.Check(reader, XML_templateId)) return (false);

                    // <overseasVisitorStatus> start element
                    reader.Read();
                    if (!x.Check(reader, XML_overseasVisitorStatus)) return (false);

                    // <templateId> element
                    reader.Read();
                    if (!x.Check(reader, XML_templateId)) return (false);

                    // <code> element
                    reader.Read();
                    if (!x.Check(reader, XML_code)) return (false);


                    // <value> start element
                    reader.Read();
                    if (!x.Check(reader, XML_value)) return (false);

                    // code attribute
                     mVisitorStatus = reader.GetAttribute(XML_code);

                    // skip to next element
                    reader.Skip();

                    // <overseasVisitorStatus> end element
                    if (!x.Check(reader, XML_overseasVisitorStatus)) return (false);

                    // <subject> end element
                    reader.Read();
                    if (!x.Check(reader, XML_subject)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // On <patient> end element
                if (!x.Check(reader, XML_patient)) return (false);
                
                // <subject> end element
                reader.Read();
                if (!x.Check(reader, XML_subject)) return (false);

                // On <COCT_TP000018GB01.PMIContent> end element RC1 OR
                // On <COCT_TP000018GB02.PMIContent> end element RC2
                // To provide backward compatibility dont check 
                reader.Read();

                // Move to next element
                reader.Read();

                return true;
            }
            catch (XmlException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
            catch (XmlSchemaValidationException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
		}

		#endregion
    }
}
