﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Data;
using System.Data.SqlClient;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		Investigation
    // Description:	An investigation.
    //
    // History:
    // 28 Oct 2011	1.00	MAK Initial version
    // 12 Mar 2012  2.00    MAK Updated

    /// <summary>
    /// Investigation represents an investigation. 
    /// </summary>
    public class Investigation
    {
        #region Constants

        private const string XML_component25 = "component25";
        private const string XML_component24 = "component24";
        private const string XML_investigations = "investigations";
        private const string XML_investigation = "investigation";
        private const string XML_code = "code";
        private const string XML_text = "text";
        private const string XML_value = "value";
        private const string XML_codeSystem = "codeSystem";

		#endregion

		#region Fields

        private ErrorLog mErrorLog;                     // Error log
        private AuditLog mAuditLog;                     // Audit Log
        private DatabaseHelper mDB;                     // Database helper

        private string mInvestigation_text;             // A string representing the investigation. 
        private string mInvestigation_value;            // A code which indicates the investigation.
        private string mInvestigation_codesystem;       // The associated code system.

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public Investigation()
		{
			Clear();
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// Audit Log
        /// </summary>
        public AuditLog Audit
        {
            get
            {
                return mAuditLog;
            }

            set
            {
                mAuditLog = value;
            }
        }

        /// <summary>
        /// Database Helper
        /// </summary>
        public DatabaseHelper Database
        {
            get
            {
                return mDB;
            }

            set
            {
                mDB = value;
            }
        }

        /// <summary>
        /// Investigation Text
        /// </summary>
        public string InvestigationText
        {
            get
            {
                return mInvestigation_text;
            }
        }

        /// <summary>
        /// Investigation Value
        /// </summary>
        public string InvestigationValue
        {
            get
            {
                return mInvestigation_value;
            }
        }

        /// <summary>
        /// Investigation Code System
        /// </summary>
        public string InvestigationCodeSystem
        {
            get
            {
                return mInvestigation_codesystem;
            }
        }

        #endregion

		#region Methods

        /// <summary>
        /// Clears field values to default values.
        /// </summary>
        public void Clear()
        {
            mInvestigation_text = "";
            mInvestigation_value = "";
            mInvestigation_codesystem = "";
        }
        
		/// <summary>
        /// Read in Investigation from an XML stream.
        /// If an error is encountered return false.
		/// </summary>
		/// <param name="reader">XML input stream.</param>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="FeedType">Feed type.</param>
        public bool ReadXML(XmlReader reader, string XMLFile, DistributionEnvelope.FEEDTYPE FeedType)
		{
            // Setup element name checker
            ElementNameChecker x = new ElementNameChecker();
            x.Error = mErrorLog;
            x.XMLFile = XMLFile;

            string ComponentTAG = "";
            string InvestigationTAG = "";

            // Set tags dependent on feed type
            switch (FeedType)
            {
                case DistributionEnvelope.FEEDTYPE.OOHWIC:
                    ComponentTAG = XML_component25;
                    InvestigationTAG = XML_investigations;
                    break;

                case DistributionEnvelope.FEEDTYPE.AE:
                    ComponentTAG = XML_component24;
                    InvestigationTAG = XML_investigation;
                    break;
            }

            try
            {
                // On component start elelemt
                if (!x.Check(reader, ComponentTAG)) return (false);

                // investigation start element
                reader.Read();
                if (!x.Check(reader, InvestigationTAG)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // Move to next element
                reader.Read();

                // Check if <text> start element
                if (reader.LocalName == XML_text)
                {
                    // Element contents if not empty
                    if (!reader.IsEmptyElement)
                    {
                        mInvestigation_text = reader.ReadElementContentAsString();
                    }
                    else
                    {
                        // Skip to next element
                        reader.Skip();
                    }
                }

                // Check if <value> start element
                if (reader.LocalName == XML_value)
                {
                    // code attribute
                    mInvestigation_value = reader.GetAttribute(XML_code);

                    // codeSystem attribute
                    mInvestigation_codesystem = reader.GetAttribute(XML_codeSystem);

                    // Skip to next element
                    reader.Skip();
                }

                // On investigation end element
                if (!x.Check(reader, InvestigationTAG)) return (false);

                // component end element
                reader.Read();
                if (!x.Check(reader, ComponentTAG)) return (false);

                // Move to next element
                reader.Read();
 
                return true;
            }
            catch (XmlException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
            catch (XmlSchemaValidationException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
		}

        /// <summary>
        /// Insert the investigation into database
        /// If an error is encountered return false.
        /// </summary>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="TrackingID">Tracking identifer.</param>
        /// <param name="FeedID">Feed identifier.</param>
        /// <param name="InvestigationID">Investigation identifier.</param>
        public bool Insert(string XMLFile, string TrackingID, int FeedID, int InvestigationID)
        {

            string myCmd = "INSERT INTO investigations (trackingid, feedid, investigationid, investigationtext, investigationvalue, investigationcodesystem) VALUES (" +
                "'" + mDB.Munge(TrackingID) + "'," +
                FeedID + "," +
                InvestigationID + ",'" +
                mDB.Munge(mInvestigation_text) + "','" +
                mDB.Munge(mInvestigation_value) + "','" +
                mDB.Munge(mInvestigation_codesystem) +
                "')";

            SqlCommand myCommand = new SqlCommand(myCmd, mDB.SQLConnection);
            myCommand.CommandType = CommandType.Text;

            try
            {
                // INSERT could throw an exception
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog("XML File: " + XMLFile + " INSERT INTO investigations error: " + e.Message);
                return (false);
            }

            return (true);
        }

		#endregion
    }
}
