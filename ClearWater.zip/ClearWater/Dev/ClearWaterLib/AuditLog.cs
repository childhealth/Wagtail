﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		AuditLog
    // Description:	Class to manage audit logging
    //
    // History:
    // 25 Oct 2011	1.00	MAK Initial version

    /// <summary>
    /// Class to manage audit logging
    /// </summary>
    public class AuditLog
    {
        #region Constants

        private const string NEWLINE = "\r\n";

        #endregion

        #region Fields

        private bool mEnabled;          // Audit logging enabled.
        private string mAuditLogFile;   // Audit Log file.

        #endregion

        #region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
		public AuditLog()
		{
			mEnabled = false;
            mAuditLogFile = "";
		}

		#endregion

        #region Properties

        /// <summary>
        /// Audit log enabled
        /// </summary>
        public bool Enabled
        {
            get
            {
                return mEnabled;
            }

            set
            {
                mEnabled = value;
            }
        }

        /// <summary>
        /// Audit log File
        /// </summary>
        public string AuditLogFile
        {
            get
            {
                return mAuditLogFile;
            }

            set
            {
                mAuditLogFile = value;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Write message to log. 
        /// </summary>
        /// <param name="message">Message.</param>
        public void WriteLog(string message)
        {
            if (mEnabled)
            {
                File.AppendAllText(mAuditLogFile, DateTime.Now.ToString() + ": " + message + NEWLINE);
            }
        }

        #endregion
    }
}
