﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:        DatabaseHelper
    // Description: Helpfull class to access and use database
    //
    // History:
    // 25 October 2011 1.0 MAK Initial version

    /// <summary>
    /// DatabaseHelper is a utility class that is used by other classes to access the database.
    /// </summary>
    public class DatabaseHelper
    {
        #region Constants

        /// <summary>
        /// Date/time format for SQL Server insert
        /// </summary>
        public const string DTFORMAT = "yyyyMMdd HH:mm:ss";

        #endregion

        #region Fields

        private string mDatabaseConnection;     // Database connection string
        private SqlConnection mSQLConnection;   // Database connection to Microsoft SQL database

        #endregion

        #region Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        public DatabaseHelper()
        {
            mDatabaseConnection = "";
            mSQLConnection = null;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Database connection string
        /// </summary>
        public string DatabaseConnection
        {
            get
            {
                return mDatabaseConnection;
            }

            set
            {
                mDatabaseConnection = value;
            }
        }

        /// <summary>
        /// Get the database connection to the SQL database.
        /// </summary>
        public SqlConnection SQLConnection
        {
            get
            {
                return mSQLConnection;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Opens the database.
        /// </summary>
        public void OpenDB()
        {
            mSQLConnection = new SqlConnection(mDatabaseConnection);
            mSQLConnection.Open();
        }

        /// <summary>
        /// Closes the database.
        /// </summary>
        public void CloseDB()
        {
            mSQLConnection.Close();
        }

        /// <summary>
        /// Munge apostrophes so SQL insert works correctly.
        /// Returns munged string.
        /// </summary>
        /// <param name="sql">SQL string to munge.</param>
        public string Munge(string sql)
        {
            if (sql == null)
            {
                return ("");
            }
            else
            {
                return (sql.Replace("'", "''"));
            }
        }

        /// <summary>
        /// Convert HL7 datatime value to .NET datetime value.
        /// If invalid format returns false.
        /// </summary>
        /// <param name="hl7">HL7 datetime string.</param>
        /// <param name="dt">.NET DateTime.</param>
        public bool HL7DataTime(string hl7, out DateTime dt)
        {
            int year = 0;
            int month = 0;
            int day = 0;
            int hour = 0;
            int min = 0;
            int sec = 0;
            bool ok = true;

            if (hl7.Length >= 8)
            {
                if (!int.TryParse(hl7.Substring(0, 4), out year)) ok = false;
                if (!int.TryParse(hl7.Substring(4, 2), out month)) ok = false;
                if (!int.TryParse(hl7.Substring(6, 2), out day)) ok = false;
            }
            if (hl7.Length >= 14)
            {
                if (!int.TryParse(hl7.Substring(8, 2), out hour)) ok = false;
                if (!int.TryParse(hl7.Substring(10, 2), out min)) ok = false;
                if (!int.TryParse(hl7.Substring(12, 2), out sec)) ok = false;
            }

            if (ok && hl7.Length >= 8)
            {
                dt = new DateTime(year, month, day, hour, min, sec);
            }
            else
            {
                // This is the minimum datetime value
                dt = DateTime.MinValue;
            }

            return (ok);
        }

        #endregion
    }
}
