﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		XmlSchema
    // Description:	Cache XML schemas
    //
    // History:
    // 26 Oct 2011	1.00	MAK Initial version

    /// <summary>
    /// Class to cache XML schemas
    /// </summary>
    public class XMLSchema
    {
		#region Fields

        private string mXSDFolder;      // Folder that contains XSD
		private XmlSchemaSet mSchemas;	// XSD collection

		#endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
		public XMLSchema()
		{
			mSchemas = new XmlSchemaSet();
		}

		#endregion

		#region Properties

        /// <summary>
        /// XSD Folder
        /// </summary>
        public string XSDFolder
        {
            get
            {
                return mXSDFolder;
            }

            set
            {
                mXSDFolder = value;
            }
        }

		/// <summary>
		/// XSD collection.
		/// </summary>
		public XmlSchemaSet XmlSchemas
		{
			get
			{
				return mSchemas;
			}
		}

		#endregion

        #region Methods

        /// <summary>
        /// Load XSD
        /// Can throw exception.
        /// </summary>
        public void LoadXSD()
        {
            // Add in XSD
            // TO DO - better way would be just load all XSD files in folder
            mSchemas.Add(null, mXSDFolder + "\\distributionEnvelope-v2-0.xsd");
            mSchemas.Add(null, mXSDFolder + "\\COCT_TP000018GB01.xsd");
            mSchemas.Add(null, mXSDFolder + "\\COMT_MT000019GB01.xsd");
            mSchemas.Add(null, mXSDFolder + "\\COMT_MT000020GB01.xsd");
            mSchemas.Add(null, mXSDFolder + "\\COMT_MT000023GB01.xsd");
            mSchemas.Add(null, mXSDFolder + "\\voc.xsd");
            mSchemas.Add(null, mXSDFolder + "\\commonInclude.xsd");
            mSchemas.Add(null, mXSDFolder + "\\datatypeflavours.xsd");
            mSchemas.Add(null, mXSDFolder + "\\datatypes.xsd");
            mSchemas.Add(null, mXSDFolder + "\\datatypes-2005.xsd");
            mSchemas.Add(null, mXSDFolder + "\\infrastructureRoot.xsd");
            mSchemas.Add(null, mXSDFolder + "\\NarrativeBlock.xsd");
            mSchemas.Add(null, mXSDFolder + "\\NHSLocalisation.xsd");
            mSchemas.Add(null, mXSDFolder + "\\NHSVocab.xsd");
            mSchemas.Add(null, mXSDFolder + "\\TemplateConfig.xsd");
            mSchemas.Add(null, mXSDFolder + "\\xhtmlNPfIT.xsd");
            mSchemas.Add(null, mXSDFolder + "\\xhtmlNPfITPresentationText.xsd");
            mSchemas.Add(null, mXSDFolder + "\\NPFIT-100007_Act.xsd");

            // Disable resolution of include elements
            mSchemas.XmlResolver = null;

            // Compile
            mSchemas.Compile();
        }

        #endregion
    }
}
