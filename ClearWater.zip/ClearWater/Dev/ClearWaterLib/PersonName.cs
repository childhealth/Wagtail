﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		PersonName
    // Description:	A persons name.
    //
    // History:
    // 29 Oct 2011	1.00	MAK Initial version
    // 12 Mar 2012  2.00    MAK Updated

    /// <summary>
    /// PersonName represents a persons name. 
    /// </summary>
    public class PersonName
    {
        #region Constants

        private const string XML_name = "name";
        private const string XML_family = "family";
        private const string XML_given = "given";
        private const string XML_prefix = "prefix";
        private const string XML_suffix = "suffix";
        private const string XML_use = "use";
        private const string CONTAINER = "from Encounter ID = ";

		#endregion

		#region Fields

        private ErrorLog mErrorLog;                     // Error log
        private AuditLog mAuditLog;                     // Audit Log

        private string mFamily;                         // Family name
        private string mGiven;                          // Given name
        private string mPrefix;                         // Prefix to name
        private string mSuffix;                         // Suffix to name
        private string mUse;                            // Use for name

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public PersonName()
		{
			Clear();
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// Audit Log
        /// </summary>
        public AuditLog Audit
        {
            get
            {
                return mAuditLog;
            }

            set
            {
                mAuditLog = value;
            }
        }

        /// <summary>
        /// Family name
        /// </summary>
        public string Family
        {
            get
            {
                return mFamily;
            }
        }

        /// <summary>
        /// Given name
        /// </summary>
        public string Given
        {
            get
            {
                return mGiven;
            }
        }

        /// <summary>
        /// Prefix to name
        /// </summary>
        public string Prefix
        {
            get
            {
                return mPrefix;
            }
        }

        /// <summary>
        /// Suffix to name
        /// </summary>
        public string Suffix
        {
            get
            {
                return mSuffix;
            }
        }

        /// <summary>
        /// Use for name
        /// </summary>
        public string Use
        {
            get
            {
                return mUse;
            }
        }

        #endregion

		#region Methods

        /// <summary>
        /// Clears field values to default values.
        /// </summary>
        public void Clear()
        {
            mFamily = "";
            mGiven = "";
            mPrefix = "";
            mSuffix = "";
            mUse = "";
        }
        
		/// <summary>
        /// Read in persons name from an XML stream.
        /// If an error is encountered return false.
		/// </summary>
		/// <param name="reader">XML input stream.</param>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="EncounterID">Encounter identity.</param>
		public bool ReadXML(XmlReader reader, string XMLFile, string EncounterID)
		{
            // Setup element name checker
            ElementNameChecker x = new ElementNameChecker();
            x.Error = mErrorLog;
            x.XMLFile = XMLFile;

            try
            {
                // Assume on <name> start elelemt
                if (!x.Check(reader, XML_name)) return (false);

                // use attribute
                mUse = reader.GetAttribute(XML_use);

                // Move to next element
                reader.Read();

                // Process inner XML
                while (reader.LocalName != XML_name && !reader.EOF)
                {
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_name, "End", CONTAINER + EncounterID);
                        return false;
                    }

                    switch (reader.LocalName)
                    {
                        case XML_family:
                            // Element contents if not empty
                            if (!reader.IsEmptyElement)
                            {
                                mFamily = reader.ReadElementContentAsString();
                            }
                            else
                            {
                                // Skip to next element
                                reader.Skip();
                            }
                            break;

                        case XML_given:
                            // Element contents if not empty
                            if (!reader.IsEmptyElement)
                            {
                                mGiven = reader.ReadElementContentAsString();
                            }
                            else
                            {
                                // Skip to next element
                                reader.Skip();
                            }
                            break;

                        case XML_prefix:
                            // Element contents if not empty
                            if (!reader.IsEmptyElement)
                            {
                                mPrefix = reader.ReadElementContentAsString();
                            }
                            else
                            {
                                // Skip to next element
                                reader.Skip();
                            }
                            break;

                        case XML_suffix:
                            // Element contents if not empty
                            if (!reader.IsEmptyElement)
                            {
                                mSuffix = reader.ReadElementContentAsString();
                            }
                            else
                            {
                                // Skip to next element
                                reader.Skip();
                            }
                            break;

                        default:
                            break;
                    }
                }

                // On <name> end element
                if (!x.Check(reader, XML_name)) return (false);

                // Move to next element
                reader.Read();
 
                return true;
            }
            catch (XmlException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
            catch (XmlSchemaValidationException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
		}

		#endregion
    }
}
