﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Data;
using System.Data.SqlClient;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		AEFeed
    // Description:	Accident & Emergency Feed 
    //
    // History:
    // 27 Oct 2011	1.00	MAK Initial version
    // 06 Feb 2012  2.00    MAK Updated
    // 12 Mar 2012  3.00    MAK Updated

    /// <summary>
    /// AEFeed represents an Accident and Emergency Feed. 
    /// </summary>
    public class AEFeed
    {
        #region Constants

        private const string XML_AEFeed = "AEFeed";
        private const string XML_effectiveTime = "effectiveTime";
        private const string XML_value = "value";
        private const string XML_createdDate = "createdDate";
        private const string XML_component = "component";
        private const string XML_component1 = "component1";
        private const string XML_modifiedDate = "modifiedDate";
        private const string XML_component10 = "component10";
        private const string XML_dischargeSummaryStatus = "dischargeSummaryStatus";
        private const string XML_component11 = "component11";
        private const string XML_arrivalMode = "arrivalMode";
        private const string XML_component12 = "component12";
        private const string XML_referralSource = "referralSource";
        private const string XML_component13 = "component13";
        private const string XML_attendanceCategory = "attendanceCategory";
        private const string XML_component14 = "component14";
        private const string XML_aEDepartmentType = "aEDepartmentType";
        private const string XML_component15 = "component15";
        private const string XML_deleteFlag = "deleteFlag";
        private const string XML_component16 = "component16";
        private const string XML_component19 = "component19";
        private const string XML_dischargeDateTime = "dischargeDateTime";
        private const string XML_component22 = "component22";
        private const string XML_firstSeenDateTime = "firstSeenDateTime";
        private const string XML_component23 = "component23";
        private const string XML_component24 = "component24";
        private const string XML_component26 = "component26";
        private const string XML_component27 = "component27";
        private const string XML_contentId = "contentId";
        private const string XML_COCT_TP000018GB01_PMIContent = "COCT_TP000018GB01.PMIContent";
        private const string XML_component28 = "component28";
        private const string XML_incidentLocationType = "incidentLocationType";
        private const string XML_component29 = "component29";
        private const string XML_aEPatientGroup = "aEPatientGroup";
        private const string XML_component30 = "component30";
        private const string XML_ambulanceData = "ambulanceData";
        private const string XML_ambulanceCrew = "ambulanceCrew";
        private const string XML_ambulanceStation = "ambulanceStation";
        private const string XML_code = "code";
        private const string XML_component31 = "component31";
        private const string XML_component5 = "component5";
        private const string XML_primaryDiagnosis = "primaryDiagnosis";
        private const string XML_component6 = "component6";
        private const string XML_initialTriageCategory = "initialTriageCategory";
        private const string XML_component8 = "component8";
        private const string XML_disposalMethod = "disposalMethod";
        private const string XML_performer = "performer";
        private const string XML_clinician = "clinician";
        private const string XML_id = "id";
        private const string XML_agentClinicianPerson = "agentClinicianPerson";
        private const string XML_name = "name";
        private const string XML_performer1 = "performer1";
        private const string XML_serviceOrganisation = "serviceOrganisation";
        private const string XML_locationServiceOrganisationDetails = "locationServiceOrganisationDetails";
        private const string XML_subject1 = "subject1";
        private const string XML_sourceOrganisation = "sourceOrganisation";
        private const string XML_locationOrganization = "locationOrganization";
        private const string XML_subject2 = "subject2";
        private const string XML_destinationOrganisation = "destinationOrganisation";
        private const string XML_extension = "extension";
        private const string XML_root = "root";
        private const string XML_codeSystem = "codeSystem";
        private const string XML_displayName = "displayName";
        private const string LB = "<";
        private const string RB = ">";
        private const string CONTAINER = "from Encounter ID = ";
        private const string XML_text = "text";
        private const string XML_component34 = "component34";
        private const string XML_caseNumber = "caseNumber";
        private const string XML_low = "low";
        private const string XML_high = "high";

		#endregion

		#region Fields

        private ErrorLog mErrorLog;                                     // Error log
        private AuditLog mAuditLog;                                     // Audit Log
        private DatabaseHelper mDB;                                     // Database helper
        private string mEncounter_id;                                   // Encounter id.
        private string mEncounter_root;                                 // Root of encounter id.
        private DateTime mEffectiveTime;			                    // Effective time low
        private DateTime mCreatedDate;                                  // This indicates the time at which the A&E record was created. 
        private DateTime mModifiedDate;                                 // This indicates the time at which the A&E record was modified. 
        private string mDischargeSummaryStatus;                         // The value of the observation is the code used to identify the discharge summary status.
        private string mArrivalMode;                                    // The value of the observation is the code used to identify the arrival mode
        private string mArrivalMode_codesystem;
        private string mArrivalMode_displayname;
        private string mReferralSource;                                 // The value of the observation is the code used to identify the referral source.
        private string mReferralSource_codesystem;
        private string mReferralSource_displayname;
        private string mAttendanceCategory;                             // The value of the observation is the code used to identify the attendance category.
        private string mAttendanceCategory_codesystem;
        private string mAttendanceCategory_displayname;
        private string mAEDepartmentType;                               // The value of the observation is the code used to identify the department type.
        private string mDeleteFlag;                                     // A value of true indicates that the record should be deleted. A value of false indicates that the record should not be deleted. 
        private List<PresentingComplaint> mPresentingComplaints;        // List of presenting complaints. 
        private DateTime mDischargeDateTime;                            // Date and time of the discharge.
        private DateTime mFirstSeenDateTime;                            // Date and time first seen.
        private List<Treatment> mTreatments;                            // List of treatments. 
        private List<Investigation> mInvestigations;                    // List of investigations. 
        private List<PrescribedItem> mPrescribedItems;                  // List of prescribed items.
        private PMIContent mPatient;                                    // Patient.
        private string mIncidentLocationType;                           // Incident location type.
        private string mIncidentLocationType_codesystem;
        private string mIncidentLocationType_displayname;
        private string mAEPatientGroup;                                 // A&E patient group.
        private string mAEPatientGroup_codesystem;
        private string mAEPatientGroup_displayname;
        private string mAmbulanceCaseNumber;                            // Ambulance case number.
        private string mAmbulanceCrew;                                  // Ambulance crew.
        private string mAmbulanceStation;                               // Ambulance station.
        private List<SecondaryDiagnosis> mSecondaryDiagnoses;           // List of secondary diagnoses.
        private string mPrimaryDiagnosis;                               // Primary diagnosis.
        private string mPrimaryDiagnosis_codesystem;
        private string mPrimaryDiagnosis_displayname;
        private string mPrimaryDiagnosis_description;
        private string mInitialTriageCategory;                          // Initial Triage Category.
        private string mDisposalMethod;                                 // Disposal Method.
        private string mDisposalMethod_codesystem;
        private string mDisposalMethod_displayname;
        private string mClinician_id1;                                  // Clinician ID1.
        private string mClinician_id1root;
        private string mClinician_id2;                                  // Clinician ID2.
        private string mClinician_id2root;
        private PersonName mClinician_name;                             // Clinician's name.
        private string mServiceOrg_id;                                  // Service organisation id.
        private string mServiceOrg_root;
        private string mServiceOrg_name;                                // Service organisation name.
        private string mSourceOrg_id;                                   // Source organisation id.
        private string mSourceOrg_root;
        private string mSourceOrg_name;                                 // Source organisation name.
        private string mDestinationOrg_id;                              // Destination organisation id.
        private string mDestinationOrg_root;
        private string mDestinationOrg_name;                            // Destination organisation name.
        private DateTime mEffectiveTime_high;
        private string mCaseNumber;                                     // Case number
        private DateTime mCaseEffectiveTime_low;			            // The date/time at which the case occurred or was planned to occur.
        private DateTime mCaseEffectiveTime_high;                       // The date/time at which the case occurred or was planned to occur.

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public AEFeed()
		{
            mEffectiveTime = new DateTime();
            mCreatedDate = new DateTime();
            mModifiedDate = new DateTime();
            mPresentingComplaints = new List<PresentingComplaint>();
            mDischargeDateTime = new DateTime();
            mFirstSeenDateTime = new DateTime(); 
            mTreatments = new List<Treatment>();
            mInvestigations = new List<Investigation>();
            mPrescribedItems = new List<PrescribedItem>();
            mPatient = new PMIContent();
            mSecondaryDiagnoses = new List<SecondaryDiagnosis>();
            mClinician_name = new PersonName();
            mEffectiveTime_high = new DateTime();
            mCaseEffectiveTime_low = new DateTime();
            mCaseEffectiveTime_high = new DateTime();
			Clear();
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// Audit Log
        /// </summary>
        public AuditLog Audit
        {
            get
            {
                return mAuditLog;
            }

            set
            {
                mAuditLog = value;
            }
        }

        /// <summary>
        /// Database Helper
        /// </summary>
        public DatabaseHelper Database
        {
            get
            {
                return mDB;
            }

            set
            {
                mDB = value;
            }
        }

        /// <summary>
        /// Encounter ID
        /// </summary>
        public string EncounterID
        {
            get
            {
                return mEncounter_id;
            }
        }

        /// <summary>
        /// Encounter Root
        /// </summary>
        public string EncounterRoot
        {
            get
            {
                return mEncounter_root;
            }
        }

        /// <summary>
        /// Effective time
        /// </summary>
        public DateTime EffectiveTime
        {
            get
            {
                return mEffectiveTime;
            }
        }

        /// <summary>
        /// Effective time high
        /// </summary>
        public DateTime EffectiveTimeHigh
        {
            get
            {
                return mEffectiveTime_high;
            }
        }

        /// <summary>
        /// Case Effective Time Low
        /// </summary>
        public DateTime CaseEffectiveTimeLow
        {
            get
            {
                return mCaseEffectiveTime_low;
            }
        }

        /// <summary>
        /// Case effective time high
        /// </summary>
        public DateTime CaseEffectiveTimeHigh
        {
            get
            {
                return mCaseEffectiveTime_high;
            }
        }

        /// <summary>
        /// Case number
        /// </summary>
        public string CaseNumber
        {
            get
            {
                return mCaseNumber;
            }
        }

        /// <summary>
        /// Created date
        /// </summary>
        public DateTime CreatedDate
        {
            get
            {
                return mCreatedDate;
            }
        }

        /// <summary>
        /// Modified date
        /// </summary>
        public DateTime ModifiedDate
        {
            get
            {
                return mModifiedDate;
            }
        }

        /// <summary>
        /// Discharge Summary Status
        /// </summary>
        public string DischargeSummaryStatus
        {
            get
            {
                return mDischargeSummaryStatus;
            }
        }

        /// <summary>
        /// Arrival mode
        /// </summary>
        public string ArrivalMode
        {
            get
            {
                return mArrivalMode;
            }
        }

        /// <summary>
        /// Arrival mode code system
        /// </summary>
        public string ArrivalModeCodeSystem
        {
            get
            {
                return mArrivalMode_codesystem;
            }
        }

        /// <summary>
        /// Arrival mode display name
        /// </summary>
        public string ArrivalModeDisplayName
        {
            get
            {
                return mArrivalMode_displayname;
            }
        }

        /// <summary>
        /// Referral source
        /// </summary>
        public string ReferralSource
        {
            get
            {
                return mReferralSource;
            }
        }

        /// <summary>
        /// Referral source code system
        /// </summary>
        public string ReferralSourceCodeSystem
        {
            get
            {
                return mReferralSource_codesystem;
            }
        }

        /// <summary>
        /// Referral source display name
        /// </summary>
        public string ReferralSourceDisplayName
        {
            get
            {
                return mReferralSource_displayname;
            }
        }

        /// <summary>
        /// Attendence category
        /// </summary>
        public string AttendanceCategory
        {
            get
            {
                return mAttendanceCategory;
            }
        }

        /// <summary>
        /// Attendence category code system
        /// </summary>
        public string AttendanceCategoryCodeSystem
        {
            get
            {
                return mAttendanceCategory_codesystem;
            }
        }

        /// <summary>
        /// Attendence category display name
        /// </summary>
        public string AttendanceCategoryDisplayName
        {
            get
            {
                return mAttendanceCategory_displayname;
            }
        }

        /// <summary>
        /// A and E Department type
        /// </summary>
        public string AEDepartmentType
        {
            get
            {
                return mAEDepartmentType;
            }
        }

        /// <summary>
        /// Delete flag
        /// </summary>
        public string DeleteFlag
        {
            get
            {
                return mDeleteFlag;
            }
        }

        /// <summary>
        /// List of presenting complaint
        /// </summary>
        public List<PresentingComplaint> PresentingComplaints
        {
            get
            {
                return mPresentingComplaints;
            }
        }

        /// <summary>
        /// Discharge date and time
        /// </summary>
        public DateTime DischargeDateTime
        {
            get
            {
                return mDischargeDateTime;
            }
        }

        /// <summary>
        /// First seen date and time
        /// </summary>
        public DateTime FirstSeenDateTime
        {
            get
            {
                return mFirstSeenDateTime;
            }
        }

        /// <summary>
        /// List of treatments
        /// </summary>
        public List<Treatment> Treatments
        {
            get
            {
                return mTreatments;
            }
        }

        /// <summary>
        /// List of investigations
        /// </summary>
        public List<Investigation> Investigations
        {
            get
            {
                return mInvestigations;
            }
        }

        /// <summary>
        /// List of prescribed items
        /// </summary>
        public List<PrescribedItem> PrescribedItems
        {
            get
            {
                return mPrescribedItems;
            }
        }

        /// <summary>
        /// Patient
        /// </summary>
        public PMIContent Patient
        {
            get
            {
                return mPatient;
            }
        }

        /// <summary>
        /// Incident location type
        /// </summary>
        public string IncidentLocationType
        {
            get
            {
                return mIncidentLocationType;
            }
        }

        /// <summary>
        /// Incident location type code system
        /// </summary>
        public string IncidentLocationTypeCodeSystem
        {
            get
            {
                return mIncidentLocationType_codesystem;
            }
        }

        /// <summary>
        /// Incident location type display name
        /// </summary>
        public string IncidentLocationTypeDisplayName
        {
            get
            {
                return mIncidentLocationType_displayname;
            }
        }

        /// <summary>
        /// A and E patient group
        /// </summary>
        public string AEPatientGroup
        {
            get
            {
                return mAEPatientGroup;
            }
        }

        /// <summary>
        /// A and E patient group code system
        /// </summary>
        public string AEPatientGroupCodeSystem
        {
            get
            {
                return mAEPatientGroup_codesystem;
            }
        }

        /// <summary>
        /// A and E patient group display name
        /// </summary>
        public string AEPatientGroupDisplayName
        {
            get
            {
                return mAEPatientGroup_displayname;
            }
        }

        /// <summary>
        /// Ambulance Case Number
        /// </summary>
        public string AmbulanceCaseNumber
        {
            get
            {
                return mAmbulanceCaseNumber;
            }
        }

        /// <summary>
        /// Ambulance Crew
        /// </summary>
        public string AmbulanceCrew
        {
            get
            {
                return mAmbulanceCrew;
            }
        }

        /// <summary>
        /// Ambulance Station
        /// </summary>
        public string AmbulanceStation
        {
            get
            {
                return mAmbulanceStation;
            }
        }

        /// <summary>
        /// List of Secondary Diagnoses
        /// </summary>
        public List<SecondaryDiagnosis> SecondaryDiagnoses
        {
            get
            {
                return mSecondaryDiagnoses;
            }
        }

        /// <summary>
        /// Primary Diagnosis
        /// </summary>
        public string PrimaryDiagnosis
        {
            get
            {
                return mPrimaryDiagnosis;
            }
        }

        /// <summary>
        /// Primary Diagnosis code system
        /// </summary>
        public string PrimaryDiagnosisCodeSystem
        {
            get
            {
                return mPrimaryDiagnosis_codesystem;
            }
        }

        /// <summary>
        /// Primary Diagnosis display name
        /// </summary>
        public string PrimaryDiagnosisDisplayName
        {
            get
            {
                return mPrimaryDiagnosis_displayname;
            }
        }

        /// <summary>
        /// Primary Diagnosis description
        /// </summary>
        public string PrimaryDiagnosisDescription
        {
            get
            {
                return mPrimaryDiagnosis_description;
            }
        }

        /// <summary>
        /// Initial Triage Category
        /// </summary>
        public string InitialTriageCategory
        {
            get
            {
                return mInitialTriageCategory;
            }
        }

        /// <summary>
        /// Disposal Method
        /// </summary>
        public string DisposalMethod
        {
            get
            {
                return mDisposalMethod;
            }
        }

        /// <summary>
        /// Disposal Method code system
        /// </summary>
        public string DisposalMethodCodeSystem
        {
            get
            {
                return mDisposalMethod_codesystem;
            }
        }

        /// <summary>
        /// Disposal Method display name
        /// </summary>
        public string DisposalMethodDisplayName
        {
            get
            {
                return mDisposalMethod_displayname;
            }
        }

        /// <summary>
        /// Clinician ID1
        /// </summary>
        public string ClinicianID1
        {
            get
            {
                return mClinician_id1;
            }
        }

        /// <summary>
        /// Clinician ID1 Root
        /// </summary>
        public string ClinicianID1Root
        {
            get
            {
                return mClinician_id1root;
            }
        }

        /// <summary>
        /// Clinician ID2
        /// </summary>
        public string ClinicianID2
        {
            get
            {
                return mClinician_id2;
            }
        }

        /// <summary>
        /// Clinician ID2 Root
        /// </summary>
        public string ClinicianID2Root
        {
            get
            {
                return mClinician_id2root;
            }
        }

        /// <summary>
        /// Clinician's name
        /// </summary>
        public PersonName ClinicianName
        {
            get
            {
                return mClinician_name;
            }
        }

        /// <summary>
        /// Service organisation id
        /// </summary>
        public string ServiceOrgID
        {
            get
            {
                return mServiceOrg_id;
            }
        }

        /// <summary>
        /// Service organisation root
        /// </summary>
        public string ServiceOrgRoot
        {
            get
            {
                return mServiceOrg_root;
            }
        }

        /// <summary>
        /// Service organisation name
        /// </summary>
        public string ServiceOrgName
        {
            get
            {
                return mServiceOrg_name;
            }
        }

        /// <summary>
        /// Source organisation id
        /// </summary>
        public string SourceOrgID
        {
            get
            {
                return mSourceOrg_id;
            }
        }

        /// <summary>
        /// Source organisation root
        /// </summary>
        public string SourceOrgRoot
        {
            get
            {
                return mSourceOrg_root;
            }
        }

        /// <summary>
        /// Source organisation name
        /// </summary>
        public string SourceOrgName
        {
            get
            {
                return mSourceOrg_name;
            }
        }

        /// <summary>
        /// Destination organisation id
        /// </summary>
        public string DestinationOrgID
        {
            get
            {
                return mDestinationOrg_id;
            }
        }

        /// <summary>
        /// Destination organisation root
        /// </summary>
        public string DestinationOrgRoot
        {
            get
            {
                return mDestinationOrg_root;
            }
        }

        /// <summary>
        /// Destination organisation name
        /// </summary>
        public string DestinationOrgName
        {
            get
            {
                return mDestinationOrg_name;
            }
        }

        #endregion

		#region Methods

        /// <summary>
        /// Clears field values to default values.
        /// </summary>
        public void Clear()
        {
            mEncounter_id = "";
            mEncounter_root = "";
            mEffectiveTime = DateTime.MinValue;
            mEffectiveTime_high = DateTime.MinValue;
            mCaseNumber = "";
            mCaseEffectiveTime_low = DateTime.MinValue;
            mCaseEffectiveTime_high = DateTime.MinValue;
            mCreatedDate = DateTime.MinValue;
            mModifiedDate = DateTime.MinValue;
            mDischargeSummaryStatus = "";
            mArrivalMode = "";
            mArrivalMode_codesystem = "";
            mArrivalMode_displayname = "";
            mReferralSource = "";
            mReferralSource_codesystem = "";
            mReferralSource_displayname = "";
            mAttendanceCategory = "";
            mAttendanceCategory_codesystem = "";
            mAttendanceCategory_displayname = "";
            mAEDepartmentType = "";
            mDeleteFlag = "";
            mPresentingComplaints.Clear();
            mDischargeDateTime = DateTime.MinValue;
            mFirstSeenDateTime = DateTime.MinValue;
            mTreatments.Clear();
            mInvestigations.Clear();
            mPrescribedItems.Clear();
            mPatient.Clear();
            mIncidentLocationType = "";
            mIncidentLocationType_codesystem = "";
            mIncidentLocationType_displayname = "";
            mAEPatientGroup = "";
            mAEPatientGroup_codesystem = "";
            mAEPatientGroup_displayname = "";
            mAmbulanceCaseNumber = "";
            mAmbulanceCrew = "";
            mAmbulanceStation = "";
            mSecondaryDiagnoses.Clear();
            mPrimaryDiagnosis = "";
            mPrimaryDiagnosis_codesystem = "";
            mPrimaryDiagnosis_displayname = "";
            mPrimaryDiagnosis_description = "";
            mInitialTriageCategory = "";
            mDisposalMethod = "";
            mDisposalMethod_codesystem = "";
            mDisposalMethod_displayname = "";
            mClinician_id1 = "";
            mClinician_id1root = "";
            mClinician_id2 = "";
            mClinician_id2root = "";
            mClinician_name.Clear();
            mServiceOrg_id = "";
            mServiceOrg_root = "";
            mServiceOrg_name = "";
            mSourceOrg_id = "";
            mSourceOrg_root = "";
            mSourceOrg_name = "";
            mDestinationOrg_id = "";
            mDestinationOrg_root = "";
            mDestinationOrg_name = "";
        }
        
		/// <summary>
        /// Read in AEFeed from an XML stream.
        /// If an error is encountered return false.
		/// </summary>
		/// <param name="reader">XML input stream.</param>
        /// <param name="XMLFile">Name of XML file.</param>
		public bool ReadXML(XmlReader reader, string XMLFile)
		{
            // Setup element name checker
            ElementNameChecker x = new ElementNameChecker();
            x.Error = mErrorLog;
            x.XMLFile = XMLFile;
            string s;

            try
            {
                // Assume on <AEFeed> start element
                if (!x.Check(reader, XML_AEFeed)) return (false);

                // Skip to <id> element
                while (reader.LocalName != XML_id && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_id, LB + XML_AEFeed + RB, "");
                    return false;
                }

                // extension attribute
                mEncounter_id = reader.GetAttribute(XML_extension);

                // root attribute
                mEncounter_root = reader.GetAttribute(XML_root);

                // Skip to <effectveTime> element
                while (reader.LocalName != XML_effectiveTime && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_effectiveTime, LB + XML_AEFeed + RB, CONTAINER + mEncounter_id);
                    return false;
                }

                // check if has value attribute
                if (reader.MoveToAttribute(XML_value))
                {
                    // If it has then RC1, RC2 or RC3 version - get single value effectivetime
                    s = reader.GetAttribute(XML_value);
                    if (!mDB.HL7DataTime(s, out mEffectiveTime))
                    {
                        x.InvalidDateTime(reader, XML_effectiveTime, LB + XML_AEFeed + RB, s);
                        return false;
                    }

                    // skip to next element
                    reader.Skip();
                }
                else
                {
                    // If it hasent then RC4 version - get low and high effectivetime
                    // <low> element
                    reader.Read();
                    if (!x.Check(reader, XML_low)) return (false);

                    // value attribute
                    s = reader.GetAttribute(XML_value);
                    if (!mDB.HL7DataTime(s, out mEffectiveTime))
                    {
                        x.InvalidDateTime(reader, XML_low, LB + XML_effectiveTime + RB, s);
                        return false;
                    }

                    // skip to next element
                    reader.Skip();

                    // <high> element
                    if (!x.Check(reader, XML_high)) return (false);

                    // value attribute
                    s = reader.GetAttribute(XML_value);
                    if (!mDB.HL7DataTime(s, out mEffectiveTime_high))
                    {
                        x.InvalidDateTime(reader, XML_high, LB + XML_effectiveTime + RB, s);
                        return false;
                    }

                }

                // Skip to <value> element in <createdDate> in element <component>
                while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_value, LB + XML_createdDate + RB, CONTAINER + mEncounter_id);
                    return false;
                }

                // value attribute
                s = reader.GetAttribute(XML_value);
                if (!mDB.HL7DataTime(s, out mCreatedDate))
                {
                    x.InvalidDateTime(reader, XML_value, LB + XML_createdDate + RB, s);
                    return false;
                }

                // Skip to next element
                reader.Skip();

                // Skip to <value> element in <modifiedDate> in element <component1>
                while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_value, LB + XML_modifiedDate + RB, CONTAINER + mEncounter_id);
                    return false;
                }

                // value attribute
                s = reader.GetAttribute(XML_value);
                if (!mDB.HL7DataTime(s, out mModifiedDate))
                {
                    x.InvalidDateTime(reader, XML_value, LB + XML_modifiedDate + RB, s);
                    return false;
                }

                // Skip to next element
                reader.Skip();

                // <modifiedDate> end element
                if (!x.Check(reader, XML_modifiedDate)) return (false);

                //  <component1> end element
                reader.Read();
                if (!x.Check(reader, XML_component1)) return (false);

                // Move to next element
                reader.Read();

                // Check if we have a <component10> element
                if (reader.LocalName == XML_component10)
                {
                    // skip to <value> element in <dischargeSummaryStatus>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_dischargeSummaryStatus + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // code attribute
                    mDischargeSummaryStatus = reader.GetAttribute(XML_code);

                    // Skip to next element
                    reader.Skip();

                    // <dischargeSummaryStatus> end element
                    if (!x.Check(reader, XML_dischargeSummaryStatus)) return (false);

                    //  <component10> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component10)) return (false);

                    // Move to next element
                    reader.Read();
                }
               

                // Check if we have a <component11> element
                if (reader.LocalName == XML_component11)
                {
                    // skip to <value> element in <arrivalMode>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_arrivalMode + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // code attribute
                    mArrivalMode = reader.GetAttribute(XML_code);

                    // codeSystem attribute
                    mArrivalMode_codesystem = reader.GetAttribute(XML_codeSystem);

                    // displayName attribute
                    mArrivalMode_displayname = reader.GetAttribute(XML_displayName);

                    // Skip to next element
                    reader.Skip();

                    // <arrivalMode> end element
                    if (!x.Check(reader, XML_arrivalMode)) return (false);

                    //  <component11> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component11)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <component12> element
                if (reader.LocalName == XML_component12)
                {
                    // skip to <value> element in <referralSource>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_referralSource + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // code attribute
                    mReferralSource = reader.GetAttribute(XML_code);

                    // codeSystem attribute
                    mReferralSource_codesystem = reader.GetAttribute(XML_codeSystem);

                    // displayName attribute
                    mReferralSource_displayname = reader.GetAttribute(XML_displayName);

                    // Skip to next element
                    reader.Skip();

                    // <referralSource> end element
                    if (!x.Check(reader, XML_referralSource)) return (false);

                    //  <component12> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component12)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <component13> element
                if (reader.LocalName == XML_component13)
                {
                    // skip to <value> element in <attendanceCategory>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_attendanceCategory + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // code attribute
                    mAttendanceCategory = reader.GetAttribute(XML_code);

                    // codeSystem attribute
                    mAttendanceCategory_codesystem = reader.GetAttribute(XML_codeSystem);

                    // displayName attribute
                    mAttendanceCategory_displayname = reader.GetAttribute(XML_displayName);

                    // Skip to next element
                    reader.Skip();

                    // <attendanceCategory> end element
                    if (!x.Check(reader, XML_attendanceCategory)) return (false);

                    //  <component13> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component13)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <component14> element
                if (reader.LocalName == XML_component14)
                {
                    // skip to <value> element in <aEDepartmentType>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_aEDepartmentType + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // code attribute
                    mAEDepartmentType = reader.GetAttribute(XML_code);

                    // Skip to next element
                    reader.Skip();

                    // <aEDepartmentType> end element
                    if (!x.Check(reader, XML_aEDepartmentType)) return (false);

                    //  <component14> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component14)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <component15> element
                if (reader.LocalName == XML_component15)
                {
                    // skip to <value> element in <deleteFlag>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_deleteFlag + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // value attribute
                    mDeleteFlag = reader.GetAttribute(XML_value);

                    // Skip to next element
                    reader.Skip();

                    // <deleteFlag> end element
                    if (!x.Check(reader, XML_deleteFlag)) return (false);

                    //  <component15> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component15)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // There can be 0 .. n <component16> elements
                while (reader.LocalName == XML_component16)
                {
                    PresentingComplaint mComplaint = new PresentingComplaint();
                    mComplaint.Audit = mAuditLog;
                    mComplaint.Error = mErrorLog;
                    mComplaint.Database = mDB;
                    if (mComplaint.ReadXML(reader, XMLFile, DistributionEnvelope.FEEDTYPE.AE))
                    {
                        mPresentingComplaints.Add(mComplaint);
                    }
                    else
                    {
                        return false;
                    }
                }

                // Check if we have a <component19> element
                if (reader.LocalName == XML_component19)
                {
                    // Skip to <value> element in <dischargeDateTime> in element <component19>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_dischargeDateTime + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // value attribute
                    s = reader.GetAttribute(XML_value);
                    if (!mDB.HL7DataTime(s, out mDischargeDateTime))
                    {
                        x.InvalidDateTime(reader, XML_value, LB + XML_dischargeDateTime + RB, s);
                        return false;
                    }

                    // Skip to next element
                    reader.Skip();

                    // <dischargeDateTime> end element
                    if (!x.Check(reader, XML_dischargeDateTime)) return (false);

                    //  <component19> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component19)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <component22> element
                if (reader.LocalName == XML_component22)
                {
                    // Skip to <value> element in <firstSeenDateTime> in element <component22>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_firstSeenDateTime + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // value attribute
                    s = reader.GetAttribute(XML_value);
                    if (!mDB.HL7DataTime(s, out mFirstSeenDateTime))
                    {
                        x.InvalidDateTime(reader, XML_value, LB + XML_firstSeenDateTime + RB, s);
                        return false;
                    }

                    // Skip to next element
                    reader.Skip();

                    // <firstSeenDateTime> end element
                    if (!x.Check(reader, XML_firstSeenDateTime)) return (false);

                    //  <component22> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component22)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // There can be 0 .. n <component23> elements
                while (reader.LocalName == XML_component23)
                {
                    Treatment mTreatment = new Treatment();
                    mTreatment.Audit = mAuditLog;
                    mTreatment.Error = mErrorLog;
                    mTreatment.Database = mDB;
                    if (mTreatment.ReadXML(reader, XMLFile))
                    {
                        mTreatments.Add(mTreatment);
                    }
                    else
                    {
                        return false;
                    }
                }

                // There can be 0 .. n <component24> elements
                while (reader.LocalName == XML_component24)
                {
                    Investigation mInvest = new Investigation();
                    mInvest.Audit = mAuditLog;
                    mInvest.Error = mErrorLog;
                    mInvest.Database = mDB;
                    if (mInvest.ReadXML(reader, XMLFile, DistributionEnvelope.FEEDTYPE.AE))
                    {
                        mInvestigations.Add(mInvest);
                    }
                    else
                    {
                        return false;
                    }
                }

                // There can be 0 .. n <component26> elements
                while (reader.LocalName == XML_component26)
                {
                    PrescribedItem mItem = new PrescribedItem();
                    mItem.Audit = mAuditLog;
                    mItem.Error = mErrorLog;
                    mItem.Database = mDB;
                    if (mItem.ReadXML(reader, XMLFile, DistributionEnvelope.FEEDTYPE.AE, mEncounter_id))
                    {
                        mPrescribedItems.Add(mItem);
                    }
                    else
                    {
                        return false;
                    }
                }

                // <component27> start element
                if (!x.Check(reader, XML_component27)) return (false);

                // <contentId> element
                reader.Read();
                if (!x.Check(reader, XML_contentId)) return (false);

                // <COCT_TP000018GB01.PMIContent> start element RC1 OR
                // <COCT_TP000018GB02.PMIContent> start element RC2
                // To provide backward compatibility dont check 
                reader.Read();

                mPatient.Audit = mAuditLog;
                mPatient.Error = mErrorLog;
                mPatient.Database = mDB;
                if (!mPatient.ReadXML(reader, XMLFile, mEncounter_id)) return (false);

                // On <component27> end element
                if (!x.Check(reader, XML_component27)) return (false);

                // Move on to next element
                reader.Read();

                // Check if we have a <component28> element
                if (reader.LocalName == XML_component28)
                {
                    // skip to <value> element in <incidentLocationType>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_incidentLocationType + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // code attribute
                    mIncidentLocationType = reader.GetAttribute(XML_code);

                    // codeSystem attribute
                    mIncidentLocationType_codesystem = reader.GetAttribute(XML_codeSystem);

                    // displayName attribute
                    mIncidentLocationType_displayname = reader.GetAttribute(XML_displayName);

                    // Skip to next element
                    reader.Skip();

                    // <incidentLocationType> end element
                    if (!x.Check(reader, XML_incidentLocationType)) return (false);

                    //  <component28> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component28)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <component29> element
                if (reader.LocalName == XML_component29)
                {
                    // skip to <value> element in <aEPatientGroup>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_aEPatientGroup + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // code attribute
                    mAEPatientGroup = reader.GetAttribute(XML_code);

                    // codeSystem attribute
                    mAEPatientGroup_codesystem = reader.GetAttribute(XML_codeSystem);

                    // displayName attribute
                    mAEPatientGroup_displayname = reader.GetAttribute(XML_displayName);

                    // Skip to next element
                    reader.Skip();

                    // <aEPatientGroup> end element
                    if (!x.Check(reader, XML_aEPatientGroup)) return (false);

                    //  <component29> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component29)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <component30> element
                if (reader.LocalName == XML_component30)
                {
                    // <ambulanceData> start element
                    reader.Read();
                    if (!x.Check(reader, XML_ambulanceData)) return (false);

                    // <code> element
                    reader.Read();
                    if (!x.Check(reader, XML_code)) return (false);

                    // Move to next element
                    reader.Read();

                    // Check if <value> start element
                    if (reader.LocalName == XML_value)
                    {
                        // Element contents if not empty
                        if (!reader.IsEmptyElement)
                        {
                            mAmbulanceCaseNumber = reader.ReadElementContentAsString();
                        }
                        else
                        {
                            // Skip to next element
                            reader.Skip();
                        }
                    }

                    // Check if <component> start element
                    if (reader.LocalName == XML_component)
                    {
                        // skip to <value> element in <ambulanceCrew>
                        while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                        if (reader.EOF)
                        {
                            x.Missing(reader, XML_value, LB + XML_ambulanceData + RB + LB + XML_ambulanceCrew + RB, CONTAINER + mEncounter_id);
                            return false;
                        }

                        // Element contents if not empty
                        if (!reader.IsEmptyElement)
                        {
                            mAmbulanceCrew = reader.ReadElementContentAsString();
                        }
                        else
                        {
                            // Skip to next element
                            reader.Skip();
                        }

                        // <ambulanceCrew> end element
                        if (!x.Check(reader, XML_ambulanceCrew)) return (false);

                        // <component> end element
                        reader.Read();
                        if (!x.Check(reader, XML_component)) return (false);

                        // Move to next element
                        reader.Read();
                    }

                    // Check if <component1> start element
                    if (reader.LocalName == XML_component1)
                    {
                        // skip to <value> element in <ambulanceStation>
                        while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                        if (reader.EOF)
                        {
                            x.Missing(reader, XML_value, LB + XML_ambulanceData + RB + LB + XML_ambulanceStation + RB, CONTAINER + mEncounter_id);
                            return false;
                        }

                        // Element contents if not empty
                        if (!reader.IsEmptyElement)
                        {
                            mAmbulanceStation = reader.ReadElementContentAsString();
                        }
                        else
                        {
                            // Skip to next element
                            reader.Skip();
                        }

                        // <ambulanceStation> end element
                        if (!x.Check(reader, XML_ambulanceStation)) return (false);

                        // <component1> end element
                        reader.Read();
                        if (!x.Check(reader, XML_component1)) return (false);

                        // Move to next element
                        reader.Read();
                    }

                    // <ambulanceData> end element
                    if (!x.Check(reader, XML_ambulanceData)) return (false);

                    // <component30> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component30)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // There can be 0 .. n <component31> elements
                while (reader.LocalName == XML_component31)
                {
                    SecondaryDiagnosis mDiagnosis = new SecondaryDiagnosis();
                    mDiagnosis.Audit = mAuditLog;
                    mDiagnosis.Error = mErrorLog;
                    mDiagnosis.Database = mDB;
                    if (mDiagnosis.ReadXML(reader, XMLFile))
                    {
                        mSecondaryDiagnoses.Add(mDiagnosis);
                    }
                    else
                    {
                        return false;
                    }
                }

                // Check if we have a <component34> element
                if (reader.LocalName == XML_component34)
                {
                    // <caseNumber> element
                    reader.Read();
                    if (!x.Check(reader, XML_caseNumber)) return (false);

                    // <code> element
                    reader.Read();
                    if (!x.Check(reader, XML_code)) return (false);

                    // Read next element
                    reader.Read();

                    // Check if we have a <effectiveTime> element
                    if (reader.LocalName == XML_effectiveTime)
                    {
                        // <low> element
                        reader.Read();
                        if (!x.Check(reader, XML_low)) return (false);

                        // value attribute
                        s = reader.GetAttribute(XML_value);
                        if (!mDB.HL7DataTime(s, out mCaseEffectiveTime_low))
                        {
                            x.InvalidDateTime(reader, XML_low, LB + XML_effectiveTime + RB, s);
                            return false;
                        }

                        // skip to next element
                        reader.Skip();

                        // <high> element
                        if (!x.Check(reader, XML_high)) return (false);

                        // value attribute
                        s = reader.GetAttribute(XML_value);
                        if (!mDB.HL7DataTime(s, out mCaseEffectiveTime_high))
                        {
                            x.InvalidDateTime(reader, XML_high, LB + XML_effectiveTime + RB, s);
                            return false;
                        }

                        // skip to next element
                        reader.Skip();

                        // <effectiveTime> end element
                        if (!x.Check(reader, XML_effectiveTime)) return (false);

                        // Read next element
                        reader.Read();
                    }

                    // <value> element
                    if (!x.Check(reader, XML_value)) return (false);

                    // extension attribute
                    mCaseNumber = reader.GetAttribute(XML_extension);

                    // skip to next element
                    reader.Skip();

                    // <caseNumber> end element
                    if (!x.Check(reader, XML_caseNumber)) return (false);

                    // <component34> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component34)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <component5> element
                if (reader.LocalName == XML_component5)
                {
                    // <primaryDiagnosis> start element
                    reader.Read();
                    if (!x.Check(reader, XML_primaryDiagnosis)) return (false);

                    // <code> element
                    reader.Read();
                    if (!x.Check(reader, XML_code)) return (false);

                    // Move to next element
                    reader.Read();

                    // Check if we have an <text> element - optional to be backward compatible with RC1
                    if (reader.LocalName == XML_text)
                    {
                        // Element contents if not empty
                        if (!reader.IsEmptyElement)
                        {
                            mPrimaryDiagnosis_description = reader.ReadElementContentAsString();
                        }
                        else
                        {
                            // Skip to next element
                            reader.Skip();
                        }
                    }

                    // <value> element
                    if (!x.Check(reader, XML_value)) return (false);

                    // code attribute
                    mPrimaryDiagnosis = reader.GetAttribute(XML_code);

                    // codeSystem attribute
                    mPrimaryDiagnosis_codesystem = reader.GetAttribute(XML_codeSystem);

                    // displayName attribute
                    mPrimaryDiagnosis_displayname = reader.GetAttribute(XML_displayName);

                    // Skip to next element
                    reader.Skip();

                    // <primaryDiagnosis> end element
                    if (!x.Check(reader, XML_primaryDiagnosis)) return (false);

                    //  <component5> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component5)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <component6> element
                if (reader.LocalName == XML_component6)
                {
                    // skip to <value> element in <initialTriageCategory>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_initialTriageCategory + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // code attribute
                    mInitialTriageCategory = reader.GetAttribute(XML_code);

                    // Skip to next element
                    reader.Skip();

                    // <initialTriageCategory> end element
                    if (!x.Check(reader, XML_initialTriageCategory)) return (false);

                    //  <component6> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component6)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <component8> element
                if (reader.LocalName == XML_component8)
                {
                    // skip to <value> element in <disposalMethod>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_disposalMethod + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // code attribute
                    mDisposalMethod = reader.GetAttribute(XML_code);

                    // codeSystem attribute
                    mDisposalMethod_codesystem = reader.GetAttribute(XML_codeSystem);

                    // displayName attribute
                    mDisposalMethod_displayname = reader.GetAttribute(XML_displayName);

                    // Skip to next element
                    reader.Skip();

                    // <disposalMethod> end element
                    if (!x.Check(reader, XML_disposalMethod)) return (false);

                    //  <component8> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component8)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <performer> element
                if (reader.LocalName == XML_performer)
                {
                    // <clinician> start element
                    reader.Read();
                    if (!x.Check(reader, XML_clinician)) return (false);

                    // Move to next element
                    reader.Read();

                    // Check if <id> element
                    if (reader.LocalName == XML_id)
                    {
                        // extension attribute
                        mClinician_id1 = reader.GetAttribute(XML_extension);

                        // root attribute
                        mClinician_id1root = reader.GetAttribute(XML_root);

                        // Move to next element
                        reader.Read();
                    }

                    // Check if <id> element
                    if (reader.LocalName == XML_id)
                    {
                        // extension attribute
                        mClinician_id2 = reader.GetAttribute(XML_extension);

                        // extension attribute
                        mClinician_id2root = reader.GetAttribute(XML_root);

                        // Move to next element
                        reader.Read();
                    }

                    // Check if <agentClinicianPerson> element
                    if (reader.LocalName == XML_agentClinicianPerson)
                    {
                        // <name> start element
                        reader.Read();
                        if (!x.Check(reader, XML_name)) return (false);

                        // Read persons name
                        mClinician_name.Audit = mAuditLog;
                        mClinician_name.Error = mErrorLog;
                        if (!mClinician_name.ReadXML(reader, XMLFile, mEncounter_id)) return (false);

                        // <agentClinicianPerson> end element
                        if (!x.Check(reader, XML_agentClinicianPerson)) return (false);

                        //Move to next element
                        reader.Read();
                    }

                    // On <clinician> end element
                    if (!x.Check(reader, XML_clinician)) return (false);

                    // <performer> end element
                    reader.Read();
                    if (!x.Check(reader, XML_performer)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <performer1> element
                if (reader.LocalName == XML_performer1)
                {
                    // <serviceOrganisation> start element
                    reader.Read();
                    if (!x.Check(reader, XML_serviceOrganisation)) return (false);

                    // <code> element
                    reader.Read();
                    if (!x.Check(reader, XML_code)) return (false);

                    // Move to next element
                    reader.Read();

                    // Check if <locationServiceOrganisationDetails> element
                    if (reader.LocalName == XML_locationServiceOrganisationDetails)
                    {
                        // <id> element
                        reader.Read();
                        if (!x.Check(reader, XML_id)) return (false);

                        // extension attribute
                        mServiceOrg_id = reader.GetAttribute(XML_extension);

                        // root attribute
                        mServiceOrg_root = reader.GetAttribute(XML_root);

                        // <name> start element
                        reader.Read();
                        if (!x.Check(reader, XML_name)) return (false);

                        // Element contents if not empty
                        if (!reader.IsEmptyElement)
                        {
                            mServiceOrg_name = reader.ReadElementContentAsString();
                        }
                        else
                        {
                            // Skip to next element
                            reader.Skip();
                        }

                        // <locationServiceOrganisationDetails> end element
                        if (!x.Check(reader, XML_locationServiceOrganisationDetails)) return (false);

                        // Move to next element
                        reader.Read();
                    }

                    // On <serviceOrganisation> end element
                    if (!x.Check(reader, XML_serviceOrganisation)) return (false);

                    // <performer1> end element
                    reader.Read();
                    if (!x.Check(reader, XML_performer1)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // <subject1> start element
                if (!x.Check(reader, XML_subject1)) return (false);

                // <sourceOrganisation> start element
                reader.Read();
                if (!x.Check(reader, XML_sourceOrganisation)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // <locationOrganization> start element
                reader.Read();
                if (!x.Check(reader, XML_locationOrganization)) return (false);

                // <id> element
                reader.Read();
                if (!x.Check(reader, XML_id)) return (false);

                // extension attribute
                mSourceOrg_id = reader.GetAttribute(XML_extension);

                // root attribute
                mSourceOrg_root = reader.GetAttribute(XML_root);

                // <name> start element
                reader.Read();
                if (!x.Check(reader, XML_name)) return (false);

                // Element contents if not empty
                if (!reader.IsEmptyElement)
                {
                    mSourceOrg_name = reader.ReadElementContentAsString();
                }
                else
                {
                    // Skip to next element
                    reader.Skip();
                }

                // <locationOrganization> end element
                if (!x.Check(reader, XML_locationOrganization)) return (false);

                // <sourceOrganisation> end element
                reader.Read();
                if (!x.Check(reader, XML_sourceOrganisation)) return (false);

                // <subject1> end element
                reader.Read();
                if (!x.Check(reader, XML_subject1)) return (false);

                // <subject2> start element
                reader.Read();
                if (!x.Check(reader, XML_subject2)) return (false);

                // <destinationOrganisation> start element
                reader.Read();
                if (!x.Check(reader, XML_destinationOrganisation)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // <locationOrganization> start element
                reader.Read();
                if (!x.Check(reader, XML_locationOrganization)) return (false);

                // <id> element
                reader.Read();
                if (!x.Check(reader, XML_id)) return (false);

                // extension attribute
                mDestinationOrg_id = reader.GetAttribute(XML_extension);

                // root attribute
                mDestinationOrg_root = reader.GetAttribute(XML_root);

                // <name> start element
                reader.Read();
                if (!x.Check(reader, XML_name)) return (false);

                // Element contents if not empty
                if (!reader.IsEmptyElement)
                {
                    mDestinationOrg_name = reader.ReadElementContentAsString();
                }
                else
                {
                    // Skip to next element
                    reader.Skip();
                }

                // <locationOrganization> end element
                if (!x.Check(reader, XML_locationOrganization)) return (false);

                // <destinationOrganisation> end element
                reader.Read();
                if (!x.Check(reader, XML_destinationOrganisation)) return (false);

                // <subject2> end element
                reader.Read();
                if (!x.Check(reader, XML_subject2)) return (false);

                // Skip to <AEFeed> end element
                while (reader.LocalName != XML_AEFeed && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_AEFeed, "End", CONTAINER + mEncounter_id);
                    return false;
                }

                return (true);
            }
            catch (XmlException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
            catch (XmlSchemaValidationException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
		}

        /// <summary>
        /// Insert the AEFeed into database
        /// If an error is encountered return false.
        /// </summary>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="TrackingID">Tracking Identifier.</param>
        /// <param name="FeedID">Feed Identifier.</param>
        public bool Insert(string XMLFile, string TrackingID, int FeedID)
        {
            string myCmd = "INSERT INTO aefeeds (trackingid, feedid, encounterid, encounterroot, effectivetime, createddate, modifieddate, DischargeSummaryStatus, ArrivalMode, ArrivalModeCodeSystem, ArrivalModeDisplayName," +
               "ReferralSource, ReferralSourceCodeSystem, ReferralSourceDisplayName, AttendanceCategory, AttendanceCategoryCodeSystem, AttendanceCategoryDisplayName, AEDepartmentType, DeleteFlag, DischargeDateTime, FirstSeenDateTime, PMI_DeleteFlag, PMI_CreatedDate," +
                "PMI_ModifiedDate, PMI_ID1, PMI_ID1Root, PMI_ID2, PMI_ID2Root, PMI_Postcode, PMI_FamilyName, PMI_GivenName, PMI_NamePrefix, PMI_NameSuffix, PMI_NameUse, PMI_Gender, PMI_DOB," +
                "PMI_DOD, PMI_EthnicGroup, PMI_GP_OrgCode, PMI_GP_OrgName, PMI_PCTReg_OrgCode, PMI_PCTReg_OrgName, PMI_PCTRes_OrgCode, PMI_PCTRes_OrgName," +
                "IncidentLocationType, IncidentLocationTypeCodeSystem, IncidentLocationTypeDisplayName, AEPatientGroup, AEPatientGroupCodeSystem, AEPatientGroupDisplayName, AmbulanceCaseNumber, AmbulanceCrew, AmbulanceStation, PrimaryDiagnosis, PrimaryDiagnosisCodeSystem, PrimaryDiagnosisDisplayName, InitialTriageCategory, " +
                "DisposalMethod, DisposalMethodCodeSystem, DisposalMethodDisplayName, Clinician_ID1, Clinician_ID1Root, Clinician_ID2, Clinician_ID2Root, Clinician_FamilyName, Clinician_GivenName, Clinician_NamePrefix, Clinician_NameSuffix, Clinician_NameUse," +
                "ServiceOrganisationID, ServiceOrganisationRoot, ServiceOrganisationName, SourceOrganisationID, SourceOrganisationRoot, SourceOrganisationName, DestinationOrganisationID, DestinationOrganisationRoot, DestinationOrganisationName, PrimaryDiagnosisDescription, VisitorStatus, EffectiveTimeHigh, CaseNumber, CaseEffectiveTimeLow, CaseEffectiveTimeHigh) VALUES (" +
                "'" + mDB.Munge(TrackingID) + "'," +
                FeedID + ",'" +
                mDB.Munge(mEncounter_id) + "','" +
                mDB.Munge(mEncounter_root) + "'," +
                ((mEffectiveTime == DateTime.MinValue) ? "NULL" : "'" + mEffectiveTime.ToString(DatabaseHelper.DTFORMAT) + "'") + "," +
                ((mCreatedDate == DateTime.MinValue) ? "NULL" : "'" + mCreatedDate.ToString(DatabaseHelper.DTFORMAT) + "'") + "," +
                ((mModifiedDate == DateTime.MinValue) ? "NULL" : "'" + mModifiedDate.ToString(DatabaseHelper.DTFORMAT) + "'") + ",'" +
                mDB.Munge(mDischargeSummaryStatus) + "','" +
                mDB.Munge(mArrivalMode) + "','" +
                mDB.Munge(mArrivalMode_codesystem) + "','" +
                mDB.Munge(mArrivalMode_displayname) + "','" +
                mDB.Munge(mReferralSource) + "','" +
                mDB.Munge(mReferralSource_codesystem) + "','" +
                mDB.Munge(mReferralSource_displayname) + "','" +
                mDB.Munge(mAttendanceCategory) + "','" +
                mDB.Munge(mAttendanceCategory_codesystem) + "','" +
                mDB.Munge(mAttendanceCategory_displayname) + "','" +
                mDB.Munge(mAEDepartmentType) + "','" +
                mDB.Munge(mDeleteFlag) + "'," +
                ((mDischargeDateTime == DateTime.MinValue) ? "NULL" : "'" + mDischargeDateTime.ToString(DatabaseHelper.DTFORMAT) + "'") + "," +
                ((mFirstSeenDateTime == DateTime.MinValue) ? "NULL" : "'" + mFirstSeenDateTime.ToString(DatabaseHelper.DTFORMAT) + "'") + ",'" +
                mDB.Munge(mPatient.DeleteFlag) + "'," +
               ((mPatient.CreatedDate == DateTime.MinValue) ? "NULL" : "'" + mPatient.CreatedDate.ToString(DatabaseHelper.DTFORMAT) + "'") + "," +
                ((mPatient.ModifiedDate == DateTime.MinValue) ? "NULL" : "'" + mPatient.ModifiedDate.ToString(DatabaseHelper.DTFORMAT) + "'") + ",'" +
                mDB.Munge(mPatient.ID1) + "','" +
                mDB.Munge(mPatient.ID1Root) + "','" +
                mDB.Munge(mPatient.ID2) + "','" +
                mDB.Munge(mPatient.ID2Root) + "','" +
                mDB.Munge(mPatient.Postcode) + "','" +
                mDB.Munge(mPatient.PatientName.Family) + "','" +
                mDB.Munge(mPatient.PatientName.Given) + "','" +
                mDB.Munge(mPatient.PatientName.Prefix) + "','" +
                mDB.Munge(mPatient.PatientName.Suffix) + "','" +
                mDB.Munge(mPatient.PatientName.Use) + "','" +
                mDB.Munge(mPatient.Gender) + "'," +
                ((mPatient.DOB == DateTime.MinValue) ? "NULL" : "'" + mPatient.DOB.ToString(DatabaseHelper.DTFORMAT) + "'") + "," +
                ((mPatient.DOD == DateTime.MinValue) ? "NULL" : "'" + mPatient.DOD.ToString(DatabaseHelper.DTFORMAT) + "'") + ",'" +
                mDB.Munge(mPatient.EthnicGroup) + "','" +
                mDB.Munge(mPatient.GP.OrgCode) + "','" +
                mDB.Munge(mPatient.GP.OrgName) + "','" +
                mDB.Munge(mPatient.PCTReg.OrgCode) + "','" +
                mDB.Munge(mPatient.PCTReg.OrgName) + "','" +
                mDB.Munge(mPatient.PCTRes.OrgCode) + "','" +
                mDB.Munge(mPatient.PCTRes.OrgName) + "','" +
                mDB.Munge(mIncidentLocationType) + "','" +
                mDB.Munge(mIncidentLocationType_codesystem) + "','" +
                mDB.Munge(mIncidentLocationType_displayname) + "','" +
                mDB.Munge(mAEPatientGroup) + "','" +
                mDB.Munge(mAEPatientGroup_codesystem) + "','" +
                mDB.Munge(mAEPatientGroup_displayname) + "','" +
                mDB.Munge(mAmbulanceCaseNumber) + "','" +
                mDB.Munge(mAmbulanceCrew) + "','" +
                mDB.Munge(mAmbulanceStation) + "','" +
                mDB.Munge(mPrimaryDiagnosis) + "','" +
                mDB.Munge(mPrimaryDiagnosis_codesystem) + "','" +
                mDB.Munge(mPrimaryDiagnosis_displayname) + "','" +
                mDB.Munge(mInitialTriageCategory) + "','" +
                mDB.Munge(mDisposalMethod) + "','" +
                mDB.Munge(mDisposalMethod_codesystem) + "','" +
                mDB.Munge(mDisposalMethod_displayname) + "','" +
                mDB.Munge(mClinician_id1) + "','" +
                mDB.Munge(mClinician_id1root) + "','" +
                mDB.Munge(mClinician_id2) + "','" +
                mDB.Munge(mClinician_id2root) + "','" +
                mDB.Munge(mClinician_name.Family) + "','" +
                mDB.Munge(mClinician_name.Given) + "','" +
                mDB.Munge(mClinician_name.Prefix) + "','" +
                mDB.Munge(mClinician_name.Suffix) + "','" +
                mDB.Munge(mClinician_name.Use) + "','" +
                mDB.Munge(mServiceOrg_id) + "','" +
                mDB.Munge(mServiceOrg_root) + "','" +
                mDB.Munge(mServiceOrg_name) + "','" +
                mDB.Munge(mSourceOrg_id) + "','" +
                mDB.Munge(mSourceOrg_root) + "','" +
                mDB.Munge(mSourceOrg_name) + "','" +
                mDB.Munge(mDestinationOrg_id) + "','" +
                mDB.Munge(mDestinationOrg_root) + "','" +
                mDB.Munge(mDestinationOrg_name) + "','" +
                mDB.Munge(mPrimaryDiagnosis_description) + "','" +
                mDB.Munge(mPatient.VisitorStatus) + "'," +
                ((mEffectiveTime_high == DateTime.MinValue) ? "NULL" : "'" + mEffectiveTime_high.ToString(DatabaseHelper.DTFORMAT) + "'") + ",'" +
                mDB.Munge(mCaseNumber) + "'," +
                ((mCaseEffectiveTime_low == DateTime.MinValue) ? "NULL" : "'" + mCaseEffectiveTime_low.ToString(DatabaseHelper.DTFORMAT) + "'") + "," +
                ((mCaseEffectiveTime_high == DateTime.MinValue) ? "NULL" : "'" + mCaseEffectiveTime_high.ToString(DatabaseHelper.DTFORMAT) + "'") + 
                ")";

            SqlCommand myCommand = new SqlCommand(myCmd, mDB.SQLConnection);
            myCommand.CommandType = CommandType.Text;

            try
            {
                // INSERT could throw an exception
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog("XML File: " + XMLFile + " INSERT INTO aefeeds error: " + e.Message);
                return (false);
            }


            // If any presenting complaints, insert them into PresentingComplaints table
            for (int i = 0; i < mPresentingComplaints.Count; ++i)
            {
                if (!mPresentingComplaints[i].Insert(XMLFile, TrackingID, FeedID, i + 1)) return (false);
            }

            // If any treatments, insert them into Treatments table
            for (int i = 0; i < mTreatments.Count; ++i)
            {
                if (!mTreatments[i].Insert(XMLFile, TrackingID, FeedID, i + 1)) return (false);
            }

            // If any investigations, insert them into Investigations table
            for (int i = 0; i < mInvestigations.Count; ++i)
            {
                if (!mInvestigations[i].Insert(XMLFile, TrackingID, FeedID, i + 1)) return (false);
            }

            // If any prescribed items, insert them into PrescribedItems table
            for (int i = 0; i < mPrescribedItems.Count; ++i)
            {
                if (!mPrescribedItems[i].Insert(XMLFile, TrackingID, FeedID, i + 1)) return (false);
            }

            // If any secondary diagnoses, insert them into SecondaryDiagnoses table
            for (int i = 0; i < mSecondaryDiagnoses.Count; ++i)
            {
                if (!mSecondaryDiagnoses[i].Insert(XMLFile, TrackingID, FeedID, i + 1)) return (false);
            }

            return (true);
        }

		#endregion
    }
}
