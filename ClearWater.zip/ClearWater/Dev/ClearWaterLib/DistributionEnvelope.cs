﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Data;
using System.Data.SqlClient;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		DistributionEnvelope
	// Description:	ITK Distribution Envelope v2.0
	//
	// History:
	// 25 Oct 2011	1.00	MAK Initial version

	/// <summary>
	/// DistributionEnvelope represents a ITK Distribution Envelope v2.0. 
	/// </summary>
    public class DistributionEnvelope
    {
        #region Types

        /// <summary>
        /// Type of feed
        /// </summary>
        public enum FEEDTYPE
        {
            /// <summary>
            /// Unknown feed type.
            /// </summary>
            UNKNOWN = 0,

            /// <summary>
            /// Out of hours walk in centre feed type.
            /// </summary>
            OOHWIC = 1,

            /// <summary>
            /// Accident and emergency feed type.
            /// </summary>
            AE = 2
        };

        #endregion

        #region Constants

        private const int XML_ERROR = -1;
        private const int DATABASE_ERROR = -2;
        private const int ALREADY_LOADED_ERROR = -3;
        private const int OK = 0;

        private const string XML_xml = "xml";
        private const string XML_DistributionEnvelope = "DistributionEnvelope";
        private const string XML_header = "header";
        private const string XML_manifest = "manifest";
        private const string XML_manifestitem = "manifestitem";
        private const string XML_payloads = "payloads";
        private const string XML_payload = "payload";
        private const string XML_recordCount = "recordCount";
        private const string XML_code = "code";
        private const string XML_value = "value";
        private const string XML_subject = "subject";
        private const string XML_senderAddress = "senderAddress";
        private const string XML_service = "service";
        private const string XML_trackingid = "trackingid";
        private const string XML_count = "count";
        private const string XML_id = "id";
        private const string XML_mimetype = "mimetype";
        private const string XML_profileid = "profileid";
        private const string XML_uri = "uri";

        private const string NEWLINE = "\r\n";
        private const string SENDDATASET = "urn:nhs-itk:services:201005:sendDataSet-v1-0";
        private const string MIMETYPE = "text/xml";

		#endregion

		#region Fields

        private ErrorLog mErrorLog;                 // Error log
        private AuditLog mAuditLog;                 // Audit Log
        private DatabaseHelper mDB;                 // Database helper

        private string mHeader_service;				// The service under which this transmission is sent - xs:anyURI
        private string mHeader_trackingid;          // A unique identifier for this transmission - itk:uuid
        private int mManifest_count;                // A count of the number of payloads being described, should be 1 as a batch message
        private string mManifest_id;                // Manifest id - xs:IDREF
        private string mManifest_mimetype;          // Manifest mime type
        private string mManifest_profileid;         // Manifest profile id
        private string mSenderAddress;              // Sender address
        private int mPayloads_count;                // A count of the number of payloads (must match manifest.count)
        private string mPayload_id;                 // Payload id - xs:ID
        private int mRecordCount;                   // Record count
        private FEEDTYPE mFeedType;                 // Feed type

        private bool mDatabaseInsert;               // Records if any database records have been inserted into any staging tables in the database

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
		public DistributionEnvelope()
		{
			Clear();
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// Audit Log
        /// </summary>
        public AuditLog Audit
        {
            get
            {
                return mAuditLog;
            }

            set
            {
                mAuditLog = value;
            }
        }

        /// <summary>
        /// Database Helper
        /// </summary>
        public DatabaseHelper Database
        {
            get
            {
                return mDB;
            }

            set
            {
                mDB = value;
            }
        }

		/// <summary>
        /// The service under which this transmission is sent.
		/// </summary>
		public string Header_service
		{
			get
			{
				return mHeader_service;
			}

		}

        /// <summary>
        /// A unique identifier for this transmission.
        /// </summary>
        public string Header_trackingid
        {
            get
            {
                return mHeader_trackingid;
            }

        }

        /// <summary>
        /// A count of the number of payloads being described.
        /// </summary>
        public int Manifest_count
        {
            get
            {
                return mManifest_count;
            }

        }

        /// <summary>
        /// Manifest id.
        /// </summary>
        public string ManifestID
        {
            get
            {
                return mManifest_id;
            }

        }

        /// <summary>
        /// Manifest mime type.
        /// </summary>
        public string ManifestMimeType
        {
            get
            {
                return mManifest_mimetype;
            }

        }

        /// <summary>
        /// Manifest profile id
        /// </summary>
        public string ManifestProfileID
        {
            get
            {
                return mManifest_profileid;
            }

        }

        /// <summary>
        /// Sender address
        /// </summary>
        public string SenderAddress
        {
            get
            {
                return mSenderAddress;
            }

        }

        /// <summary>
        /// A count of the number of payloads being described (must match manifest.count).
        /// </summary>
        public int Payloads_count
        {
            get
            {
                return mPayloads_count;
            }

        }

        /// <summary>
        /// Payload id
        /// </summary>
        public string PayloadID
        {
            get
            {
                return mPayload_id;
            }

        }

        /// <summary>
        /// Record count
        /// </summary>
        public int RecordCount
        {
            get
            {
                return mRecordCount;
            }

        }

        /// <summary>
        /// Feed type
        /// </summary>
        public FEEDTYPE Feed
        {
            get
            {
                return mFeedType;
            }

        }

        /// <summary>
        /// Database Insert
        /// </summary>
        public bool DatabaseInsert
        {
            get
            {
                return mDatabaseInsert;
            }

        }

        #endregion

		#region Methods

        /// <summary>
        /// Clears field values to default values.
        /// </summary>
        public void Clear()
        {
            mHeader_service = "";
            mHeader_trackingid = "";
            mManifest_count = 0;
            mManifest_id = "";
            mManifest_mimetype = "";
            mManifest_profileid = "";
            mSenderAddress = "";
            mPayloads_count = 0;
            mPayload_id = "";
            mRecordCount = 0;
            mFeedType = FEEDTYPE.UNKNOWN;
            mDatabaseInsert = false;
        }
        
		/// <summary>
		/// Read in DistributionEnvelope from an XML stream and load into database
        /// If an XML error is encountered return -1.
        /// If a database error is encountered return -2.
        /// If OK return 0.
		/// </summary>
		/// <param name="reader">XML input stream.</param>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="ValidateEnvelope">Flag to indicate if validation errors of the envelope should abort the loading of the distribution file.</param>
		public int ReadAndLoadXML(XmlReader reader, string XMLFile, bool ValidateEnvelope)
		{
            OOHWICFeed mOOHWIC;
            AEFeed mAE;

            // Setup element name checker
            ElementNameChecker x = new ElementNameChecker();
            x.Error = mErrorLog;
            x.XMLFile = XMLFile;

            // Setup feed objects
            mOOHWIC = new OOHWICFeed();
            mOOHWIC.Database = mDB;
            mOOHWIC.Audit = mAuditLog;
            mOOHWIC.Error = mErrorLog;
            mAE = new AEFeed();
            mAE.Database = mDB;
            mAE.Audit = mAuditLog;
            mAE.Error = mErrorLog;

            try
            {
                // <xml> element
                reader.Read();
                if (!x.Check(reader, XML_xml)) return (XML_ERROR);

                // <DistributionEnvelope> start element
                reader.Read();
                if (!x.Check(reader, XML_DistributionEnvelope)) return (XML_ERROR);
                
                // <header> start element
                reader.Read();
                if (!x.Check(reader, XML_header)) return (XML_ERROR);

                // service attribute
                mHeader_service = reader.GetAttribute(XML_service);

                // Check valid service name
                if (!IsValidServiceName(mHeader_service))
                {
                    mErrorLog.WriteLog("XML File: " + XMLFile + " Service name: " + mHeader_service + " is invalid.");
                    if (ValidateEnvelope) return (XML_ERROR);
                }

                // trackingid attribute
                mHeader_trackingid = reader.GetAttribute(XML_trackingid);
                mAuditLog.WriteLog("TrackingID = " + mHeader_trackingid);

                // Check we havent already got this distribution file loaded
                bool loaded = false;
                if (!FileAlreadyLoaded(XMLFile, mHeader_trackingid, ref loaded)) return (DATABASE_ERROR);

                if (loaded)
                {
                    mErrorLog.WriteLog("XML File: " + XMLFile + " TrackingID: " + mHeader_trackingid + " has already been loaded into database.");
                    return (ALREADY_LOADED_ERROR);
                }

                // Skip to <manifest> start element
                while (reader.LocalName != XML_manifest && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_manifest, "Start", "");
                    return (XML_ERROR);
                }

                // count attribute
                mManifest_count = int.Parse(reader.GetAttribute(XML_count));
                
                // Check count is 1
                if (mManifest_count != 1)
                {
                    mErrorLog.WriteLog("XML File: " + XMLFile + " Manifest.Count = " + mManifest_count + " is invalid, it must be 1.");
                    if (ValidateEnvelope) return(XML_ERROR);
                }

                // <manifestitem> element
                reader.Read();
                if (!x.Check(reader, XML_manifestitem)) return (XML_ERROR);

                // id attribute
                mManifest_id = reader.GetAttribute(XML_id);

                // mimetype attribute
                mManifest_mimetype = reader.GetAttribute(XML_mimetype);

                // Check valid mimetype
                if (!IsValidMimeType(mManifest_mimetype))
                {
                    mErrorLog.WriteLog("XML File: " + XMLFile + " MimeType: " + mManifest_mimetype + " is invalid.");
                    if (ValidateEnvelope) return (XML_ERROR);
                }

                // profileid attribute
                if (!x.CheckA(reader, XML_profileid) && ValidateEnvelope) return (XML_ERROR);
                mManifest_profileid = reader.GetAttribute(XML_profileid);

                // Skip to <manifest> end element
                while (reader.LocalName != XML_manifest && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_manifest, "End", "");
                    return (XML_ERROR);
                }

                // <senderAddress> element
                reader.Read();
                if (!x.Check(reader, XML_senderAddress) && ValidateEnvelope) return (XML_ERROR);

                // uri attribute
                mSenderAddress = reader.GetAttribute(XML_uri);
                mAuditLog.WriteLog("SenderAddress = " + mSenderAddress);

                // Skip to <payloads> start element
                while (reader.LocalName != XML_payloads && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_payloads, "Start", "");
                    return (XML_ERROR);
                }

                // count attribute
                mPayloads_count = int.Parse(reader.GetAttribute(XML_count));

                // Check valid count
                if (mManifest_count != mPayloads_count)
                {
                    mErrorLog.WriteLog("XML File: " + XMLFile + " Manifest count: " + mManifest_count + " is not the same as payloads count: " + mPayloads_count);
                    if (ValidateEnvelope) return (XML_ERROR);
                }

                // <payload> start element
                reader.Read();
                if (!x.Check(reader, XML_payload)) return (XML_ERROR);

                // id attribute
                mPayload_id = reader.GetAttribute(XML_id);

                // Check payload and manifestitem ids match
                if (mManifest_id != mPayload_id)
                {
                    mErrorLog.WriteLog("XML File: " + XMLFile + " Payload id: " + mPayload_id + " does not match Manifest id: " + mManifest_id);
                    if (ValidateEnvelope) return (XML_ERROR);
                }

                // Skip to <recordCount> start element
                while (reader.LocalName != XML_recordCount && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_recordCount, "Start", "");
                    return (XML_ERROR);
                }

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (XML_ERROR);

                // <value> element
                reader.Read();
                if (!x.Check(reader, XML_value)) return (XML_ERROR);

                // value attribute
                mRecordCount = int.Parse(reader.GetAttribute(XML_value));
                mAuditLog.WriteLog("Record count = " + mRecordCount);

                // Skip to first <subject> start element
                while (reader.LocalName != XML_subject && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_subject, "Start", "");
                    return (XML_ERROR);
                }

                // Initialise subject count
                int SubjectCount = 1;

                // Move to first Feed element
                reader.Read();

                // Determine type of feed
                switch(reader.LocalName)
                {
                    case "OOHWICFeed":
                        mFeedType = FEEDTYPE.OOHWIC;
                        mAuditLog.WriteLog("Feed type = OOHWIC");
                        break;

                    case "AEFeed":
                        mFeedType = FEEDTYPE.AE;
                        mAuditLog.WriteLog("Feed type = AE");
                        break;

                    default:
                        mFeedType = FEEDTYPE.UNKNOWN;
                        break;
                }

                // Check defined feed
                if (mFeedType == FEEDTYPE.UNKNOWN)
                {
                    mErrorLog.WriteLog("XML File: " + XMLFile + " Unknown feed: " + reader.LocalName);
                    return (XML_ERROR);
                }

                // INSERT DistributionEnvelope into database 
                if (!Insert(XMLFile)) return (DATABASE_ERROR);
                mDatabaseInsert = true;


                // Process feed
                bool FeedOK = false;
                switch (mFeedType)
                {
                    case FEEDTYPE.OOHWIC:
                        mOOHWIC.Clear();
                        FeedOK = mOOHWIC.ReadXML(reader, XMLFile);
                        break;

                    case FEEDTYPE.AE:
                        mAE.Clear();
                        FeedOK = mAE.ReadXML(reader, XMLFile);
                        break;
                }
                if (!FeedOK) return (XML_ERROR);

                // INSERT Feed into database
                switch (mFeedType)
                {
                    case FEEDTYPE.OOHWIC:
                        if (!mOOHWIC.Insert(XMLFile, mHeader_trackingid, SubjectCount)) return (DATABASE_ERROR);
                        break;

                    case FEEDTYPE.AE:
                        if (!mAE.Insert(XMLFile, mHeader_trackingid, SubjectCount)) return (DATABASE_ERROR);
                        break;
                }

                // Skip to <subject> end element
                while (reader.LocalName != XML_subject && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_subject, "End", "");
                    return (XML_ERROR);
                }

                // Move to next element
                reader.Read();

                // Process all remaining <subject> elements
                do
                {
                    // Skip to next <subject> start element
                    while (reader.LocalName != XML_subject && !reader.EOF) reader.Read();
                    if (!reader.EOF)
                    {
                        // Increment subject count
                        ++SubjectCount;

                        // Move to Feed element
                        reader.Read();

                        // Determine if type of feed is consistent with all other feeds in the batch
                        FEEDTYPE feed;
                        switch (reader.LocalName)
                        {
                            case "OOHWICFeed":
                                feed = FEEDTYPE.OOHWIC;
                                break;

                            case "AEFeed":
                                feed = FEEDTYPE.AE;
                                break;

                            default:
                                feed = FEEDTYPE.UNKNOWN;
                                break;
                        }
                        if (mFeedType != feed)
                        {
                            mErrorLog.WriteLog("XML File: " + XMLFile + " Contains mixed feeds.");
                            return (XML_ERROR);
                        }

                        // Process feed
                        switch (mFeedType)
                        {
                            case FEEDTYPE.OOHWIC:
                                mOOHWIC.Clear();
                                FeedOK = mOOHWIC.ReadXML(reader, XMLFile);
                                break;

                            case FEEDTYPE.AE:
                                mAE.Clear();
                                FeedOK = mAE.ReadXML(reader, XMLFile);
                                break;
                        }
                        if (!FeedOK) return (XML_ERROR);

                        // INSERT Feed into database
                        switch (mFeedType)
                        {
                            case FEEDTYPE.OOHWIC:
                                if (!mOOHWIC.Insert(XMLFile, mHeader_trackingid, SubjectCount)) return (DATABASE_ERROR);
                                break;

                            case FEEDTYPE.AE:
                                if (!mAE.Insert(XMLFile, mHeader_trackingid, SubjectCount)) return (DATABASE_ERROR);
                                break;
                        }

                        // Skip to <subject> end element
                        while (reader.LocalName != XML_subject && !reader.EOF) reader.Read();
                        if (reader.EOF)
                        {
                            x.Missing(reader, XML_subject, "End", "");
                            return (XML_ERROR);
                        }

                        // Move to next element
                        reader.Read();
                    }
                } while (!reader.EOF);

                // Check record count matches subject count
                if (mRecordCount != SubjectCount)
                {
                    mErrorLog.WriteLog("XML File: " + XMLFile + " Record count = " + mRecordCount + " does not match number of subjects = " + SubjectCount);
                    if (ValidateEnvelope) return (XML_ERROR);
                }

                return (OK);
            }
            catch (XmlException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return (XML_ERROR);
            }
            catch (XmlSchemaValidationException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return (XML_ERROR);
            }
		}

        /// <summary>
        /// Rolls back all database records with TrackingID value
        /// </summary>
        /// <param name="TrackingID">Tracking identifier.</param>
        public void RollBack(string TrackingID)
        {
            // Doesnt pass back any exceptions

            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = mDB.SQLConnection;
            myCommand.CommandType = CommandType.Text;

            // PresentingComplaints
            myCommand.CommandText = "DELETE FROM presentingcomplaints WHERE trackingid = '" + mDB.Munge(TrackingID) + "'";
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog(" " + myCommand.CommandText + " error: " + e.Message);
            }

            // PrescribedItems
            myCommand.CommandText = "DELETE FROM prescribeditems WHERE trackingid = '" + mDB.Munge(TrackingID) + "'";
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog(" " + myCommand.CommandText + " error: " + e.Message);
            }

            // Diagnoses
            myCommand.CommandText = "DELETE FROM diagnoses WHERE trackingid = '" + mDB.Munge(TrackingID) + "'";
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog(" " + myCommand.CommandText + " error: " + e.Message);
            }

            // Investigations
            myCommand.CommandText = "DELETE FROM investigations WHERE trackingid = '" + mDB.Munge(TrackingID) + "'";
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog(" " + myCommand.CommandText + " error: " + e.Message);
            }

            // Outcomes
            myCommand.CommandText = "DELETE FROM outcomes WHERE trackingid = '" + mDB.Munge(TrackingID) + "'";
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog(" " + myCommand.CommandText + " error: " + e.Message);
            }

            // OOHWICFeeds
            myCommand.CommandText = "DELETE FROM oohwicfeeds WHERE trackingid = '" + mDB.Munge(TrackingID) + "'";
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog(" " + myCommand.CommandText + " error: " + e.Message);
            }

            // Treatments
            myCommand.CommandText = "DELETE FROM treatments WHERE trackingid = '" + mDB.Munge(TrackingID) + "'";
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog(" " + myCommand.CommandText + " error: " + e.Message);
            }

            // Secondary Diagnoses
            myCommand.CommandText = "DELETE FROM secondarydiagnoses WHERE trackingid = '" + mDB.Munge(TrackingID) + "'";
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog(" " + myCommand.CommandText + " error: " + e.Message);
            }

            // AEFeeds
            myCommand.CommandText = "DELETE FROM aefeeds WHERE trackingid = '" + mDB.Munge(TrackingID) + "'";
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog(" " + myCommand.CommandText + " error: " + e.Message);
            }

            // DistributionFiles
            myCommand.CommandText = "DELETE FROM distributionfiles WHERE trackingid = '" + mDB.Munge(TrackingID) + "'";
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog(" " + myCommand.CommandText + " error: " + e.Message);
            }
        }

        /// <summary>
        /// Check if service name is valid. 
        /// </summary>
        /// <param name="service">Service URI.</param>
        private bool IsValidServiceName(string service)
        {
            return (service == SENDDATASET);
        }

        /// <summary>
        /// Check if mimetype is valid. 
        /// </summary>
        /// <param name="mimetype">Mime type.</param>
        private bool IsValidMimeType(string mimetype)
        {
            return (mimetype == MIMETYPE);
        }

        /// <summary>
        /// Check if file already loaded in database
        /// If database error returns false
        /// Returns file loaded status in loaded
        /// </summary>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="trackingid">Tracking identifier.</param>
        /// <param name="loaded">Returns file loaded status.</param>
        private bool FileAlreadyLoaded(string XMLFile, string trackingid, ref bool loaded)
        {
            int c;

            string myCmd = "SELECT COUNT(*) FROM distributionfiles WHERE trackingid = '" + mDB.Munge(mHeader_trackingid) + "'";
            SqlCommand myCommand = new SqlCommand(myCmd, mDB.SQLConnection);
            myCommand.CommandType = CommandType.Text;
            try
            {
                c = (int)myCommand.ExecuteScalar();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog("XML File: " + XMLFile + " SELECT FROM distributionfiles error: " + e.Message);
                return (false);
            }

            loaded = (c == 1);

            return (true);
        }

        /// <summary>
        /// Insert the DistributionEnvelope into database
        /// If an error is encountered return false.
        /// </summary>
        /// <param name="XMLFile">Name of XML file.</param>
        private bool Insert(string XMLFile)
        {

            string myCmd = "INSERT INTO distributionfiles (trackingid, senderaddress, recordcount, feedtype, filename, loaddatetime) VALUES (" +
                "'" + mDB.Munge(mHeader_trackingid) + "','" +
                mDB.Munge(mSenderAddress) + "'," +
                mRecordCount.ToString() + "," +
                ((int)mFeedType).ToString() + ",'" +
                mDB.Munge(XMLFile) + "','" +
                DateTime.Now.ToString(DatabaseHelper.DTFORMAT) + "')";

            SqlCommand myCommand = new SqlCommand(myCmd, mDB.SQLConnection);
            myCommand.CommandType = CommandType.Text;

            try
            {
                // INSERT could throw an exception
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog("XML File: " + XMLFile + " INSERT INTO distribtionfiles error: " + e.Message);
                return (false);
            }

            return (true);
        }

		#endregion
    }
}
