﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Data;
using System.Data.SqlClient;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		Treatment
    // Description:	A treatment.
    //
    // History:
    // 09 Nov 2011	1.00	MAK Initial version
    // 12 Mar 2012  2.00    MAK Updated
    // 28 Mar 2012  3.00    MAK Updated

    /// <summary>
    /// Treatment represents a treatment. 
    /// </summary>
    public class Treatment
    {
        #region Constants

        private const string XML_component23 = "component23";
        private const string XML_observationEvent = "observationEvent";
        private const string XML_code = "code";
        private const string XML_text = "text";
        private const string XML_value = "value";
        private const string XML_codeSystem = "codeSystem";
        private const string XML_displayName = "displayName";

		#endregion

		#region Fields

        private ErrorLog mErrorLog;                     // Error log
        private AuditLog mAuditLog;                     // Audit Log
        private DatabaseHelper mDB;                     // Database helper

        private string mTreatment_text;                 // A string representing the treatment. 
        private string mTreatment_value;                // A code which indicates the treatment.
        private string mTreatment_codesystem;
        private string mTreatment_displayname;

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public Treatment()
		{
			Clear();
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// Audit Log
        /// </summary>
        public AuditLog Audit
        {
            get
            {
                return mAuditLog;
            }

            set
            {
                mAuditLog = value;
            }
        }

        /// <summary>
        /// Database Helper
        /// </summary>
        public DatabaseHelper Database
        {
            get
            {
                return mDB;
            }

            set
            {
                mDB = value;
            }
        }

        /// <summary>
        /// Treatment Text
        /// </summary>
        public string TreatmentText
        {
            get
            {
                return mTreatment_text;
            }
        }

        /// <summary>
        /// Treatment Value
        /// </summary>
        public string TreatmentValue
        {
            get
            {
                return mTreatment_value;
            }
        }

        /// <summary>
        /// Treatment code system
        /// </summary>
        public string TreatmentCodeSystem
        {
            get
            {
                return mTreatment_codesystem;
            }
        }

        /// <summary>
        /// Treatment display name
        /// </summary>
        public string TreatmentDisplayName
        {
            get
            {
                return mTreatment_displayname;
            }
        }

        #endregion

		#region Methods

        /// <summary>
        /// Clears field values to default values.
        /// </summary>
        public void Clear()
        {
            mTreatment_text = "";
            mTreatment_value = "";
            mTreatment_codesystem = "";
            mTreatment_displayname = "";
        }
        
		/// <summary>
        /// Read in Treatment from an XML stream.
        /// If an error is encountered return false.
		/// </summary>
		/// <param name="reader">XML input stream.</param>
        /// <param name="XMLFile">Name of XML file.</param>
		public bool ReadXML(XmlReader reader, string XMLFile)
		{
            // Setup element name checker
            ElementNameChecker x = new ElementNameChecker();
            x.Error = mErrorLog;
            x.XMLFile = XMLFile;

            try
            {
                // On <component23> start elelemt
                if (!x.Check(reader, XML_component23)) return (false);

                // <observationEvent> start element
                reader.Read();
                if (!x.Check(reader, XML_observationEvent)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // Move to next element
                reader.Read();

                // Check if <text> start element
                if (reader.LocalName == XML_text)
                {
                    // Element contents if not empty
                    if (!reader.IsEmptyElement)
                    {
                        mTreatment_text = reader.ReadElementContentAsString();
                    }
                    else
                    {
                        // Skip to next element
                        reader.Skip();
                    }
                }

                // Check if <value> start element
                if (reader.LocalName == XML_value)
                {
                    // code attribute
                    mTreatment_value = reader.GetAttribute(XML_code);

                    // codeSystem attribute
                    mTreatment_codesystem = reader.GetAttribute(XML_codeSystem);

                    // displayName attribute
                    mTreatment_displayname = reader.GetAttribute(XML_displayName);

                    // Skip to next element
                    reader.Skip();
                }

                // On <observationEvent> end element
                if (!x.Check(reader, XML_observationEvent)) return (false);

                // <component23> end element
                reader.Read();
                if (!x.Check(reader, XML_component23)) return (false);

                // Move to next element
                reader.Read();
 
                return true;
            }
            catch (XmlException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
            catch (XmlSchemaValidationException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
		}

        /// <summary>
        /// Insert the treatment into database
        /// If an error is encountered return false.
        /// </summary>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="TrackingID">Tracking identifer.</param>
        /// <param name="FeedID">Feed identifier.</param>
        /// <param name="TreatmentID">Treatment identifier.</param>
        public bool Insert(string XMLFile, string TrackingID, int FeedID, int TreatmentID)
        {

            string myCmd = "INSERT INTO treatments (trackingid, feedid, treatmentid, treatmenttext, treatmentvalue, treatmentcodesystem, treatmentdisplayname) VALUES (" +
                "'" + TrackingID + "'," +
                FeedID + "," +
                TreatmentID + ",'" +
                mDB.Munge(mTreatment_text) + "','" +
                mDB.Munge(mTreatment_value) + "','" +
                mDB.Munge(mTreatment_codesystem) + "','" +
                mDB.Munge(mTreatment_displayname) +
                "')";

            SqlCommand myCommand = new SqlCommand(myCmd, mDB.SQLConnection);
            myCommand.CommandType = CommandType.Text;

            try
            {
                // INSERT could throw an exception
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog("XML File: " + XMLFile + " INSERT INTO treatments error: " + e.Message);
                return (false);
            }

            return (true);
        }

		#endregion
    }
}
