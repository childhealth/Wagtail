﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Data;
using System.Data.SqlClient;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		OOHWICFeed
    // Description:	Out of Hours/Walk In Centre Feed.
    //
    // History:
    // 27 Oct 2011	1.00	MAK Initial version
    // 14 Feb 2012  2.00    MAK Updated
    // 12 Mar 2012  3.00    MAK Updated

    /// <summary>
    /// OOHWICFeed represents a Out of Hours/Walk In Centre Feed. 
    /// </summary>
    public class OOHWICFeed
    {
        #region Constants

        private const string XML_OOHWICFeed = "OOHWICFeed";
        private const string XML_low = "low";
        private const string XML_high = "high";
        private const string XML_value = "value";
        private const string XML_createdDate = "createdDate";
        private const string XML_component17 = "component17";
        private const string XML_component18 = "component18";
        private const string XML_modifiedDate = "modifiedDate";
        private const string XML_component19 = "component19";
        private const string XML_component4 = "component4";
        private const string XML_cancelledEncounter = "cancelledEncounter";
        private const string XML_code = "code";
        private const string XML_component = "component";
        private const string XML_cancellationReason = "cancellationReason";
        private const string XML_component21 = "component21";
        private const string XML_component23 = "component23";
        private const string XML_contactType = "contactType";
        private const string XML_component24 = "component24";
        private const string XML_component25 = "component25";
        private const string XML_component27 = "component27";
        private const string XML_contentId = "contentId";
        private const string XML_COCT_TP000018GB01_PMIContent = "COCT_TP000018GB01.PMIContent";
        private const string XML_component28 = "component28";
        private const string XML_activityLocationType = "activityLocationType";
        private const string XML_component5 = "component5";
        private const string XML_component7 = "component7";
        private const string XML_priorityAfterAssessment = "priorityAfterAssessment";
        private const string XML_component9 = "component9";
        private const string XML_caseNumber = "caseNumber";
        private const string XML_location = "location";
        private const string XML_destinationOrganisation1 = "destinationOrganisation1";
        private const string XML_locationRoutingOrganization = "locationRoutingOrganization";
        private const string XML_id = "id";
        private const string XML_location1 = "location1";
        private const string XML_locationType = "locationType";
        private const string XML_location2 = "location2";
        private const string XML_serviceOrganisation = "serviceOrganisation";
        private const string XML_locationOrganization = "locationOrganization";
        private const string XML_name = "name";
        private const string XML_location3 = "location3";
        private const string XML_sourceOrganisation = "sourceOrganisation";
        private const string XML_responsibleParty = "responsibleParty";
        private const string XML_assignedEntity = "assignedEntity";
        private const string XML_assignedPerson1 = "assignedPerson1";
        private const string XML_walkInEncounterType = "walkInEncounterType";
        private const string XML_deleteFlag = "deleteFlag";
        private const string XML_extension = "extension";
        private const string XML_root = "root";
        private const string XML_effectiveTime = "effectiveTime";
        private const string LB = "<";
        private const string RB = ">";
        private const string CONTAINER = "from Encounter ID = ";
        private const string XML_text = "text";

		#endregion

		#region Fields

        private ErrorLog mErrorLog;                                 // Error log
        private AuditLog mAuditLog;                                 // Audit Log
        private DatabaseHelper mDB;                                 // Database helper

        private string mEncounter_id;                               // Encounter id.
        private string mEncounter_root;                             // Root of encounter id.
        private DateTime mEffectiveTime_low;			            // The date/time at which the encounter occurred or was planned to occur.
        private DateTime mEffectiveTime_high;                       // The date/time at which the encounter occurred or was planned to occur.
        private string mWalkInEncounterType;                        // A code which indicates the type of walk in encounter.
        private string mDeleteFlag;                                 // A value of true indicates that the record should be deleted, a value of false indicates that the record should not be deleted. 
        private DateTime mCreatedDate;                              // The time at which the Out of Hours/Walk in Centre record was created
        private DateTime mModifiedDate;                             // The time at which the Out of Hours/Walk in Centre record was modified.
        private List<PresentingComplaint> mPresentingComplaints;    // List of presenting complaints. 
        private string mCancelledEncounter_value;                   // A value of true indicates that the encounter was cancelled, a value of false indicates that the encounter was not cancelled. 
        private string mCancellationReason_value;                   // A string representation of the reason for the cancellation of the encounter. 
        private List<PrescribedItem> mPrescribedItems;              // List of prescribed items
        private string mContactType;                                // Contact type
        private string mContactTypeDescription;                     // Contact type description
        private List<Diagnosis> mDiagnoses;                         // List of diagnosis
        private List<Investigation> mInvestigations;                // List of investigations
        private PMIContent mPatient;                                // Patient
        private string mActivityLocationType;                       // A code which indicates the type of activity location
        private List<Outcome> mOutcomes;                            // List of outcomes
        private string mPriorityAfterAssessment;                    // Priority after assessment
        private string mCaseNumber;                                 // Case number
        private string mDestinationOrg;                             // Destination organisation
        private string mDestinationOrg_root;                        // Root of destination organisation value
        private string mDestinationOrg_name;                        // Destination organisation name
        private string mLocationType;                               // Location type
        private string mServiceOrg_id;                              // Service organisation id
        private string mServiceOrg_root;                            // Root of service organisation id value
        private string mServiceOrg_name;                            // Service organisation name
        private string mSourceOrg;                                  // Source organisation
        private string mSourceOrg_root;                             // Root of source organisation value
        private string mSourceOrg_name;                             // Source organisation name
        private string mResponsibleParty_id1;                       // Responsible Party ID 1
        private string mResponsibleParty_id1root;                   // Root of Responsible Party ID 1 value             
        private string mResponsibleParty_id2;                       // Responsible Party ID 2
        private string mResponsibleParty_id2root;                   // Root of Responsible Party ID 2 value      
        private PersonName mResponsibleParty_name;                  // Responsible Party name
        private DateTime mCaseEffectiveTime_low;			        // The date/time at which the case occurred or was planned to occur.
        private DateTime mCaseEffectiveTime_high;                   // The date/time at which the case occurred or was planned to occur.

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public OOHWICFeed()
		{
            mEffectiveTime_low = new DateTime();
            mEffectiveTime_high = new DateTime();
            mCreatedDate = new DateTime();
            mModifiedDate = new DateTime(); ;
            mPresentingComplaints = new List<PresentingComplaint>();
            mPrescribedItems = new List<PrescribedItem>();
            mDiagnoses = new List<Diagnosis>();
            mInvestigations = new List<Investigation>();
            mPatient = new PMIContent();
            mOutcomes = new List<Outcome>();
            mResponsibleParty_name = new PersonName();
            mCaseEffectiveTime_low = new DateTime();
            mCaseEffectiveTime_high = new DateTime();
			Clear();
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// Audit Log
        /// </summary>
        public AuditLog Audit
        {
            get
            {
                return mAuditLog;
            }

            set
            {
                mAuditLog = value;
            }
        }

        /// <summary>
        /// Database Helper
        /// </summary>
        public DatabaseHelper Database
        {
            get
            {
                return mDB;
            }

            set
            {
                mDB = value;
            }
        }

        /// <summary>
        /// Encounter ID
        /// </summary>
        public string EncounterID
        {
            get
            {
                return mEncounter_id;
            }
        }

        /// <summary>
        /// Encounter Root
        /// </summary>
        public string EncounterRoot
        {
            get
            {
                return mEncounter_root;
            }
        }

        /// <summary>
        /// The date/time at which the encounter occurred or was planned to occur.
        /// </summary>
        public DateTime EffectiveTime_low
        {
            get
            {
                return mEffectiveTime_low;
            }
        }

        /// <summary>
        /// The date/time at which the encounter occurred or was planned to occur.
        /// </summary>
        public DateTime EffectiveTime_high
        {
            get
            {
                return mEffectiveTime_high;
            }
        }

        /// <summary>
        /// A code which indicates the type of walk in encounter.
        /// </summary>
        public string WalkInEncounterType
        {
            get
            {
                return mWalkInEncounterType;
            }
        }

        /// <summary>
        /// Delete flag
        /// </summary>
        public string DeleteFlag
        {
            get
            {
                return mDeleteFlag;
            }
        }

        /// <summary>
        /// Creation date
        /// </summary>
        public DateTime CreatedDate
        {
            get
            {
                return mCreatedDate;
            }
        }

        /// <summary>
        /// Modified date
        /// </summary>
        public DateTime ModifiedDate
        {
            get
            {
                return mModifiedDate;
            }
        }

        /// <summary>
        /// List of presenting complaint
        /// </summary>
        public List<PresentingComplaint> PresentingComplaints
        {
            get
            {
                return mPresentingComplaints;
            }
        }

        /// <summary>
        /// Cancelled encounter
        /// </summary>
        public string CancelledEncounter
        {
            get
            {
                return mCancelledEncounter_value;
            }
        }

        /// <summary>
        /// Cancellation reason
        /// </summary>
        public string CancellationReason
        {
            get
            {
                return mCancellationReason_value;
            }
        }

        /// <summary>
        /// List of prescribed items
        /// </summary>
        public List<PrescribedItem> PrescribedItems
        {
            get
            {
                return mPrescribedItems;
            }
        }

        /// <summary>
        /// Contact type
        /// </summary>
        public string ContactType
        {
            get
            {
                return mContactType;
            }
        }

        /// <summary>
        /// Contact type description
        /// </summary>
        public string ContactTypeDescription
        {
            get
            {
                return mContactTypeDescription;
            }
        }

        /// <summary>
        /// List of diagnosis
        /// </summary>
        public List<Diagnosis> Diagnoses
        {
            get
            {
                return mDiagnoses;
            }
        }

        /// <summary>
        /// List of investigations
        /// </summary>
        public List<Investigation> Investigations
        {
            get
            {
                return mInvestigations;
            }
        }

        /// <summary>
        /// Patient
        /// </summary>
        public PMIContent Patient
        {
            get
            {
                return mPatient;
            }
        }

        /// <summary>
        /// Activity location type
        /// </summary>
        public string ActivityLocationType
        {
            get
            {
                return mActivityLocationType;
            }
        }

        /// <summary>
        /// List of outcomes
        /// </summary>
        public List<Outcome> Outcomes
        {
            get
            {
                return mOutcomes;
            }
        }

        /// <summary>
        /// Priority after assessment
        /// </summary>
        public string PriorityAfterAssessment
        {
            get
            {
                return mPriorityAfterAssessment;
            }
        }

        /// <summary>
        /// Case number
        /// </summary>
        public string CaseNumber
        {
            get
            {
                return mCaseNumber;
            }
        }

        /// <summary>
        /// Destination organisation
        /// </summary>
        public string DestinationOrg
        {
            get
            {
                return mDestinationOrg;
            }
        }

        /// <summary>
        /// Destination organisation root
        /// </summary>
        public string DestinationOrgRoot
        {
            get
            {
                return mDestinationOrg_root;
            }
        }

        /// <summary>
        /// Destination organisation name
        /// </summary>
        public string DestinationOrgName
        {
            get
            {
                return mDestinationOrg_name;
            }
        }

        /// <summary>
        /// Location type
        /// </summary>
        public string LocationType
        {
            get
            {
                return mLocationType;
            }
        }

        /// <summary>
        /// Service organisation id
        /// </summary>
        public string ServiceOrgID
        {
            get
            {
                return mServiceOrg_id;
            }
        }

        /// <summary>
        /// Service organisation root
        /// </summary>
        public string ServiceOrgRoot
        {
            get
            {
                return mServiceOrg_root;
            }
        }

        /// <summary>
        /// Service organisation name
        /// </summary>
        public string ServiceOrgName
        {
            get
            {
                return mServiceOrg_name;
            }
        }

        /// <summary>
        /// Source organisation
        /// </summary>
        public string SourceOrg
        {
            get
            {
                return mSourceOrg;
            }
        }

        /// <summary>
        /// Source organisation root
        /// </summary>
        public string SourceOrgRoot
        {
            get
            {
                return mSourceOrg_root;
            }
        }

        /// <summary>
        /// Source organisation name
        /// </summary>
        public string SourceOrgName
        {
            get
            {
                return mSourceOrg_name;
            }
        }

        /// <summary>
        /// Responsible Party ID 1
        /// </summary>
        public string ResponsiblePartyID1
        {
            get
            {
                return mResponsibleParty_id1;
            }
        }

        /// <summary>
        /// Responsible Party ID 1 Root
        /// </summary>
        public string ResponsiblePartyID1Root
        {
            get
            {
                return mResponsibleParty_id1root;
            }
        }

        /// <summary>
        /// Responsible Party ID 2
        /// </summary>
        public string ResponsiblePartyID2
        {
            get
            {
                return mResponsibleParty_id2;
            }
        }

        /// <summary>
        /// Responsible Party ID 2 Root
        /// </summary>
        public string ResponsiblePartyID2Root
        {
            get
            {
                return mResponsibleParty_id2root;
            }
        }

        /// <summary>
        /// Responsible Party Name
        /// </summary>
        public PersonName ResponsiblePartyName
        {
            get
            {
                return mResponsibleParty_name;
            }
        }

        /// <summary>
        /// The date/time at which the case occurred or was planned to occur.
        /// </summary>
        public DateTime CaseEffectiveTime_low
        {
            get
            {
                return mCaseEffectiveTime_low;
            }
        }

        /// <summary>
        /// The date/time at which the case occurred or was planned to occur.
        /// </summary>
        public DateTime CaseEffectiveTime_high
        {
            get
            {
                return mCaseEffectiveTime_high;
            }
        }

        #endregion

		#region Methods

        /// <summary>
        /// Clears field values to default values.
        /// </summary>
        public void Clear()
        {
            mEncounter_id = "";
            mEncounter_root = "";
            mEffectiveTime_low = DateTime.MinValue;
            mEffectiveTime_high = DateTime.MinValue;
            mWalkInEncounterType = "";
            mDeleteFlag = "";
            mCreatedDate = DateTime.MinValue;
            mModifiedDate = DateTime.MinValue;
            mPresentingComplaints.Clear();
            mCancelledEncounter_value = "";
            mCancellationReason_value = "";
            mPrescribedItems.Clear();
            mContactType = "";
            mContactTypeDescription = "";
            mDiagnoses.Clear();
            mInvestigations.Clear();
            mPatient.Clear();
            mActivityLocationType = "";
            mOutcomes.Clear();
            mPriorityAfterAssessment = "";
            mCaseNumber = "";
            mDestinationOrg = "";
            mDestinationOrg_root = "";
            mDestinationOrg_name = "";
            mLocationType = "";
            mServiceOrg_id = "";
            mServiceOrg_root = "";
            mServiceOrg_name = "";
            mSourceOrg = "";
            mServiceOrg_root = "";
            mSourceOrg_name = "";
            mResponsibleParty_id1 = ""; 
            mResponsibleParty_id1root = "";
            mResponsibleParty_id2 = "";
            mResponsibleParty_id2root = "";
            mResponsibleParty_name.Clear();
            mCaseEffectiveTime_low = DateTime.MinValue;
            mCaseEffectiveTime_high = DateTime.MinValue;
        }
        
		/// <summary>
        /// Read in OOHWICFeed from an XML stream.
        /// If an error is encountered return false.
		/// </summary>
		/// <param name="reader">XML input stream.</param>
        /// <param name="XMLFile">Name of XMLFile.</param>
		public bool ReadXML(XmlReader reader, string XMLFile)
		{
            // Setup element name checker
            ElementNameChecker x = new ElementNameChecker();
            x.Error = mErrorLog;
            x.XMLFile = XMLFile;

            try
            {
                // Assume on <OOHWICFeed> start element
                if (!x.Check(reader, XML_OOHWICFeed)) return (false);

                // Skip to <id> element
                while (reader.LocalName != XML_id && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_id, LB + XML_OOHWICFeed + RB, "");
                    return false;
                }

                // extension attribute
                mEncounter_id = reader.GetAttribute(XML_extension);

                // root attribute
                mEncounter_root = reader.GetAttribute(XML_root);

                // Skip to <low> element in <effectiveTime>
                while (reader.LocalName != XML_low && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_low, LB + XML_effectiveTime + RB, CONTAINER + mEncounter_id);
                    return false;
                }

                // value attribute
                string s = reader.GetAttribute(XML_value);
                if (!mDB.HL7DataTime(s, out mEffectiveTime_low))
                {
                    x.InvalidDateTime(reader, XML_low, LB + XML_effectiveTime + RB, s);
                    return false;
                }

                // skip to next element
                reader.Skip();

                // <high> element
                if (!x.Check(reader, XML_high)) return (false);

                // value attribute
                s = reader.GetAttribute(XML_value);
                if (!mDB.HL7DataTime(s, out mEffectiveTime_high))
                {
                    x.InvalidDateTime(reader, XML_high, LB + XML_effectiveTime + RB, s);
                    return false;
                }

                // Skip to <value> element in <walkInEncounterType> in element <component2>
                while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_value, LB + XML_walkInEncounterType + RB, CONTAINER + mEncounter_id);
                    return false;
                }

                // code attribute
                mWalkInEncounterType = reader.GetAttribute(XML_code);

                // skip to next element
                reader.Skip();

                // <walkInEncounterType> end element
                if (!x.Check(reader, XML_walkInEncounterType)) return (false);

                // Skip to <value> element in <deleteFlag> in element <component12>
                while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_value, LB + XML_deleteFlag + RB, CONTAINER + mEncounter_id);
                    return false;
                }

                // value attribute
                mDeleteFlag = reader.GetAttribute(XML_value);

                // skip to next element
                reader.Skip();

                // <deleteFlag> end element
                if (!x.Check(reader, XML_deleteFlag)) return (false);

                // Skip to <value> element in <createdDate> in element <component17>
                while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_value, LB + XML_createdDate + RB, CONTAINER + mEncounter_id);
                    return false;
                }

                // value attribute
                s = reader.GetAttribute(XML_value);
                if (!mDB.HL7DataTime(s, out mCreatedDate))
                {
                    x.InvalidDateTime(reader, XML_value, LB + XML_createdDate + RB, s);
                    return false;
                }

                // skip to next element
                reader.Skip();

                // <createdDate> end element
                if (!x.Check(reader, XML_createdDate)) return (false);

                //  <component17> end element
                reader.Read();
                if (!x.Check(reader, XML_component17)) return (false);

                // Move to next element
                reader.Read();

                // Check if we have a <component18> element
                if (reader.LocalName == XML_component18)
                {
                    // skip to <value> element in <modifiedDate>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_modifiedDate + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // value attribute
                    s = reader.GetAttribute(XML_value);
                    if (!mDB.HL7DataTime(s, out mModifiedDate))
                    {
                        x.InvalidDateTime(reader, XML_value, LB + XML_modifiedDate + RB, s);
                        return false;
                    }
                    // skip to next element
                    reader.Skip();

                    // <modifiedDate> end element
                    if (!x.Check(reader, XML_modifiedDate)) return (false);

                    // <component18> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component18)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // There can be 0 .. n <component19> elements
                while (reader.LocalName == XML_component19)
                {
                    PresentingComplaint mComplaint = new PresentingComplaint();
                    mComplaint.Audit = mAuditLog;
                    mComplaint.Error = mErrorLog;
                    mComplaint.Database = mDB;
                    if (mComplaint.ReadXML(reader, XMLFile, DistributionEnvelope.FEEDTYPE.OOHWIC))
                    {
                        mPresentingComplaints.Add(mComplaint);
                    }
                    else
                    {
                        return false;
                    }
                }

                // On <component4> start element
                if (!x.Check(reader, XML_component4)) return (false);

                // <cancelledEncounter> start element
                reader.Read();
                if (!x.Check(reader, XML_cancelledEncounter)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // <value> element
                reader.Read();
                if (!x.Check(reader, XML_value)) return (false);

                // value attribute
                mCancelledEncounter_value = reader.GetAttribute(XML_value);

                // skip to next element
                reader.Skip();

                // Check if we have a <component> start element
                if (reader.LocalName == XML_component)
                {
                    // <cancellationReason> start element
                    reader.Read();
                    if (!x.Check(reader, XML_cancellationReason)) return (false);

                    // <code> element
                    reader.Read();
                    if (!x.Check(reader, XML_code)) return (false);

                    // <value> start element
                    reader.Read();
                    if (!x.Check(reader, XML_value)) return (false);

                    // Element contents if not empty
                    if (!reader.IsEmptyElement)
                    {
                        mCancellationReason_value = reader.ReadElementContentAsString();
                    }
                    else
                    {
                        // Skip to next element
                        reader.Skip();
                    }

                    // <cancellationReason> end element
                    if (!x.Check(reader, XML_cancellationReason)) return (false);

                    // <component> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component)) return (false);

                    // <cancelledEncounter> end element
                    reader.Read();
                    if (!x.Check(reader, XML_cancelledEncounter)) return (false);
                }

                // On <cancelledEncounter> end element
                if (!x.Check(reader, XML_cancelledEncounter)) return (false);

                // <component4> end element
                reader.Read();
                if (!x.Check(reader, XML_component4)) return (false);

                // Move to next element
                reader.Read();

                // There can be 0 .. n <component21> elements
                while (reader.LocalName == XML_component21)
                {
                    PrescribedItem mItem = new PrescribedItem();
                    mItem.Audit = mAuditLog;
                    mItem.Error = mErrorLog;
                    mItem.Database = mDB;
                    if (mItem.ReadXML(reader, XMLFile, DistributionEnvelope.FEEDTYPE.OOHWIC, mEncounter_id))
                    {
                        mPrescribedItems.Add(mItem);
                    }
                    else
                    {
                        return false;
                    }
                }

                // Check if we have a <component23> start element
                // This should be mandatory but TPP have a bug
                if (reader.LocalName == XML_component23)
                {
                    // On <component23> start element
                    //if (!x.Check(reader, XML_component23)) return (false);

                    // <contactType> start element
                    reader.Read();
                    if (!x.Check(reader, XML_contactType)) return (false);

                    // <code> element
                    reader.Read();
                    if (!x.Check(reader, XML_code)) return (false);

                    // <text> element - optional to be backwards compatible with RC1
                    reader.Read();
                    if (reader.LocalName == XML_text)
                    {
                        // Element contents if not empty
                        if (!reader.IsEmptyElement)
                        {
                            mContactTypeDescription = reader.ReadElementContentAsString();
                        }
                        else
                        {
                            // Skip to next element
                            reader.Skip();
                        }
                    }

                    // <value> element
                    if (!x.Check(reader, XML_value)) return (false);

                    // code attribute
                    mContactType = reader.GetAttribute(XML_code);

                    // skip to next element
                    reader.Skip();

                    // <contactType> end element
                    if (!x.Check(reader, XML_contactType)) return (false);

                    // <component23> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component23)) return (false);

                    // Move to next element
                    reader.Read();
                }
                else
                {
                    x.Check(reader, XML_component23);
                }

                // There can be 0 .. n <component24> elements
                while (reader.LocalName == XML_component24)
                {
                    Diagnosis mDiag = new Diagnosis();
                    mDiag.Audit = mAuditLog;
                    mDiag.Error = mErrorLog;
                    mDiag.Database = mDB;
                    if (mDiag.ReadXML(reader, XMLFile))
                    {
                        mDiagnoses.Add(mDiag);
                    }
                    else
                    {
                        return false;
                    }
                }

                // There can be 0 .. n <component25> elements
                while (reader.LocalName == XML_component25)
                {
                    Investigation mInvest = new Investigation();
                    mInvest.Audit = mAuditLog;
                    mInvest.Error = mErrorLog;
                    mInvest.Database = mDB;
                    if (mInvest.ReadXML(reader, XMLFile, DistributionEnvelope.FEEDTYPE.OOHWIC))
                    {
                        mInvestigations.Add(mInvest);
                    }
                    else
                    {
                        return false;
                    }
                }

                // On <component27> start element
                if (!x.Check(reader, XML_component27)) return (false);

                // <contentId> element
                reader.Read();
                if (!x.Check(reader, XML_contentId)) return (false);

                // <COCT_TP000018GB01.PMIContent> start element RC1 OR
                // <COCT_TP000018GB02.PMIContent> start element RC2
                // To provide backward compatibility dont check 
                reader.Read();

                mPatient.Audit = mAuditLog;
                mPatient.Error = mErrorLog;
                mPatient.Database = mDB;
                if (!mPatient.ReadXML(reader, XMLFile, mEncounter_id)) return (false);
                
                // On <component27> end element
                if (!x.Check(reader, XML_component27)) return (false);

                // Move on to next element
                reader.Read();

                // Check if we have a <component28> element
                if (reader.LocalName == XML_component28)
                {
                    // Skip to <value> element in <activityLocationType>
                    while (reader.LocalName != XML_value && !reader.EOF) reader.Read();
                    if (reader.EOF)
                    {
                        x.Missing(reader, XML_value, LB + XML_activityLocationType + RB, CONTAINER + mEncounter_id);
                        return false;
                    }

                    // value attribute
                    mActivityLocationType = reader.GetAttribute(XML_value);

                    // <activityLocationType> end element
                    reader.Read();
                    if (!x.Check(reader, XML_activityLocationType)) return (false);

                    // <component28> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component28)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // There can be 0 .. n <component5> elements
                while (reader.LocalName == XML_component5)
                {
                    Outcome mOut = new Outcome();
                    mOut.Audit = mAuditLog;
                    mOut.Error = mErrorLog;
                    mOut.Database = mDB;
                    if (mOut.ReadXML(reader, XMLFile))
                    {
                        mOutcomes.Add(mOut);
                    }
                    else
                    {
                        return false;
                    }
                }

                // Check if we have a <component7> element
                if (reader.LocalName == XML_component7)
                {
                    // <priorityAfterAssessment> element
                    reader.Read();
                    if (!x.Check(reader, XML_priorityAfterAssessment)) return (false);

                    // <code> element
                    reader.Read();
                    if (!x.Check(reader, XML_code)) return (false);

                    // <value> element
                    reader.Read();
                    if (!x.Check(reader, XML_value)) return (false);

                    // code attribute
                    mPriorityAfterAssessment = reader.GetAttribute(XML_code);

                    // <priorityAfterAssessment> end element
                    reader.Read();
                    if (!x.Check(reader, XML_priorityAfterAssessment)) return (false);

                    // <component7> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component7)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <component9> element
                if (reader.LocalName == XML_component9)
                {
                    // <caseNumber> element
                    reader.Read();
                    if (!x.Check(reader, XML_caseNumber)) return (false);

                    // <code> element
                    reader.Read();
                    if (!x.Check(reader, XML_code)) return (false);

                    // Read next element
                    reader.Read();

                    // Check if we have a <effectiveTime> element
                    if (reader.LocalName == XML_effectiveTime)
                    {
                        // <low> element
                        reader.Read();
                        if (!x.Check(reader, XML_low)) return (false);

                        // value attribute
                        s = reader.GetAttribute(XML_value);
                        if (!mDB.HL7DataTime(s, out mCaseEffectiveTime_low))
                        {
                            x.InvalidDateTime(reader, XML_low, LB + XML_effectiveTime + RB, s);
                            return false;
                        }

                        // skip to next element
                        reader.Skip();

                        // <high> element
                        if (!x.Check(reader, XML_high)) return (false);

                        // value attribute
                        s = reader.GetAttribute(XML_value);
                        if (!mDB.HL7DataTime(s, out mCaseEffectiveTime_high))
                        {
                            x.InvalidDateTime(reader, XML_high, LB + XML_effectiveTime + RB, s);
                            return false;
                        }

                        // skip to next element
                        reader.Skip();

                        // <effectiveTime> end element
                        if (!x.Check(reader, XML_effectiveTime)) return (false);

                        // Read next element
                        reader.Read();
                    }

                    // <value> element
                    if (!x.Check(reader, XML_value)) return (false);

                    // extension attribute
                    mCaseNumber = reader.GetAttribute(XML_extension);

                    // skip to next element
                    reader.Skip();

                    // <caseNumber> end element
                    if (!x.Check(reader, XML_caseNumber)) return (false);
    
                    // <component9> end element
                    reader.Read();
                    if (!x.Check(reader, XML_component9)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // On <location> start element
                if (!x.Check(reader, XML_location)) return (false);

                // <destinationOrganisation1> start element
                reader.Read();
                if (!x.Check(reader, XML_destinationOrganisation1)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // <locationRoutingOrganization> start element
                reader.Read();
                if (!x.Check(reader, XML_locationRoutingOrganization)) return (false);

                // <id> element
                reader.Read();
                if (!x.Check(reader, XML_id)) return (false);

                // extension attribute
                mDestinationOrg = reader.GetAttribute(XML_extension);

                // root attribute
                mDestinationOrg_root = reader.GetAttribute(XML_root);

                // Move to next element
                reader.Read();

                // Check if we have an <name> element - optional to be backward compatible with RC1
                if (reader.LocalName == XML_name)
                {
                    // Element contents if not empty
                    if (!reader.IsEmptyElement)
                    {
                        mDestinationOrg_name = reader.ReadElementContentAsString();
                    }
                    else
                    {
                        // Skip to next element
                        reader.Skip();
                    }
                }

                // <locationRoutingOrganization> end element
                if (!x.Check(reader, XML_locationRoutingOrganization)) return (false);

                // <destinationOrganisation1> end element
                reader.Read();
                if (!x.Check(reader, XML_destinationOrganisation1)) return (false);

                // <location> end element
                reader.Read();
                if (!x.Check(reader, XML_location)) return (false);

                // Move to next element
                reader.Read();

                // Check if we have a <location1> element
                if (reader.LocalName == XML_location1)
                {
                    // <locationType> element
                    reader.Read();
                    if (!x.Check(reader, XML_locationType)) return (false);

                    // <code> element
                    reader.Read();
                    if (!x.Check(reader, XML_code)) return (false);

                    // code attribute
                    mLocationType = reader.GetAttribute(XML_code);

                    // <locationType> end element
                    reader.Read();
                    if (!x.Check(reader, XML_locationType)) return (false);
    
                    // <location1> end element
                    reader.Read();
                    if (!x.Check(reader, XML_location1)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // Check if we have a <location2> element
                if (reader.LocalName == XML_location2)
                {
                    // <serviceOrganisation> element
                    reader.Read();
                    if (!x.Check(reader, XML_serviceOrganisation)) return (false);
  
                    // Move to next element
                    reader.Read();

                    // Check if we have a <locationOrganization> element
                    if (reader.LocalName == XML_locationOrganization)
                    {
                        // Move to next element
                        reader.Read();

                        // Check if we have an <id> element
                        if (reader.LocalName == XML_id)
                        {
                            // extension attribute
                            mServiceOrg_id = reader.GetAttribute(XML_extension);

                            // root attribute
                            mServiceOrg_root = reader.GetAttribute(XML_root);

                            // Move to next node
                            reader.Read();
                        }

                        // Check if we have an <name> element
                        if (reader.LocalName == XML_name)
                        {
                            // Element contents if not empty
                            if (!reader.IsEmptyElement)
                            {
                                mServiceOrg_name = reader.ReadElementContentAsString();
                            }
                            else
                            {
                                // Skip to next element
                                reader.Skip();
                            }
                        }

                        // On <locationOrganization> end element
                        if (!x.Check(reader, XML_locationOrganization)) return (false);
        
                    }
                    
                    // <serviceOrganisation> end element
                    reader.Read();
                    if (!x.Check(reader, XML_serviceOrganisation)) return (false);
    
                    // <location2> end element
                    reader.Read();
                    if (!x.Check(reader, XML_location2)) return (false);

                    // Move to next element
                    reader.Read();
                }

                // On <location3>
                if (!x.Check(reader, XML_location3)) return (false);

                // <sourceOrganisation>
                reader.Read();
                if (!x.Check(reader, XML_sourceOrganisation)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // <locationRoutingOrganization> start element
                reader.Read();
                if (!x.Check(reader, XML_locationRoutingOrganization)) return (false);

                // <id> element
                reader.Read();
                if (!x.Check(reader, XML_id)) return (false);

                // extension attribute
                mSourceOrg = reader.GetAttribute(XML_extension);

                // root attribute
                mSourceOrg_root = reader.GetAttribute(XML_root);

                // Move to next element
                reader.Read();

                // Check if we have an <name> element - optional to be backward compatible with RC1
                if (reader.LocalName == XML_name)
                {
                    // Element contents if not empty
                    if (!reader.IsEmptyElement)
                    {
                        mSourceOrg_name = reader.ReadElementContentAsString();
                    }
                    else
                    {
                        // Skip to next element
                        reader.Skip();
                    }
                }

                // <locationRoutingOrganization> end element
                if (!x.Check(reader, XML_locationRoutingOrganization)) return (false);


                // <sourceOrganisation> end element
                reader.Read();
                if (!x.Check(reader, XML_sourceOrganisation)) return (false);

                // <location3> end element
                reader.Read();
                if (!x.Check(reader, XML_location3)) return (false);

                // Move to next element
                reader.Read();

                // Check if we have a <responsibleParty> element
                if (reader.LocalName == XML_responsibleParty)
                {
                    // <assignedEntity> start element
                    reader.Read();
                    if (!x.Check(reader, XML_assignedEntity)) return (false);

                    // Move to next element
                    reader.Read();

                    // Check if <id> element
                    if (reader.LocalName == XML_id)
                    {
                        // extension attribute
                        mResponsibleParty_id1 = reader.GetAttribute(XML_extension);

                        // root attribute
                        mResponsibleParty_id1root = reader.GetAttribute(XML_root);

                        // Move to next element
                        reader.Read();
                    }

                    // Check if <id> element
                    if (reader.LocalName == XML_id)
                    {
                        // extension attribute
                        mResponsibleParty_id2 = reader.GetAttribute(XML_extension);

                        // root attribute
                        mResponsibleParty_id2root = reader.GetAttribute(XML_root);

                        // Move to next element
                        reader.Read();
                    }

                    // Check if <assignedPerson1> element
                    if (reader.LocalName == XML_assignedPerson1)
                    {
                        // <name> start element
                        reader.Read();
                        if (!x.Check(reader, XML_name)) return (false);

                        // Read persons name
                        mResponsibleParty_name.Audit = mAuditLog;
                        mResponsibleParty_name.Error = mErrorLog;
                        if (!mResponsibleParty_name.ReadXML(reader, XMLFile, mEncounter_id)) return (false);
        
                        // <assignedEntity> end element
                        reader.Read();
                        if (!x.Check(reader, XML_assignedEntity)) return (false);
                    }
                            
                    // On <assignedEntity> end element
                    if (!x.Check(reader, XML_assignedEntity)) return (false);
    
                    // <responsibleParty> end element
                    reader.Read();
                    if (!x.Check(reader, XML_responsibleParty)) return (false);
                    
                    // Move to next element
                    reader.Read();
                }

                // Skip to <OOHWICFeed> end element
                while (reader.LocalName != XML_OOHWICFeed && !reader.EOF) reader.Read();
                if (reader.EOF)
                {
                    x.Missing(reader, XML_OOHWICFeed, "End", CONTAINER + mEncounter_id);
                    return false;
                }

                return true;
            }
            catch (XmlException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
            catch (XmlSchemaValidationException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
		}

        /// <summary>
        /// Insert the OOWICFeed into database
        /// If an error is encountered return false.
        /// </summary>
        /// <param name="XMLFile">Name of XMLFile.</param>
        /// <param name="TrackingID">Tracking Identifier.</param>
        /// <param name="FeedID">Feed Identifier.</param>
        public bool Insert(string XMLFile, string TrackingID, int FeedID)
        {
            // Insert record into OOWICFeeds table

            string myCmd = "INSERT INTO oohwicfeeds (trackingid, feedid, encounterid, encounterroot, effectivetimelow, effectivetimehigh, walkinencountertype, deleteflag, createddate," +
                           "modifieddate, cancelledencounter, cancellationreason, contacttype, activitylocationtype, priorityafterassessment, casenumber," +
                            "destinationorganisation, destinationorganisationroot, locationtype, serviceorganisationid, serviceorganisationroot, serviceorganisationname, sourceorganisation, sourceorganisationroot, RP_ID1, RP_ID1Root, RP_ID2, RP_ID2Root," +
                            "RP_FamilyName, RP_GivenName, RP_NamePrefix, RP_NameSuffix, RP_NameUse, PMI_DeleteFlag, PMI_CreatedDate, PMI_ModifiedDate, PMI_ID1, PMI_ID1Root, PMI_ID2, PMI_ID2Root," +
                            "PMI_Postcode, PMI_FamilyName, PMI_GivenName, PMI_NamePrefix, PMI_NameSuffix, PMI_NameUse, PMI_Gender, PMI_DOB, PMI_DOD, PMI_EthnicGroup," +
                            "PMI_GP_OrgCode, PMI_GP_OrgName, PMI_PCTReg_OrgCode, PMI_PCTReg_OrgName, PMI_PCTRes_OrgCode, PMI_PCTRes_OrgName, VisitorStatus, contacttypedescription, destinationorganisationname, sourceorganisationname, caseeffectivetimelow, caseeffectivetimehigh) VALUES (" +
                "'" + mDB.Munge(TrackingID) + "'," +
                FeedID + ",'" +
                mDB.Munge(mEncounter_id) + "','" +
                mDB.Munge(mEncounter_root) + "'," +
                ((mEffectiveTime_low == DateTime.MinValue) ? "NULL" : "'" + mEffectiveTime_low.ToString(DatabaseHelper.DTFORMAT) + "'") + "," +
                ((mEffectiveTime_high == DateTime.MinValue) ? "NULL" : "'" + mEffectiveTime_high.ToString(DatabaseHelper.DTFORMAT) + "'") + ",'" +
                mDB.Munge(mWalkInEncounterType) + "','" +
                mDB.Munge(mDeleteFlag) + "'," +
                ((mCreatedDate == DateTime.MinValue) ? "NULL" : "'" + mCreatedDate.ToString(DatabaseHelper.DTFORMAT) + "'") + "," +
                ((mModifiedDate == DateTime.MinValue) ? "NULL" : "'" + mModifiedDate.ToString(DatabaseHelper.DTFORMAT) + "'") + ",'" +
                mDB.Munge(mCancelledEncounter_value) + "','" +
                mDB.Munge(mCancellationReason_value) + "','" +
                mDB.Munge(mContactType) + "','" +
                mDB.Munge(mActivityLocationType) + "','" +
                mDB.Munge(mPriorityAfterAssessment) + "','" +
                mDB.Munge(mCaseNumber) + "','" +
                mDB.Munge(mDestinationOrg) + "','" +
                mDB.Munge(mDestinationOrg_root) + "','" +
                mDB.Munge(mLocationType) + "','" +
                mDB.Munge(mServiceOrg_id) + "','" +
                mDB.Munge(mServiceOrg_root) + "','" +
                mDB.Munge(mServiceOrg_name) + "','" +
                mDB.Munge(mSourceOrg) + "','" +
                mDB.Munge(mSourceOrg_root) + "','" +
                mDB.Munge(mResponsibleParty_id1) + "','" +
                mDB.Munge(mResponsibleParty_id1root) + "','" +
                mDB.Munge(mResponsibleParty_id2) + "','" +
                mDB.Munge(mResponsibleParty_id2root) + "','" +
                mDB.Munge(mResponsibleParty_name.Family) + "','" +
                mDB.Munge(mResponsibleParty_name.Given) + "','" +
                mDB.Munge(mResponsibleParty_name.Prefix) + "','" +
                mDB.Munge(mResponsibleParty_name.Suffix) + "','" +
                mDB.Munge(mResponsibleParty_name.Use) + "','" +
                mDB.Munge(mPatient.DeleteFlag) + "'," +
                ((mPatient.CreatedDate == DateTime.MinValue) ? "NULL" : "'" + mPatient.CreatedDate.ToString(DatabaseHelper.DTFORMAT) + "'") + "," +
                ((mPatient.ModifiedDate == DateTime.MinValue) ? "NULL" : "'" + mPatient.ModifiedDate.ToString(DatabaseHelper.DTFORMAT) + "'") + ",'" +
                mDB.Munge(mPatient.ID1) + "','" +
                mDB.Munge(mPatient.ID1Root) + "','" +
                mDB.Munge(mPatient.ID2) + "','" +
                mDB.Munge(mPatient.ID2Root) + "','" +
                mDB.Munge(mPatient.Postcode) + "','" +
                mDB.Munge(mPatient.PatientName.Family) + "','" +
                mDB.Munge(mPatient.PatientName.Given) + "','" +
                mDB.Munge(mPatient.PatientName.Prefix) + "','" +
                mDB.Munge(mPatient.PatientName.Suffix) + "','" +
                mDB.Munge(mPatient.PatientName.Use) + "','" +
                mDB.Munge(mPatient.Gender) + "'," +
                ((mPatient.DOB == DateTime.MinValue) ? "NULL" : "'" + mPatient.DOB.ToString(DatabaseHelper.DTFORMAT) + "'") + "," +
                ((mPatient.DOD == DateTime.MinValue) ? "NULL" : "'" + mPatient.DOD.ToString(DatabaseHelper.DTFORMAT) + "'") + ",'" +
                mDB.Munge(mPatient.EthnicGroup) + "','" +
                mDB.Munge(mPatient.GP.OrgCode) + "','" +
                mDB.Munge(mPatient.GP.OrgName) + "','" +
                mDB.Munge(mPatient.PCTReg.OrgCode) + "','" +
                mDB.Munge(mPatient.PCTReg.OrgName) + "','" +
                mDB.Munge(mPatient.PCTRes.OrgCode) + "','" +
                mDB.Munge(mPatient.PCTRes.OrgName) + "','" +
                mDB.Munge(mPatient.VisitorStatus) + "','" +
                mDB.Munge(mContactTypeDescription) + "','" +
                mDB.Munge(mDestinationOrg_name) + "','" +
                mDB.Munge(mSourceOrg_name) + "'," +
                ((mCaseEffectiveTime_low == DateTime.MinValue) ? "NULL" : "'" + mCaseEffectiveTime_low.ToString(DatabaseHelper.DTFORMAT) + "'") + "," +
                ((mCaseEffectiveTime_high == DateTime.MinValue) ? "NULL" : "'" + mCaseEffectiveTime_high.ToString(DatabaseHelper.DTFORMAT) + "'") +
                ")";

            SqlCommand myCommand = new SqlCommand(myCmd, mDB.SQLConnection);
            myCommand.CommandType = CommandType.Text;

            try
            {
                // INSERT could throw an exception
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog("XML File: " + XMLFile + " INSERT INTO oohwicfeeds error: " + e.Message);
                return (false);
            }

            // If any presenting complaints, insert them into PresentingComplaints table
            for (int i = 0; i < mPresentingComplaints.Count; ++i)
            {
                if(!mPresentingComplaints[i].Insert(XMLFile, TrackingID, FeedID, i + 1)) return(false);
            }

            // If any prescribed items, insert them into PrescribedItems table
            for (int i = 0; i < mPrescribedItems.Count; ++i)
            {
                if (!mPrescribedItems[i].Insert(XMLFile, TrackingID, FeedID, i + 1)) return (false);
            }

            // If any diagnoses, insert them into Diagnoses table
            for (int i = 0; i < mDiagnoses.Count; ++i)
            {
                if (!mDiagnoses[i].Insert(XMLFile, TrackingID, FeedID, i + 1)) return (false);
            }

            // If any investigations, insert them into Investigations table
            for (int i = 0; i < mInvestigations.Count; ++i)
            {
                if (!mInvestigations[i].Insert(XMLFile, TrackingID, FeedID, i + 1)) return (false);
            }

            // If any outcomes, insert them into Outcomes table
            for (int i = 0; i < mOutcomes.Count; ++i)
            {
                if (!mOutcomes[i].Insert(XMLFile, TrackingID, FeedID, i + 1)) return (false);
            }

            return (true);
        }

		#endregion
    }
}
