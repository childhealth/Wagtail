﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Data;
using System.Data.SqlClient;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		PresentingComplaint
    // Description:	A presenting complaint.
    //
    // History:
    // 28 Oct 2011	1.00	MAK Initial version
    // 12 Mar 2012  2.00    MAK Updated

    /// <summary>
    /// PresentingComplaint represents a presenting complaint. 
    /// </summary>
    public class PresentingComplaint
    {
        #region Constants

        private const string XML_component19 = "component19";
        private const string XML_component16 = "component16";
        private const string XML_presentingComplaintCode = "presentingComplaintCode";
        private const string XML_presentingComplaint = "presentingComplaint";
        private const string XML_code = "code";
        private const string XML_text = "text";
        private const string XML_value = "value";
        private const string XML_codeSystem = "codeSystem";
        private const string XML_displayName = "displayName";

		#endregion

		#region Fields

        private ErrorLog mErrorLog;                     // Error log
        private AuditLog mAuditLog;                     // Audit Log
        private DatabaseHelper mDB;                     // Database helper

        private string mPresentingComplaint_text;       // A string representing the presenting complaint. 
        private string mPresentingComplaint_value;      // A code which indicates the presenting complaint.
        private string mPresentingComplaint_codesystem; // The associated code system.
        private string mPresentingComplaint_displayname;// The display name of code.

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public PresentingComplaint()
		{
			Clear();
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// Audit Log
        /// </summary>
        public AuditLog Audit
        {
            get
            {
                return mAuditLog;
            }

            set
            {
                mAuditLog = value;
            }
        }

        /// <summary>
        /// Database Helper
        /// </summary>
        public DatabaseHelper Database
        {
            get
            {
                return mDB;
            }

            set
            {
                mDB = value;
            }
        }

        /// <summary>
        /// Complaint Text
        /// </summary>
        public string ComplaintText
        {
            get
            {
                return mPresentingComplaint_text;
            }
        }

        /// <summary>
        /// Complaint Value
        /// </summary>
        public string ComplaintValue
        {
            get
            {
                return mPresentingComplaint_value;
            }
        }

        /// <summary>
        /// Complaint Code System
        /// </summary>
        public string ComplaintCodeSystem
        {
            get
            {
                return mPresentingComplaint_codesystem;
            }
        }

        /// <summary>
        /// Complaint Display Name
        /// </summary>
        public string ComplaintDisplayName
        {
            get
            {
                return mPresentingComplaint_displayname;
            }
        }

        #endregion

		#region Methods

        /// <summary>
        /// Clears field values to default values.
        /// </summary>
        public void Clear()
        {
            mPresentingComplaint_text = "";
            mPresentingComplaint_value = "";
            mPresentingComplaint_codesystem = "";
            mPresentingComplaint_displayname = "";
        }
        
		/// <summary>
        /// Read in PresentingComplaint from an XML stream.
        /// If an error is encountered return false.
		/// </summary>
		/// <param name="reader">XML input stream.</param>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="FeedType">Feed type.</param>
		public bool ReadXML(XmlReader reader, string XMLFile, DistributionEnvelope.FEEDTYPE FeedType)
		{
            // Setup element name checker
            ElementNameChecker x = new ElementNameChecker();
            x.Error = mErrorLog;
            x.XMLFile = XMLFile;

            string ComponentTAG = "";
            string ComplaintTAG = "";

            // Set tags dependent on feed type
            switch (FeedType)
            {
                case DistributionEnvelope.FEEDTYPE.OOHWIC:
                    ComponentTAG = XML_component19;
                    ComplaintTAG = XML_presentingComplaintCode;
                    break;

                case DistributionEnvelope.FEEDTYPE.AE:
                    ComponentTAG = XML_component16;
                    ComplaintTAG = XML_presentingComplaint;
                    break;
            }

            try
            {
                // Assume on component start element 
                if (!x.Check(reader, ComponentTAG)) return (false);

                // Complaint start element
                reader.Read();
                if (!x.Check(reader, ComplaintTAG)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // Move to next element
                reader.Read();

                // Check if <text> start element
                if (reader.LocalName == XML_text)
                {
                    // Element contents if not empty
                    if (!reader.IsEmptyElement)
                    {
                        mPresentingComplaint_text = reader.ReadElementContentAsString();
                    }
                    else
                    {
                        // Skip to next element
                        reader.Skip();
                    }
                }

                // check if <value> start element
                if (reader.LocalName == XML_value)
                {
                    // code attribute
                    mPresentingComplaint_value = reader.GetAttribute(XML_code);

                    // codeSystem attribute
                    mPresentingComplaint_codesystem = reader.GetAttribute(XML_codeSystem);

                    // displayName attribute
                    mPresentingComplaint_displayname = reader.GetAttribute(XML_displayName);

                    // Skip to next element
                    reader.Skip();
                }

                // On complaint end element
                if (!x.Check(reader, ComplaintTAG)) return (false);

                // component end element
                reader.Read();
                if (!x.Check(reader, ComponentTAG)) return (false);

                // Move to next element
                reader.Read();
 
                return true;
            }
            catch (XmlException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
            catch (XmlSchemaValidationException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
		}

        /// <summary>
        /// Insert the presenting complaint into database
        /// If an error is encountered return false.
        /// </summary>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="TrackingID">Tracking identifier.</param>
        /// <param name="FeedID">Feed identifer.</param>
        /// <param name="ComplaintID">Complaint identifier.</param>
        public bool Insert(string XMLFile, string TrackingID, int FeedID, int ComplaintID)
        {

            string myCmd = "INSERT INTO presentingcomplaints (trackingid, feedid, complaintid, complainttext, complaintvalue, complaintcodesystem, complaintdisplayname) VALUES (" +
                "'" + mDB.Munge(TrackingID) + "'," +
                FeedID + "," +
                ComplaintID + ",'" +
                mDB.Munge(mPresentingComplaint_text) + "','" +
                mDB.Munge(mPresentingComplaint_value) + "','" +
                mDB.Munge(mPresentingComplaint_codesystem) + "','" +
                mDB.Munge(mPresentingComplaint_displayname) +
                "')";

            SqlCommand myCommand = new SqlCommand(myCmd, mDB.SQLConnection);
            myCommand.CommandType = CommandType.Text;

            try
            {
                // INSERT could throw an exception
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog("XML File: " + XMLFile + " INSERT INTO presentingcomplaints error: " + e.Message);
                return (false);
            }

            return (true);
        }

		#endregion
    }
}
