﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using System.Data;
using System.Data.SqlClient;
using UK.GOV.DH.ClearWaterLib;

namespace UK.GOV.DH.ClearWaterLib
{
    // Name:		Diagnosis
    // Description:	A diagnosis.
    //
    // History:
    // 28 Oct 2011	1.00	MAK Initial version
    // 12 Mar 2012  2.00    MAK Updated

    /// <summary>
    /// Diagnosis represents a diagnosis. 
    /// </summary>
    public class Diagnosis
    {
        #region Constants

        private const string XML_component24 = "component24";
        private const string XML_diagnosis = "diagnosis";
        private const string XML_code = "code";
        private const string XML_text = "text";
        private const string XML_value = "value";
        private const string XML_codeSystem = "codeSystem";
        private const string XML_displayName = "displayName";

		#endregion

		#region Fields

        private ErrorLog mErrorLog;                     // Error log
        private AuditLog mAuditLog;                     // Audit Log
        private DatabaseHelper mDB;                     // Database helper

        private string mDiagnosis_text;                 // A string representing the diagnosis. 
        private string mDiagnosis_value;                // A code which indicates the diagnosis.
        private string mDiagnosis_codesystem;           // The associated code system.
        private string mDiagnosis_displayname;          // The display name of code.

        #endregion

		#region Constructors

		/// <summary>
		/// Default constructor.
		/// </summary>
        public Diagnosis()
		{
			Clear();
		}

		#endregion

		#region Properties

        /// <summary>
        /// Error Log
        /// </summary>
        public ErrorLog Error
        {
            get
            {
                return mErrorLog;
            }

            set
            {
                mErrorLog = value;
            }
        }

        /// <summary>
        /// Audit Log
        /// </summary>
        public AuditLog Audit
        {
            get
            {
                return mAuditLog;
            }

            set
            {
                mAuditLog = value;
            }
        }

        /// <summary>
        /// Database Helper
        /// </summary>
        public DatabaseHelper Database
        {
            get
            {
                return mDB;
            }

            set
            {
                mDB = value;
            }
        }

        /// <summary>
        /// Diagnosis Text
        /// </summary>
        public string DiagnosisText
        {
            get
            {
                return mDiagnosis_text;
            }
        }

        /// <summary>
        /// Diagnosis Value
        /// </summary>
        public string DiagnosisValue
        {
            get
            {
                return mDiagnosis_value;
            }
        }

        /// <summary>
        /// Diagnosis Code system
        /// </summary>
        public string DiagnosisCodeSystem
        {
            get
            {
                return mDiagnosis_codesystem;
            }
        }

        /// <summary>
        /// Diagnosis Display Name
        /// </summary>
        public string DiagnosisDisplayName
        {
            get
            {
                return mDiagnosis_displayname;
            }
        }

        #endregion

		#region Methods

        /// <summary>
        /// Clears field values to default values.
        /// </summary>
        public void Clear()
        {
            mDiagnosis_text = "";
            mDiagnosis_value = "";
            mDiagnosis_codesystem = "";
            mDiagnosis_displayname = "";
        }
        
		/// <summary>
        /// Read in Diagnosis from an XML stream.
        /// If an error is encountered return false.
		/// </summary>
		/// <param name="reader">XML input stream.</param>
        /// <param name="XMLFile">Name of XML file.</param>
		public bool ReadXML(XmlReader reader, string XMLFile)
		{
            // Setup element name checker
            ElementNameChecker x = new ElementNameChecker();
            x.Error = mErrorLog;
            x.XMLFile = XMLFile;

            try
            {
                // On <component24> start element
                if (!x.Check(reader, XML_component24)) return (false);

                // <diagnosis> start element
                reader.Read();
                if (!x.Check(reader, XML_diagnosis)) return (false);

                // <code> element
                reader.Read();
                if (!x.Check(reader, XML_code)) return (false);

                // Move to next element
                reader.Read();

                // Check if <text> start element
                if (reader.LocalName == XML_text)
                {
                    // Element contents if not empty
                    if (!reader.IsEmptyElement)
                    {
                        mDiagnosis_text = reader.ReadElementContentAsString();
                    }
                    else
                    {
                        // Skip to next element
                        reader.Skip();
                    }
                }

                // Check if <value> start element
                if (reader.LocalName == XML_value)
                {
                    // code attribute
                    mDiagnosis_value = reader.GetAttribute(XML_code);

                    // codeSystem attribute
                    mDiagnosis_codesystem = reader.GetAttribute(XML_codeSystem);

                    // displayName attribute
                    mDiagnosis_displayname = reader.GetAttribute(XML_displayName);

                    // Move to next element
                    reader.Read();
                }

                // On <diagnosis> end element
                if (!x.Check(reader, XML_diagnosis)) return (false);

                // <component24> end element
                reader.Read();
                if (!x.Check(reader, XML_component24)) return (false);

                // Move to next element
                reader.Read();
 
                return true;
            }
            catch (XmlException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
            catch (XmlSchemaValidationException e)
            {
                // Thrown explictly for an invalid value within the XML
                mErrorLog.WriteLog("XML File: " + XMLFile + " " + e.Message);
                return false;
            }
		}

        /// <summary>
        /// Insert the diagnosis into database
        /// If an error is encountered return false.
        /// </summary>
        /// <param name="XMLFile">Name of XML file.</param>
        /// <param name="TrackingID">Tracking identifer.</param>
        /// <param name="FeedID">Feed identifier.</param>
        /// <param name="DiagnosisID">Diagnosis identifier.</param>
        public bool Insert(string XMLFile, string TrackingID, int FeedID, int DiagnosisID)
        {

            string myCmd = "INSERT INTO diagnoses (trackingid, feedid, diagnosisid, diagnosistext, diagnosisvalue, diagnosiscodesystem, diagnosisdisplayname) VALUES (" +
                "'" + mDB.Munge(TrackingID) + "'," +
                FeedID + "," +
                DiagnosisID + ",'" +
                mDB.Munge(mDiagnosis_text) + "','" +
                mDB.Munge(mDiagnosis_value) + "','" +
                mDB.Munge(mDiagnosis_codesystem) + "','" +
                mDB.Munge(mDiagnosis_displayname) +
                "')";

            SqlCommand myCommand = new SqlCommand(myCmd, mDB.SQLConnection);
            myCommand.CommandType = CommandType.Text;

            try
            {
                // INSERT could throw an exception
                myCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                mErrorLog.WriteLog("XML File: " + XMLFile + " INSERT INTO diagnoses error: " + e.Message);
                return (false);
            }

            return (true);
        }

		#endregion
    }
}
