﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using System.Configuration;
using UK.GOV.DH.ClearWaterLib;

namespace ClearWaterWin
{
    public partial class Form1 : Form
    {
        #region Constants

        public const string NEWLINE = "\r\n";

        #endregion

        #region Fields

        public ErrorLog mErrorLog;
        public AuditLog mAuditLog;
        public DatabaseHelper mDB;
        public XMLSchema mXSD;
        public bool mValidateEnvelope;

        #endregion

        #region Constructors

        /// <summary>
        /// Default constructor
        /// </summary>
        public Form1()
        {
            InitializeComponent();

            mErrorLog = new ErrorLog();
            mAuditLog = new AuditLog();
            mDB = new DatabaseHelper();
            mXSD = new XMLSchema();

            // Get settings from App.config file
            AuditLogFile.Text = ConfigurationManager.AppSettings.Get("AuditLogFile");
            AuditLogFileEnable.Checked = bool.Parse(ConfigurationManager.AppSettings.Get("AuditLogEnable"));
            ErrorLogFile.Text = ConfigurationManager.AppSettings.Get("ErrorLogFile");
            ErrorLogFileEnable.Checked = bool.Parse(ConfigurationManager.AppSettings.Get("ErrorLogEnable"));
            DatabaseConnectionString.Text = ConfigurationManager.AppSettings.Get("DatabaseConnectionString");
            XSDFolder.Text = ConfigurationManager.AppSettings.Get("XSDFolder");
            mValidateEnvelope = bool.Parse(ConfigurationManager.AppSettings.Get("ValidateEnvelope"));
        }

        #endregion

        #region Event handlers

        /// <summary>
        /// Save settings
        /// </summary>
        private void SaveSettings_Click(object sender, EventArgs e)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(Application.ExecutablePath);

            config.AppSettings.Settings["AuditLogFile"].Value = AuditLogFile.Text;
            config.AppSettings.Settings["AuditLogEnable"].Value = AuditLogFileEnable.Checked.ToString();
            config.AppSettings.Settings["ErrorLogFile"].Value = ErrorLogFile.Text;
            config.AppSettings.Settings["ErrorLogEnable"].Value = ErrorLogFileEnable.Checked.ToString();
            config.AppSettings.Settings["DatabaseConnectionString"].Value = DatabaseConnectionString.Text;
            config.AppSettings.Settings["XSDFolder"].Value = XSDFolder.Text;

            config.Save();
        }

        /// <summary>
        /// Select XML File to load.
        /// </summary>
        private void SelectXMLFile_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "xml files (*.xml)|*.xml|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.FileName = "";
            openFileDialog1.RestoreDirectory = false;
            openFileDialog1.Title = "Open XML File";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                XMLFile.Text = openFileDialog1.FileName;
            }

        }

        /// <summary>
        /// Select Folder to load XML files from
        /// </summary>
        private void SelectXMLFolder_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.Description = "Select folder containg XML files to load";

            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                XMLFolder.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        /// <summary>
        /// Load XML File
        /// </summary>
        private void LoadFile_Click(object sender, EventArgs e)
        {
            // Get settings
            if (!GetSettings())
                return;

            // Check we have a valid XML file
            string mXMLFile = XMLFile.Text;

            if (!File.Exists(mXMLFile))
            {
                Status.Text = Status.Text + "Error: XML File " + mXMLFile + " does not exist." + NEWLINE;
                Status.SelectionStart = Status.Text.Length;
                Status.ScrollToCaret();
                Status.Refresh();
                return;
            }

            // Create XmlReaderSettings
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.ConformanceLevel = ConformanceLevel.Document;
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;
            settings.Schemas = mXSD.XmlSchemas;
            settings.ValidationType = ValidationType.None;

            // Create XmlReader
            XmlReader reader = XmlReader.Create(mXMLFile, settings);
            string s = "XML File " + mXMLFile + " opened.";
            Status.Text = Status.Text + s + NEWLINE;
            Status.SelectionStart = Status.Text.Length;
            Status.ScrollToCaret();
            Status.Refresh();
            mAuditLog.WriteLog(s);

            // Read the DistributionEnvelope
            DistributionEnvelope mEnvelope = new DistributionEnvelope();
            mEnvelope.Error = mErrorLog;
            mEnvelope.Audit = mAuditLog;
            mEnvelope.Database = mDB;

            // Open database connection
            mEnvelope.Database.OpenDB();

            switch (mEnvelope.ReadAndLoadXML(reader, mXMLFile, mValidateEnvelope))
            {
                case -1:
                    s = "Error: Reading XML file - see error log.";
                    Status.Text = Status.Text + s + NEWLINE;
                    Status.SelectionStart = Status.Text.Length;
                    Status.ScrollToCaret();
                    Status.Refresh();
                    mAuditLog.WriteLog(s);

                    // If inserted any database records, roll them back
                    if (mEnvelope.DatabaseInsert) mEnvelope.RollBack(mEnvelope.Header_trackingid);
                    break;

                case -2:
                    s = "Error: Database - see error log.";
                    Status.Text = Status.Text + s + NEWLINE;
                    Status.SelectionStart = Status.Text.Length;
                    Status.ScrollToCaret();
                    Status.Refresh();
                    mAuditLog.WriteLog(s);
                    break;

                case -3:
                    s = "Error: XML file with same TrackingID already loaded into database - see error log.";
                    Status.Text = Status.Text + s + NEWLINE;
                    Status.SelectionStart = Status.Text.Length;
                    Status.ScrollToCaret();
                    Status.Refresh();
                    mAuditLog.WriteLog(s);
                    break;

                default:
                    s = "XML file loaded into database successfully.";
                    Status.Text = Status.Text + s + NEWLINE;
                    Status.SelectionStart = Status.Text.Length;
                    Status.ScrollToCaret();
                    Status.Refresh();
                    mAuditLog.WriteLog(s);
                    break;
            }

            // Close database connection
            mEnvelope.Database.CloseDB();

            // Close XmlReader
            reader.Close();
            s = "XML File " + mXMLFile + " closed.";
            Status.Text = Status.Text + s + NEWLINE;
            Status.SelectionStart = Status.Text.Length;
            Status.ScrollToCaret();
            Status.Refresh();
            mAuditLog.WriteLog(s);
        }

        /// <summary>
        /// Load XML Files from folder
        /// </summary>
        private void LoadFolder_Click(object sender, EventArgs e)
        {
            // Get settings
            if (!GetSettings())
                return;

            // Check we have a valid XML folder
            string mXMLFolder = XMLFolder.Text;

            if (!Directory.Exists(mXMLFolder))
            {
                Status.Text = Status.Text + "Error: Folder " + mXMLFolder + " does not exist." + NEWLINE;
                Status.SelectionStart = Status.Text.Length;
                Status.ScrollToCaret();
                Status.Refresh();
                return;
            }

            // Create XmlReaderSettings
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.ConformanceLevel = ConformanceLevel.Document;
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;
            settings.Schemas = mXSD.XmlSchemas;
            settings.ValidationType = ValidationType.None;

            string s = "Folder " + mXMLFolder + " opened.";
            Status.Text = Status.Text + s + NEWLINE;
            Status.SelectionStart = Status.Text.Length;
            Status.ScrollToCaret();
            Status.Refresh();
            mAuditLog.WriteLog(s);

            // Process the list of files found in the directory.
            string[] fileEntries = Directory.GetFiles(mXMLFolder);
            foreach (string mXMLFile in fileEntries)
            {
                // Create XmlReader
                XmlReader reader = XmlReader.Create(mXMLFile, settings);
                s = "XML File " + mXMLFile + " opened.";
                Status.Text = Status.Text + s + NEWLINE;
                Status.SelectionStart = Status.Text.Length;
                Status.ScrollToCaret();
                Status.Refresh();
                mAuditLog.WriteLog(s);

                // Read the DistributionEnvelope
                DistributionEnvelope mEnvelope = new DistributionEnvelope();
                mEnvelope.Error = mErrorLog;
                mEnvelope.Audit = mAuditLog;
                mEnvelope.Database = mDB;

                // Open database connection
                mEnvelope.Database.OpenDB();

                switch (mEnvelope.ReadAndLoadXML(reader, mXMLFile, mValidateEnvelope))
                {
                    case -1:
                        s = "Error: Reading XML file - see error log.";
                        Status.Text = Status.Text + s + NEWLINE;
                        Status.SelectionStart = Status.Text.Length;
                        Status.ScrollToCaret();
                        Status.Refresh();
                        mAuditLog.WriteLog(s);

                        // If inserted any database records, roll them back
                        if (mEnvelope.DatabaseInsert) mEnvelope.RollBack(mEnvelope.Header_trackingid);
                        break;

                    case -2:
                        s = "Error: Database - see error log.";
                        Status.Text = Status.Text + s + NEWLINE;
                        Status.SelectionStart = Status.Text.Length;
                        Status.ScrollToCaret();
                        Status.Refresh();
                        mAuditLog.WriteLog(s);
                        break;

                    case -3:
                        s = "Error: XML file with same TrackingID already loaded into database - see error log.";
                        Status.Text = Status.Text + s + NEWLINE;
                        Status.SelectionStart = Status.Text.Length;
                        Status.ScrollToCaret();
                        Status.Refresh();
                        mAuditLog.WriteLog(s);
                        break;

                    default:
                        s = "XML file loaded into database successfully.";
                        Status.Text = Status.Text + s + NEWLINE;
                        Status.SelectionStart = Status.Text.Length;
                        Status.ScrollToCaret();
                        Status.Refresh();
                        mAuditLog.WriteLog(s);
                        break;
                }

                // Close database connection
                mEnvelope.Database.CloseDB();

                // Close XmlReader
                reader.Close();
                s = "XML File " + mXMLFile + " closed.";
                Status.Text = Status.Text + s + NEWLINE;
                Status.SelectionStart = Status.Text.Length;
                Status.ScrollToCaret();
                Status.Refresh();
                mAuditLog.WriteLog(s);
            }

            s = "Folder " + mXMLFolder + " closed.";
            Status.Text = Status.Text + s + NEWLINE;
            Status.SelectionStart = Status.Text.Length;
            Status.ScrollToCaret();
            Status.Refresh();
            mAuditLog.WriteLog(s);
        }

        /// <summary>
        /// Show About Box
        /// </summary>
        private void mnuAbout_Click(object sender, EventArgs e)
        {
            AboutBox f = new AboutBox();
            f.ShowDialog();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets and validates settings.
        /// If there is a validation error will place a message in the Status control and return false.
        /// </summary>
        private bool GetSettings()
        {
            // Audit
            mAuditLog.AuditLogFile = AuditLogFile.Text;
            mAuditLog.Enabled = AuditLogFileEnable.Checked;
            if (mAuditLog.Enabled)
            {
                try
                {
                    File.AppendAllText(mAuditLog.AuditLogFile, "");
                }
                catch (Exception e)
                {
                    Status.Text = Status.Text + "Error: Audit Log File " + mAuditLog.AuditLogFile + ": " + e.Message + NEWLINE;
                    Status.SelectionStart = Status.Text.Length;
                    Status.ScrollToCaret();
                    Status.Refresh();
                    return false;
                }
            }

            // Error
            mErrorLog.ErrorLogFile = ErrorLogFile.Text;
            mErrorLog.Enabled = ErrorLogFileEnable.Checked;
            if (mErrorLog.Enabled)
            {
                try
                {
                    File.AppendAllText(mErrorLog.ErrorLogFile, "");
                }
                catch (Exception e)
                {
                    Status.Text = Status.Text + "Error: Error Log File " + mErrorLog.ErrorLogFile + ": " + e.Message + NEWLINE;
                    Status.SelectionStart = Status.Text.Length;
                    Status.ScrollToCaret();
                    Status.Refresh();
                    return false;
                }
            }

            // Database
            mDB.DatabaseConnection = DatabaseConnectionString.Text;
            // Check we can open
            try
            {
                mDB.OpenDB();
                mDB.CloseDB();
            }
            catch (Exception e)
            {
                Status.Text = Status.Text + "Error: Database connection string " + mDB.DatabaseConnection + ": " + e.Message + NEWLINE;
                Status.SelectionStart = Status.Text.Length;
                Status.ScrollToCaret();
                Status.Refresh();
                return false;
            }

            // XSD Folder
            mXSD.XSDFolder = XSDFolder.Text;
            // Check we can load
            try
            {
                mXSD.LoadXSD();
            }
            catch (Exception e)
            {
                Status.Text = Status.Text + "Error: XSD file: " + e.Message + NEWLINE;
                Status.SelectionStart = Status.Text.Length;
                Status.ScrollToCaret();
                Status.Refresh();
                return false;
            }

            return true;
        }

        #endregion
    }
}
