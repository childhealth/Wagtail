﻿namespace ClearWaterWin
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.XSDFolder = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SaveSettings = new System.Windows.Forms.Button();
            this.DatabaseConnectionString = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ErrorLogFileEnable = new System.Windows.Forms.CheckBox();
            this.ErrorLogFile = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.AuditLogFileEnable = new System.Windows.Forms.CheckBox();
            this.AuditLogFile = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.LoadFile = new System.Windows.Forms.Button();
            this.SelectXMLFile = new System.Windows.Forms.Button();
            this.XMLFile = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.LoadFolder = new System.Windows.Forms.Button();
            this.SelectXMLFolder = new System.Windows.Forms.Button();
            this.XMLFolder = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Status = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.XSDFolder);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.SaveSettings);
            this.groupBox1.Controls.Add(this.DatabaseConnectionString);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.ErrorLogFileEnable);
            this.groupBox1.Controls.Add(this.ErrorLogFile);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.AuditLogFileEnable);
            this.groupBox1.Controls.Add(this.AuditLogFile);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(736, 157);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Settings";
            // 
            // XSDFolder
            // 
            this.XSDFolder.Location = new System.Drawing.Point(169, 99);
            this.XSDFolder.Name = "XSDFolder";
            this.XSDFolder.Size = new System.Drawing.Size(496, 20);
            this.XSDFolder.TabIndex = 10;
            this.XSDFolder.Text = "D:\\ClearWater\\Schema";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 99);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "XSD Folder";
            // 
            // SaveSettings
            // 
            this.SaveSettings.Location = new System.Drawing.Point(170, 126);
            this.SaveSettings.Name = "SaveSettings";
            this.SaveSettings.Size = new System.Drawing.Size(126, 23);
            this.SaveSettings.TabIndex = 8;
            this.SaveSettings.Text = "Save Settings";
            this.SaveSettings.UseVisualStyleBackColor = true;
            this.SaveSettings.Click += new System.EventHandler(this.SaveSettings_Click);
            // 
            // DatabaseConnectionString
            // 
            this.DatabaseConnectionString.Location = new System.Drawing.Point(168, 69);
            this.DatabaseConnectionString.Name = "DatabaseConnectionString";
            this.DatabaseConnectionString.Size = new System.Drawing.Size(497, 20);
            this.DatabaseConnectionString.TabIndex = 7;
            this.DatabaseConnectionString.Text = "Data Source=046683-XP\\SQLEXPRESS;Initial Catalog=ClearWater;Integrated Security=S" +
                "SPI;";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Database Connection String";
            // 
            // ErrorLogFileEnable
            // 
            this.ErrorLogFileEnable.AutoSize = true;
            this.ErrorLogFileEnable.Location = new System.Drawing.Point(674, 42);
            this.ErrorLogFileEnable.Name = "ErrorLogFileEnable";
            this.ErrorLogFileEnable.Size = new System.Drawing.Size(59, 17);
            this.ErrorLogFileEnable.TabIndex = 5;
            this.ErrorLogFileEnable.Text = "Enable";
            this.ErrorLogFileEnable.UseVisualStyleBackColor = true;
            // 
            // ErrorLogFile
            // 
            this.ErrorLogFile.Location = new System.Drawing.Point(168, 42);
            this.ErrorLogFile.Name = "ErrorLogFile";
            this.ErrorLogFile.Size = new System.Drawing.Size(497, 20);
            this.ErrorLogFile.TabIndex = 4;
            this.ErrorLogFile.Text = "D:\\ClearWater\\Logs\\ClearWater_ErrorLog.txt";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Error Log File";
            // 
            // AuditLogFileEnable
            // 
            this.AuditLogFileEnable.AutoSize = true;
            this.AuditLogFileEnable.Location = new System.Drawing.Point(673, 18);
            this.AuditLogFileEnable.Name = "AuditLogFileEnable";
            this.AuditLogFileEnable.Size = new System.Drawing.Size(59, 17);
            this.AuditLogFileEnable.TabIndex = 2;
            this.AuditLogFileEnable.Text = "Enable";
            this.AuditLogFileEnable.UseVisualStyleBackColor = true;
            // 
            // AuditLogFile
            // 
            this.AuditLogFile.Location = new System.Drawing.Point(169, 15);
            this.AuditLogFile.Name = "AuditLogFile";
            this.AuditLogFile.Size = new System.Drawing.Size(496, 20);
            this.AuditLogFile.TabIndex = 1;
            this.AuditLogFile.Text = "D:\\ClearWater\\Logs\\ClearWater_AuditLog.txt";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Audit Log File";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.LoadFile);
            this.groupBox2.Controls.Add(this.SelectXMLFile);
            this.groupBox2.Controls.Add(this.XMLFile);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(12, 216);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(736, 84);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Load XML File";
            // 
            // LoadFile
            // 
            this.LoadFile.Location = new System.Drawing.Point(169, 51);
            this.LoadFile.Name = "LoadFile";
            this.LoadFile.Size = new System.Drawing.Size(75, 23);
            this.LoadFile.TabIndex = 3;
            this.LoadFile.Text = "Load";
            this.LoadFile.UseVisualStyleBackColor = true;
            this.LoadFile.Click += new System.EventHandler(this.LoadFile_Click);
            // 
            // SelectXMLFile
            // 
            this.SelectXMLFile.Location = new System.Drawing.Point(604, 23);
            this.SelectXMLFile.Name = "SelectXMLFile";
            this.SelectXMLFile.Size = new System.Drawing.Size(126, 23);
            this.SelectXMLFile.TabIndex = 2;
            this.SelectXMLFile.Text = "Browse...";
            this.SelectXMLFile.UseVisualStyleBackColor = true;
            this.SelectXMLFile.Click += new System.EventHandler(this.SelectXMLFile_Click);
            // 
            // XMLFile
            // 
            this.XMLFile.Location = new System.Drawing.Point(169, 25);
            this.XMLFile.Name = "XMLFile";
            this.XMLFile.Size = new System.Drawing.Size(429, 20);
            this.XMLFile.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "XML File";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.LoadFolder);
            this.groupBox3.Controls.Add(this.SelectXMLFolder);
            this.groupBox3.Controls.Add(this.XMLFolder);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(12, 306);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(736, 82);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Load XML Files from Folder";
            // 
            // LoadFolder
            // 
            this.LoadFolder.Location = new System.Drawing.Point(169, 51);
            this.LoadFolder.Name = "LoadFolder";
            this.LoadFolder.Size = new System.Drawing.Size(75, 23);
            this.LoadFolder.TabIndex = 3;
            this.LoadFolder.Text = "Load";
            this.LoadFolder.UseVisualStyleBackColor = true;
            this.LoadFolder.Click += new System.EventHandler(this.LoadFolder_Click);
            // 
            // SelectXMLFolder
            // 
            this.SelectXMLFolder.Location = new System.Drawing.Point(605, 24);
            this.SelectXMLFolder.Name = "SelectXMLFolder";
            this.SelectXMLFolder.Size = new System.Drawing.Size(125, 23);
            this.SelectXMLFolder.TabIndex = 2;
            this.SelectXMLFolder.Text = "Browse...";
            this.SelectXMLFolder.UseVisualStyleBackColor = true;
            this.SelectXMLFolder.Click += new System.EventHandler(this.SelectXMLFolder_Click);
            // 
            // XMLFolder
            // 
            this.XMLFolder.Location = new System.Drawing.Point(168, 25);
            this.XMLFolder.Name = "XMLFolder";
            this.XMLFolder.Size = new System.Drawing.Size(430, 20);
            this.XMLFolder.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Folder";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Status);
            this.groupBox4.Location = new System.Drawing.Point(12, 406);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(736, 152);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Status";
            // 
            // Status
            // 
            this.Status.Location = new System.Drawing.Point(10, 19);
            this.Status.Multiline = true;
            this.Status.Name = "Status";
            this.Status.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Status.Size = new System.Drawing.Size(720, 127);
            this.Status.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuAbout});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(761, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mnuAbout
            // 
            this.mnuAbout.Name = "mnuAbout";
            this.mnuAbout.Size = new System.Drawing.Size(124, 20);
            this.mnuAbout.Text = "About ClearWaterWin";
            this.mnuAbout.Click += new System.EventHandler(this.mnuAbout_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 566);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "ClearWaterWin";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox DatabaseConnectionString;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox ErrorLogFileEnable;
        private System.Windows.Forms.TextBox ErrorLogFile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox AuditLogFileEnable;
        private System.Windows.Forms.TextBox AuditLogFile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button SaveSettings;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button SelectXMLFile;
        private System.Windows.Forms.TextBox XMLFile;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button LoadFile;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox XMLFolder;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button LoadFolder;
        private System.Windows.Forms.Button SelectXMLFolder;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox Status;
        private System.Windows.Forms.TextBox XSDFolder;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuAbout;
    }
}

